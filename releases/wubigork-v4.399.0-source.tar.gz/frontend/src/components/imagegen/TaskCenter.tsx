import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Button, Input, Tag, Typography } from 'antd'
import {
  AppstoreOutlined, CheckCircleOutlined, ClockCircleOutlined, CloseCircleOutlined,
  DeleteOutlined, FolderOpenOutlined, HistoryOutlined, LoadingOutlined, MenuFoldOutlined, MenuUnfoldOutlined,
  SearchOutlined, ThunderboltOutlined,
} from '@ant-design/icons'
import { C } from '../../utils/theme'
import { HistoryRail } from './HistoryRail'
import { CATEGORIES, type Template, type CustomTemplate } from '../../data/imageTemplates'
import { imageHubAssets, readFileAsDataURL, type ImageHubAssetView } from '../../api/image'
import { usePollingGate } from '../../hooks/usePollingGate'
import type { GenResult, QueueEntry, QueueStatus } from './types'

type TabKey = 'queue' | 'recent' | 'templates' | 'assets'

interface AssetThumb extends ImageHubAssetView {
  url: string
}

// T1 收口：素材库轻扫轮询间隔（低频：登记/成本表变化远慢于任务状态）。
const ASSETS_POLL_MS = 30000

const STATUS_META: Record<QueueStatus, { label: string; icon: React.ReactNode; color: string }> = {
  pending: { label: '待执行', icon: <ClockCircleOutlined />, color: 'default' },
  running: { label: '执行中', icon: <LoadingOutlined />, color: 'processing' },
  done: { label: '完成', icon: <CheckCircleOutlined />, color: 'success' },
  failed: { label: '失败', icon: <CloseCircleOutlined />, color: 'error' },
  canceled: { label: '已取消', icon: <CloseCircleOutlined />, color: 'default' },
}

const MODE_LABEL: Record<string, string> = {
  txt2img: '文生图', img2img: '图生图', t2v: '文生视频',
}

interface Props {
  queueItems: QueueEntry[]
  onClearQueue: () => void
  onCancelQueue: () => void
  history: GenResult[]
  selectedIndex: number
  onSelectHistory: (i: number) => void
  onClearHistory: () => void
  onRegenerateMeta?: (item: GenResult) => void
  templates: Record<string, Template[]>
  customTemplates: CustomTemplate[]
  onApplyTemplate: (t: Template) => void
  onManageTemplates: () => void
}

const TABS: { key: TabKey; label: string; icon: React.ReactNode }[] = [
  { key: 'queue', label: '队列', icon: <ThunderboltOutlined /> },
  { key: 'recent', label: '最近结果', icon: <HistoryOutlined /> },
  { key: 'assets', label: '素材库', icon: <FolderOpenOutlined /> },
  { key: 'templates', label: '模板', icon: <AppstoreOutlined /> },
]

export const TaskCenter: React.FC<Props> = ({
  queueItems, onClearQueue, onCancelQueue,
  history, selectedIndex, onSelectHistory, onClearHistory, onRegenerateMeta,
  templates, customTemplates, onApplyTemplate, onManageTemplates,
}) => {
  const [tab, setTab] = useState<TabKey>('queue')
  const [collapsed, setCollapsed] = useState(false)
  const [keyword, setKeyword] = useState('')
  // T1 画室素材库：登记读取（play 空间，最多展示 12 张缩略）。
  const [assetThumbs, setAssetThumbs] = useState<AssetThumb[]>([])
  const [activeAsset, setActiveAsset] = useState<AssetThumb | null>(null)
  // T1 收口：素材库轻扫更新——tab 激活即重读（成本表不再一次性陈旧）+
  // 30s 低频轮询（复用 usePollingGate 页面可见性门控：不可见即停表，
  // 恢复可见时立即重读一次）。缩略 dataURL 按 path 缓存，避免每轮重读文件。
  const assetsVisible = usePollingGate()
  const assetUrlCacheRef = useRef<Map<string, string>>(new Map())

  useEffect(() => {
    if (tab !== 'assets' || collapsed || !assetsVisible) return
    let cancelled = false
    const load = async () => {
      const list = await imageHubAssets('play', '', 50)
      if (cancelled) return
      const items: AssetThumb[] = []
      for (const a of list) {
        if (!a.path) continue
        let url = assetUrlCacheRef.current.get(a.path)
        if (url === undefined) {
          url = await readFileAsDataURL(a.path).catch(() => '')
          if (cancelled) return
          if (url) assetUrlCacheRef.current.set(a.path, url)
        }
        if (url) {
          items.push({ ...a, url })
          if (items.length >= 12) break
        }
      }
      if (cancelled) return
      setAssetThumbs(items)
      // 轻扫刷新保留用户当前选中（仍在列表内时不跳到第一张）。
      setActiveAsset((prev) => (prev && items.some((x) => x.path === prev.path) ? prev : items[0] || null))
    }
    void load()
    const timer = window.setInterval(() => { void load() }, ASSETS_POLL_MS)
    return () => {
      cancelled = true
      window.clearInterval(timer)
    }
  }, [tab, collapsed, assetsVisible])

  const activeRunning = queueItems.some((q) => q.status === 'pending' || q.status === 'running')
  const recentCount = history.length
  const kw = keyword.trim().toLowerCase()

  const matchedCategories = useMemo(() => {
    if (!kw) return CATEGORIES
    return CATEGORIES.filter((cat) =>
      (templates[cat.id] || []).some((t) =>
        t.label.toLowerCase().includes(kw) || (t.description || '').toLowerCase().includes(kw),
      ),
    )
  }, [kw, templates])

  const customMatch = useMemo(
    () => customTemplates.filter((t) =>
      !kw || t.label.toLowerCase().includes(kw) || (t.description || '').toLowerCase().includes(kw),
    ),
    [customTemplates, kw],
  )
  const hasAnyTemplate = customMatch.length > 0 || matchedCategories.length > 0

  if (collapsed) {
    return (
      <div className="ig-task-center is-collapsed v3-panel" role="complementary" aria-label="历史与任务队列（已收起）">
        {TABS.map((t) => {
          const count = t.key === 'queue' ? queueItems.length
            : t.key === 'recent' ? recentCount
              : t.key === 'assets' ? assetThumbs.length : customTemplates.length
          const active = tab === t.key
          return (
            <button
              key={t.key}
              type="button"
              title={t.label}
              onClick={() => { setTab(t.key); setCollapsed(false) }}
              className={`ig-task-icon${active ? ' is-active' : ''}`}
            >
              {t.icon}
              {count > 0 && <span className="ig-task-badge">{count}</span>}
            </button>
          )
        })}
        <button
          type="button"
          className="ig-task-icon"
          title="展开任务中心"
          onClick={() => setCollapsed(false)}
        >
          <MenuUnfoldOutlined />
        </button>
      </div>
    )
  }

  return (
    <div className="ig-task-center v3-panel" role="complementary" aria-label="历史与任务队列">
      <div className="ig-task-tabs" role="tablist" aria-label="任务中心">
        {TABS.map((t) => {
          const active = tab === t.key
          const count = t.key === 'queue' ? queueItems.length
            : t.key === 'recent' ? recentCount
              : t.key === 'assets' ? assetThumbs.length : customTemplates.length
          return (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={active}
              className={`ig-task-tab${active ? ' is-active' : ''}`}
              onClick={() => setTab(t.key)}
            >
              {t.icon}
              {t.label}
              {count > 0 && <span className="ig-task-tab-count">{count}</span>}
            </button>
          )
        })}
        <button
          type="button"
          className="ig-task-icon"
          title="收起任务中心"
          onClick={() => setCollapsed(true)}
          style={{ marginLeft: 'auto' }}
        >
          <MenuFoldOutlined />
        </button>
      </div>

      <div className="ig-task-body" style={{ flex: 1, minHeight: 0, overflowY: 'auto', overflowX: 'hidden', padding: '10px 2px 2px' }}>
        {tab === 'assets' && (
          assetThumbs.length === 0 ? (
            <div className="ig-task-empty">
              <FolderOpenOutlined style={{ fontSize: 20, color: C('color-text-secondary'), opacity: 0.6 }} />
              <span>画室素材库还是空的——先在图生图中选角色/上传参考图生成一张</span>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {activeAsset && activeAsset.url && (
                <div style={{ textAlign: 'center' }}>
                  <img
                    src={activeAsset.url}
                    alt="素材预览"
                    style={{ maxWidth: '100%', maxHeight: 240, objectFit: 'contain', borderRadius: 10, border: '1px solid var(--border-subtle)' }}
                  />
                  <div style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', gap: 4, justifyContent: 'center' }}>
                    {activeAsset.model && <Tag color="blue">{activeAsset.model}</Tag>}
                    {activeAsset.cost && <Tag>{activeAsset.cost}</Tag>}
                    {activeAsset.source_board === 'novel' && <Tag color="purple">小说</Tag>}
                    {activeAsset.source_board === 'characterlib' && <Tag color="green">角色</Tag>}
                    {activeAsset.kind === 'video' && <Tag color="orange">视频</Tag>}
                  </div>
                  {activeAsset.created_at && (
                    <div style={{ fontSize: 11, color: C('color-text-secondary') }}>
                      {activeAsset.created_at}
                    </div>
                  )}
                </div>
              )}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 5 }}>
                {assetThumbs.map((a) => (
                  <button
                    key={a.path}
                    type="button"
                    onClick={() => setActiveAsset(a)}
                    title={a.path}
                    style={{
                      padding: 2, border: '1px solid',
                      borderColor: activeAsset?.path === a.path ? 'var(--color-primary)' : 'var(--border-subtle)',
                      borderRadius: 8, background: 'color-mix(in srgb, var(--color-text) 3%, transparent)', cursor: 'pointer',
                    }}
                  >
                    <img
                      src={a.url}
                      alt={a.path || '素材'}
                      style={{ width: '100%', aspectRatio: '1 / 1', objectFit: 'cover', borderRadius: 6, display: 'block' }}
                    />
                  </button>
                ))}
              </div>
            </div>
          )
        )}
        {tab === 'queue' && (
          queueItems.length === 0 ? (
            <div className="ig-task-empty">
              <ClockCircleOutlined style={{ fontSize: 20, color: C('color-text-secondary'), opacity: 0.6 }} />
              <span>没有排队中的任务</span>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {queueItems.map((q) => {
                const meta = STATUS_META[q.status]
                const iconColor = q.status === 'running' ? 'var(--color-primary)'
                  : q.status === 'done' ? 'var(--color-success)'
                  : q.status === 'failed' ? 'var(--color-destructive)'
                  : C('color-text-secondary')
                return (
                  <div key={q.id} className="ig-queue-row">
                    <span style={{ color: iconColor }}>
                      {meta.icon}
                    </span>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{
                        fontSize: 12, color: 'var(--color-text)', whiteSpace: 'nowrap',
                        overflow: 'hidden', textOverflow: 'ellipsis',
                      }}>
                        {q.task.prompt || '(空提示词)'}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 2 }}>
                        <Tag color={meta.color} style={{ marginInlineEnd: 0, fontSize: 10, lineHeight: '16px', borderRadius: 999 }}>
                          {meta.label}
                        </Tag>
                        <Typography.Text style={{ fontSize: 10, color: C('color-text-secondary') }}>
                          {MODE_LABEL[q.task.mode] || q.task.mode} · {q.task.model}
                        </Typography.Text>
                      </div>
                    </div>
                  </div>
                )
              })}
              <div style={{ display: 'flex', gap: 6, marginTop: 4 }}>
                {activeRunning && (
                  <Button size="small" block icon={<CloseCircleOutlined />} onClick={onCancelQueue}
                    style={{ borderRadius: 999, fontSize: 11 }}>
                    取消排队
                  </Button>
                )}
                <Button size="small" block icon={<DeleteOutlined />} onClick={onClearQueue}
                  style={{ borderRadius: 999, fontSize: 11 }}>
                  清空记录
                </Button>
              </div>
            </div>
          )
        )}

        {tab === 'recent' && (
          <HistoryRail
            history={history}
            selectedIndex={selectedIndex}
            onSelect={onSelectHistory}
            onClear={onClearHistory}
            onRegenerateMeta={onRegenerateMeta}
            collapsed={false}
          />
        )}

        {tab === 'templates' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <Input
              size="small"
              allowClear
              prefix={<SearchOutlined style={{ color: C('color-text-secondary') }} />}
              placeholder="搜索模板"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              style={{ borderRadius: 999, fontSize: 12 }}
            />

            {customMatch.length > 0 && (
              <TemplateGroup
                title="自定义"
                color="var(--color-primary)"
                items={customMatch}
                onApply={onApplyTemplate}
              />
            )}

            {matchedCategories.map((cat) => {
              const items = (templates[cat.id] || []).filter((t) =>
                !kw || t.label.toLowerCase().includes(kw) || (t.description || '').toLowerCase().includes(kw),
              )
              if (items.length === 0) return null
              return (
                <TemplateGroup
                  key={cat.id}
                  title={cat.label}
                  color={cat.color}
                  items={items}
                  onApply={onApplyTemplate}
                />
              )
            })}

            {kw && !hasAnyTemplate && (
              <div className="ig-task-empty">
                <SearchOutlined style={{ fontSize: 18, color: C('color-text-secondary'), opacity: 0.6 }} />
                <span>未找到匹配模板</span>
              </div>
            )}

            <Button size="small" block icon={<AppstoreOutlined />} onClick={onManageTemplates}
              style={{ borderRadius: 999, fontSize: 11, marginTop: 2 }}>
              管理模板库
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

const TemplateGroup: React.FC<{
  title: string
  color: string
  items: Template[]
  onApply: (t: Template) => void
}> = ({ title, color, items, onApply }) => (
  <div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginBottom: 5 }}>
      <span style={{ width: 7, height: 7, borderRadius: '50%', background: color, flexShrink: 0 }} />
      <Typography.Text style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.04em', color: C('color-text-secondary') }}>
        {title}
      </Typography.Text>
      <span style={{ fontSize: 10, color: C('color-text-secondary'), opacity: 0.7 }}>{items.length}</span>
    </div>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      {items.map((t) => (
        <button
          key={t.label}
          type="button"
          title={t.description || t.prompt}
          onClick={() => onApply(t)}
          className="ig-template-row"
        >
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, minWidth: 0 }}>
            {t.icon && <span style={{ fontSize: 13, lineHeight: 1, flexShrink: 0 }}>{t.icon}</span>}
            <span style={{ fontSize: 12, color: 'var(--color-text)', fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {t.label}
            </span>
          </span>
          {t.description && (
            <span style={{ fontSize: 10, color: C('color-text-secondary'), whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {t.description}
            </span>
          )}
        </button>
      ))}
    </div>
  </div>
)
