// CompanionAvatar.tsx — 简易Canvasgaea光球
// 100% 对齐 ackem AIVatar 的核心视觉效果：旋转粒子球 + 呼吸脉冲 + 状态变色

import React, { useEffect, useRef } from 'react'
import { resolveThemeColorRGB } from '../utils/theme'

interface Props {
  size?: number
  /** idle / listening / thinking / speaking */
  state?: 'idle' | 'listening' | 'thinking' | 'speaking'
  emotionColor?: string
}

const N = 64 // 粒子数
const R = 0.55 // 球半径

export const CompanionAvatar: React.FC<Props> = ({
  size = 280,
  state = 'idle',
  emotionColor = '#e85388', // hex-exempt 品牌识别色（gaea 玫红）
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const stateRef = useRef(state)
  stateRef.current = state

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    canvas.width = size * dpr
    canvas.height = size * dpr
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    // canvas 需要具体色 + 半透明派生：探针解析令牌（含 color-mix，旧手拆实现
    // 不支持）为 RGB 元组，拼 rgba()——hex 后缀拼接只兼容 6 位 hex 输入，探针
    // 返回 rgb() 串时会拼出非法色被 canvas 静默忽略。解析失败回退原串。
    const rgb = resolveThemeColorRGB(emotionColor)
    const withAlpha = (a: number) =>
      rgb ? `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${a})` : emotionColor

    // 生成球面点云
    const points: { theta: number; phi: number; r: number; baseR: number }[] = []
    for (let i = 0; i < N; i++) {
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      const r = R * size * 0.5
      points.push({ theta, phi, r, baseR: r })
    }

    let raf = 0
    let t = 0

    const draw = () => {
      // v4.365 后台空转治理：隐藏时挂起绘制（聊天页常驻两个实例，idle 也别烧）
      if (document.hidden || canvas.offsetParent === null) {
        raf = requestAnimationFrame(draw)
        return
      }
      const cx = size / 2
      const cy = size / 2
      ctx.clearRect(0, 0, size, size)

      const s = stateRef.current
      const speed = s === 'listening' ? 0.6 : s === 'speaking' ? 0.8 : 0.3
      const pulse = s === 'speaking' ? 1 + Math.sin(t * 8) * 0.06 : 1 + Math.sin(t * 2) * 0.03
      const glow = s === 'speaking' ? 0.4 : s === 'listening' ? 0.3 : 0.15

      t += speed * 0.016

      // 外发光
      const grd = ctx.createRadialGradient(cx, cy, R * size * 0.3, cx, cy, R * size * 0.8)
      grd.addColorStop(0, 'transparent')
      grd.addColorStop(0.5, withAlpha(0x22 / 255))
      grd.addColorStop(1, withAlpha(glow))
      ctx.fillStyle = grd
      ctx.beginPath()
      ctx.arc(cx, cy, R * size * 0.8, 0, Math.PI * 2)
      ctx.fill()

      // 粒子
      for (const p of points) {
        // 绕Y轴旋转
        const rx = Math.cos(t * 0.5) * p.theta
        const x3 = Math.sin(p.phi) * Math.cos(rx) * p.r * pulse
        const y3 = Math.cos(p.phi) * p.r * pulse
        const z3 = Math.sin(p.phi) * Math.sin(rx) * p.r * pulse

        // 透视投影
        const scale = 1 / (1 + z3 / (size * 0.8))
        const sx = cx + x3 * scale
        const sy = cy - y3 * scale

        // z深度决定大小和透明度
        const depth = (z3 / (R * size * 0.5) + 1) / 2
        const alpha = 0.15 + depth * 0.6
        const r = 1.5 + depth * 2.5

        ctx.beginPath()
        ctx.arc(sx, sy, r, 0, Math.PI * 2)
        ctx.fillStyle = withAlpha(alpha)
        ctx.fill()
      }

      raf = requestAnimationFrame(draw)
    }

    draw()
    return () => cancelAnimationFrame(raf)
  }, [size, emotionColor])

  return (
    <canvas
      ref={canvasRef}
      style={{ width: size, height: size, borderRadius: '50%' }}
      aria-hidden
    />
  )
}
