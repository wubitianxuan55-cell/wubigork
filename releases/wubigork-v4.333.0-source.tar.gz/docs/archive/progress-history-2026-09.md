# progress.md 历史发布磁带归档（v4.170.0 及之前）

> 归档时间：2026-09-09（progress.md 瘦身归档）。
> 本文件为 `.gaea/progress.md` 的 v4.170.0 及之前历史发布磁带，**逐字节保留原文、未改写**
> （90 条版本记录 + 历史期各章节：当前状态/在途快照/长期规划/下一步执行/执行审计/纪律等）。
> 当前动态（最近 7 条版本速览）见 `.gaea/progress.md`。

## 最新发布：v4.170.0（2026-09-09）「瘦身 P3 结构版1：巨文件首批 4 拆（App/bridge/types/GanttView）」

- **线B App.tsx 拆分**（子代理）：87.3KB→46.6KB（<50KB）；palette 构建/exportConversation/JSX 布局因 App.export.test/App.palette.test 的 src 级断言（readFileSync 行级断言）刻意留壳内；11 组逻辑迁新 `gaea/app/`（useSubagentTabs/useTaskCards/usePreviewAutoFront/useDeliverables/useWorkspaceLayout/usePreviewPanel/useSessionHandlers/useAppKeyboard/useTasksAutoOpen/sessionCleanup/layout）——**deps 数组与执行顺序逐项原样**（35→16 组 effect，原 2 处 eslint-disable 保留），JSX 区与基线逐字节一致；hook 参数化后 exhaustive-deps 降级 warn，按仓库既有风格加带理由的 disable 注释（0 error 0 warning）。
- **线C bridge.ts 拆分**（子代理）：85.1KB→1.3KB；按 bindingNames 域切新 `gaea/lib/bridge/` 16 文件（10 分域接口 + `interface AppBindings extends CoreBindings, …, CharLibBindings {}` 组合 + mappings/proxy/events/http/drift）——**Proxy/懒探测/mock 回退/事件时序原样**（PowerShell 脚本按内容锚点切片非手抄，方法名 parity old=315=new 与 spaceBindings.test 锁一致）；**bindingNames 602 零变更=drift 锁不动**；公开导出 17 名 re-export 逐一同。
- **线D types.ts 拆分**（子代理）：66.4KB→1.2KB；纯类型按域拆 `gaea/lib/types/` 24 文件（shared/wire/session/context/git/trajectory/agent/shell/files/office/subagent/deliverables/resync/capabilities/memory/knowledge/settings/updater/whisper/weixin/cost/search/tasks/programming）——**220 声明零增减零重名**（列 0 锚定 155+63 与原始一致；CostSummary 成员/CostEntry/CostComponent 两条缩进接口为 +2 真值），入口纯 type re-export，135 处消费方 import 零改动。
- **线E GanttView.tsx 拆分**（子代理）：64.8KB→25.2KB；纯函数/常量/子组件拆 `schedule/gantt/` 8 文件（ganttUtil+PredEditor+CustomFieldCell+GanttToolbar+GanttTable+GanttTimeline+GanttBars+GanttOverlay），classNames/data-testid 逐字节照搬；GanttView 保留全部 state/memo/handler 组合层（深拆需 context/reducer，超「行为零变化」红线）。
- **主代理收口**：四线足迹互斥核验（git status 仅 4 M + 4 新目录）；拆分池口径 >50KB 9→5 出口判据达成；版本三处 4.170.0（sync-version.ps1）。
- **门禁**：Go 127 包 0 FAIL、vitest 2737（313 文件全绿，纯拆分零新增测试）、tsc 0（全项目）、eslint 0（全量 313+）、drift PASS@602（零绑定）、locale 0 死。
- **欠账**：P3 版2 待续=office 抽核（journal/evidence/文件读写→internal/core；office 树 29 处 import 集中 internal/AI 22 文件+根包 3 处已盘点）+ bridge 双轨退役启动（wailsjsCompat 单 shim 被 57 文件引用）+ 次批 5 巨文件（按实测 KnowledgePanel 62.2/DeliverablesPanel 57.4/XlsxPreview 56.4/ChapterPage 55.9/herdsmanTemplates 55.7）；壳内真机池/审计刀D 不变。

## 最新发布：v4.169.0（2026-09-09）「瘦身 P2 主干：双空间并列落地 + home 空间感知化 + 走查待证项收口」

- **线A rail 双空间分域+切换器**（子代理）：CommandRail 新增 space/onSwitchSpace props + rail 顶部**工位/乐园切换器**（SHELL_SPACES 驱动、labelKey/titleKey 三语、aria-pressed 激活态）；rail 主体改 getActiveMenuBoardsForSpace（shared 恒在/independent 剔除/settings inMenu:false 不在 rail）——**基线 §3.1 rail code 双入口缺陷闭合**（independent 仅 foot 单列，CommandRail.test 断言全 rail 编程入口=1）；manifests.test +4 钉 work/play 派生序、新 CommandRail.test 5 例。
- **线B home 空间感知化**（子代理）：Bento 按当前空间过滤（deriveLauncherModules(…, space)：shared 保留/编程不再上首页/settings 两空间皆在）+ 新 LAUNCHER_FEATURED（work=gaea 办公旗舰/play=chat 会客厅旗舰，bento 动态排除 featured 键防 chat 双卡）+ hero 空间 chip（ml-space-chip）+ **工位右舷「最近文档」面板**（loadRecentFiles localStorage 单源前 5、点击/Enter/空格→办公、零新 binding）；launcher.test +3。
- **线C 走查项收口**（子代理）：**knowledge 孤儿页处置**（main.tsx 移除注册+删除 pages/KnowledgePage.tsx，全仓 grep 零引用实证，tsc 全项目过=佐证；知识库=记忆中枢 KnowledgePanel 子面等价，后端 D7 保留导航侧过滤）；**刀2 G-2 基线数关闭**（GschedSummary 增 baselineCount + ScheduleFileCard「基线 N」StatChip，测试 +5）；**后端 nav 子项差异取证**（cost 后端 7 vs 前端静态 4、novel 后端 6 vs 5=有意的双源回退：normalizeManifests nav 后端优先，运行时以后端为准不改码）。
- **主代理收口**：三语字典契约键统一（shell.space.* 书房/庭院→工位/乐园、home.recentDocs×3、schedCard.baselineCount；progEntry 死键随编程瓦片移除三语删，1448 键 0 死零重复）；审计文档 docs/gaea-slim-p2-dualspace-2026-09.md 落档+基线文档 §3 重走查标注+刀2 审计 G-2/G-3 状态回写；**Go 测试加固** TestGaeaGitNotARepo（test-all.ps1 的 TMP=.tmp 仓库内→git 向上寻根误命中外层仓库的确定性假红；加固=沙箱选址检测 gitTopLevelOf 命中即改系统用户缓存区另建，双配置全绿）；版本三处 4.169.0。
- **门禁**：Go 127 包 0 FAIL、vitest 2720→**2737**（313 文件全绿 exit 0）、tsc 0、eslint 0、drift PASS@602（零绑定）、locale 0 死。
- **欠账**：壳内真机走查（rail 切换器与分域渲染/home 最近文档面板/.gsched「基线 N」布局/knowledge 无残留入口）、审计刀D 真机取证（printSvg print/拖拽/粘贴）、观察池刀3（工作台内嵌办公）待一周评估、P4 性能版随阶段推进。

## 最新发布：v4.168.0（2026-09-09）「瘦身 P2 刀1：schedule 并入办公文档面 + 命令面板入口 + 刀2 补验落档」

- **线A 刀1a**（子代理）：前端 manifests.ts schedule inMenu:true→false（藏出顶栏菜单，白名单仍含=注册即可导航）；manifests.test 菜单断言 12→11 项+not.toContain('schedule') 锁、navigateWhitelist 保持 12 项；launcher.test 静态清单 12→11 卡同步（主代理收口）。
- **线B 刀1b**（子代理）：App.tsx paletteItems 新增 cmd-schedule（Ctrl+K 直达，title 复用 schedCard.tag 三语键/icon=LineChart/run=NAVIGATE{page:schedule}）；办公文件面可达性=RecentFilesBar 单源含 .gsched→FilePreview 摘要卡既有链路零新增；App.palette.test 源级锁 3 例。
- **线C 刀2 补验审计**（子代理）：docs/gaea-slim-knife2-audit-2026-09.md——刀2 主体已提前在产（v4.121 刀12 ScheduleFileCard+v4.139 多工程），三要素 2.5/3 实证；勘出 **G-1 前后端分裂**（前端 inMenu:false 但后端 builtins.go 仍 true，normalizeManifests 后端字段优先→真机仍显示）。
- **主代理收口**：G-1 后端 builtins.go schedule InMenu:false 同步翻 + board_manifest_test 补断言；**v4.167 遗留绑定签名修复** DataPanel GaeaPickFiles()→GaeaPickFiles('zip')（wails 生成 OfficeB.d.ts 必填签名 TS2554，顺带恢复备份对话框前置过滤）；**G-5 补验** FilePreview.test 新增 .gsched 分发 2 例（合法→摘要卡/坏 JSON→回落文本）。
- **门禁**：Go 115 包 0 FAIL、vitest 2715→2720（312 文件，首跑 1 flaky 复跑清同族）、tsc 0（基线 TS2554 清零）、eslint 0、drift PASS@602（零绑定）、冒烟 200。
- **欠账**：审计刀D 真机取证、P2 走查待证项（rail code 双入口/nav 子项差异/knowledge 孤儿页）、刀2 G-2 基线计数口径关闭+G-3 真机走查、观察池刀3（工作台内嵌办公）待一周评估、双空间并列落地+home 空间感知化随 P2 主干。

## 最新发布：v4.167.0（2026-09-09）「瘦身 P2 刀0（白名单解耦）+ P0 基线落档 + 审计刀D Filters + nanoid 升级」

- **线A P2 刀0 白名单解耦**（子代理）：deriveNavigateWhitelist filter `inMenu && !isHome` → `!isHome`——**注册即可导航**，inMenu 只控菜单（v4.164 前科根治；刀1 schedule inMenu=false 依赖本语义）；settings 进白名单（隐式入口）、weixin 进 fixture 白名单（角色库→青鸟 crossSpace 深链依赖）；menuBoards 展示层零改动。
- **线B P0 基线落档**（子代理）：docs/gaea-slim-baseline-2026-09.md——§1 七面四表实测（dist 10.0MB/227、entry 1192.79kB、MemoryHub 1436.11kB 解剖、exe 46.22MB、npm 直依赖 29、>50KB 源文件 16）；§2 功能等价快照 13 板块×核心动作（纠正 knowledge 非一级导航=后端 D7 被过滤、KnowledgePage 孤儿页入 P2 待证）；§3 IA 走查（rail 12 板块平铺+foot code 区勘出双入口疑似项、默认空间=work、首页 Bento 无空间过滤、双空间并列未表达实证成立仅 3 处空间感知）。
- **线C nanoid+死代码**（子代理）：nanoid 3.3.17→3.3.18（审计实证受影响范围 <3.3.18 修正过时口径；纯传递依赖免 overrides；npm 11 写坏 lockfile→git restore+手动单条目+dry-run，diff 3 行）；GHSA-2v37-7h3g-55p8 清零（npm audit total=0）；downloadMarkdown 删（export.ts，exportAsMarkdown 保留）+ App.export.test 源级断言强化。
- **线D 审计刀D Filters**（主代理）：GaeaPickFiles(filters string) 可选扩展名过滤（Go 转 Wails FileFilter 前置系统对话框）+ 前端 bridge/mock/pickFile 传参，后置校验保留 fail-closed 双保险；pick_file_filter_test.go 7 例。
- **门禁**：Go 115 包 0 FAIL（首跑干净）、vitest 2684→2715（+3 vs v4.166）、tsc/eslint 0、drift PASS@602（Filters 签名变化方法名零变更）、vite+wails build+冒烟 200。
- **欠账**：审计刀D 真机取证（printSvg print/拖拽/粘贴）、P2 走查待证项（rail code 双入口/后端 nav 子项差异/knowledge 孤儿页）、P2 刀1/刀2 待续、双空间并列落地随 P2 主干。

## 最新发布：v4.166.0（2026-09-09）「瘦身 P1 快赢：轮子四刀全收 + 审计刀B/C + locale 死键 + 依赖验活」

- **W1 字节+双门收口**：新中立层 gaea/lib/bytes.ts（b64ToBytes 唯一解码规范，全仓 ~20 处手搓 atob 循环收口）+ gaea/lib/saveFile.ts（downloadBlob/dataUrlToBlob/saveExportBlob 从 schedule/exportArtifact 迁入，schedule 侧 re-export 零改动，防域倒挂）；inShell 判定合一=pickFile.inShellEnv 全仓唯一规范（exportArtifact.inShell 薄委托）。
- **W2 slug×5 收敛**：新 internal/gaea/strutil/title_slug.go（TitleSlug：小写/保留 Unicode 字母数字/其余折叠 '-'/60 rune 截断/entry 兜底）；cost.SlugName（保留 cost 兜底语义）/knowledgeimport.slugName/app.slugFromTitle/modelengine.customSlug（保留 ASCII 白名单前置）/controller_memory.slugifyName（界面文案）并入；legacy golden matrix 测试钉死五旧实现逐项对照。
- **W3 novel diff 收口**：DiffReview 手搓弱贪心行 diff → lib/diff.ts LCS（贪心 3 行窗口漂移边界用例锁死，空串=0 行口径不劣化）。
- **审计刀B（下载类×4）**：ImageGen 两处下载、NovelSetting 导入导出、办公 md 分支并入 exportConversation 统一交付管线（App.export.test 源级回归锁）。
- **审计刀C（上传类×3）**：ControlPanel/VisionTrial/SkillModal 壳内走 GaeaPickFiles+扩展名后置 fail-closed，浏览器回退原 input。
- **locale 死键清零**：scripts/slim-locale-deadkeys.mjs（1445 键 0 死，en/zh/zh-TW 同步删）；依赖验活：26 直依赖逐个计数，存疑名单 gsap/docx-preview/unist-util-visit 洗清；codemirror 顶包死重移除（源码零引用），@codemirror/state|view|commands|language 四子包显式化（npm 11 uninstall 再次写坏 lockfile——git restore+手动删条目+dry-run 验证）。
- **门禁**：Go 115 包全量绿（首跑 1 flaky 复跑清）、vitest 2684→2712（+28，311 文件）、tsc/eslint 0、drift PASS@602（零绑定）、vite build 过。
- **欠账**：审计刀D（真机取证+Filters）、P0 基线快照表入档、nanoid 升级刀、downloadMarkdown 死代码下轮清。

## 最新发布：v4.165.0（2026-09-08）「拍板落档 + 壳内残留审计刀A：P0×2 修复」

- **拍板**：收敛计划 §0 两项已决——路线 A=终极个人工具（产品化=期权不作承诺）；LICENSE=私有 All Rights Reserved（根目录 LICENSE + README 许可段 + AGENTS 长期规划回写）。
- **刀A**：①新中立层 gaea/lib/pickFile.ts（inShellEnv/pickFileAsFile/pickImageAsDataUrl，只 import ./bridge 防倒挂；GaeaPickFiles 无过滤器→扩展名后置校验 fail-closed）；②BaselinesPanel 签证台账 CSV 导出改 saveExportBlob（v4.162 漏了同域邻居）；③角色库「添加参考图」壳内接 pickImageAsDataUrl（此前无替代路径卡死 img2img 立绘），浏览器回退保留。红→绿全链取证（修复前 GaeaPickFiles 0 次调用）。
- **门禁**：vitest 2678→2684（+6，全量首跑全绿——v4.164 抗抖见效）、Go 0 FAIL、tsc/eslint 0、drift PASS@602、build 45.4s+冒烟 200。
- **欠账**：审计刀 B（下载类×4）/C（上传类×3）/D（真机取证+Filters）、nanoid 升级刀。

## 最新发布：v4.164.0（2026-09-08）「收敛计划 W1 卫生刀」

- **立项**：docs/gaea-convergence-plan-2026-09.md（收敛期叠加层：卫生/外化/止血刀+节奏改革）；三线并发子代理（A 供应链+抗抖/B 潜伏 bug/C 只读审计）足迹互斥，主代理收口。
- **内容**：①package-lock 入库+CI npm ci（npm 11 lockfile 缺漏坑→npm 10 生成，701 包）；②vitest testTimeout 15s+CI 前端 flaky retry（动因=同机满并发 32 例假红实测）；③修 DeliverablesPanel「回办公面板重新规划」失效（NAVIGATE 过期板块 id office→gaea 被白名单静默丢弃，v4.121 潜伏 bug 销项，+1 先失败回归锁）；④WebView2 残留审计落档 docs/webview2-shell-audit-2026-09.md（P0×2/P1×7/刀序 A-D）。
- **门禁**：Go 全量绿（116 包）、vitest 2677→2678（复跑全绿）、tsc/eslint 0、drift PASS@602（v4.163 文案 603 系口径出入）、build+冒烟过。
- **欠账**：nanoid high 升级刀、审计刀 A-D、LICENSE/性质拍板。

## 最新发布：v4.163.0（2026-09-08）「gaea 长期日志机制」

- **机制**：按日分文件 <DataRoot>/logs/gaea-YYYYMMDD.log（保留 365 天+1GB 兜底+启动清理）；旧 gaea.log 迁入 legacy；启动头带版本、Shutdown 记时长；前端诊断自动汇入；GaeaOpenLogsDir 绑定+设置→数据「打开日志目录」按钮。
- **附带**：修 v4.162 缺陷——ReadFileB64/SaveFileAs 漏 facade 委托运行时不可达（OfficeB 补委托）；规约=App 新增绑定必须加门面委托+壳内实测可达。
- **门禁**：Go logging_test ×3、app 包绿；vitest 2677、tsc/eslint 0、drift PASS@603、build+冒烟过。

## 最新发布：v4.162.0（2026-09-08）「进度计划导入导出壳内修复：原生对话框链路」

- **根因**：Wails 壳内 input[file] 不弹框、`<a download>` 不落盘（浏览器正常故测试不可见）；菜单/下拉正常。分层排除（浏览器 dev/prod ✓ 壳 ✗）+ CDP 受信任点击 + EnumWindows 探测定位。
- **修复**：新绑定 GaeaReadFileB64+GaeaSaveFileAs（599→601）；导入四路=PickFiles+ReadFileB64 还原 File 喂原解析器；导出五路=saveExportBlob 统一另存为；浏览器全回退原机制。
- **门禁**：vitest 2671→2677、tsc/eslint 0、drift PASS@601、build+冒烟过；壳内实测原生「选择文件」对话框弹出 ✓。
- **欠账**：window.print 壳内行为未走查；全 app input[file]/a[download] 残留扫尾。

## 最新发布：v4.161.0（2026-09-08）「双代号对齐标杆二期：工程标尺 + 图面语言」

- **内容**：①时间坐标框架进视图（aoaRuler.ts 纯函数：工程日/月/日+星期/工程周,月界竖线贯通;手动布局不画）②波形拆独立路径着绿（segsToPathSplit,segsToPath 兼容包装,视图/导出同口径）③关键红圈/名称工期蓝/非关键加深④修 v4.160 打包阶梯化（改按重心行道 gRow 打包）。
- **目检**：esbuild 隔离挂载 AoaView+Edge 无头截图——实锤打包阶梯化与标尺对齐两处测试盲区。
- **门禁**：vitest 2671→2677、tsc/eslint 0、build 过。
- **欠账**：汇总线双线样式观察池；标尺真机观感挂池。

## 最新发布：v4.160.0（2026-09-08）「双代号分级横幅：一级/二级分区布局」

- **起因**：用户以重庆干休所网络计划 PDF 为标杆反馈「一级、二级没有分级展示，比较混乱」。解析标杆=每分部一条横幅：汇总线走带顶通长线（分部名挂线上）、二级工序带内排布、跨分部虚工作竖向衔接、交替底纹分带。
- **落地**：buildAoa band 归属+带内保序打包+行距自适应接打包行数；summarySegs 汇总线三段正交（视图/导出同口径+底纹垫底）；**跨横幅不合并事件**（FS/SS 限同带+非首横幅无前置自设开始事件）——任务边不再跨带压字，时间参数/关键判定零变化。
- **门禁**：vitest 2665→2671、tsc/eslint 0、build 过；SVG 生成+Edge 无头截图逐带目检。
- **欠账**：真实计划横幅观感真机走查挂池；工程标尺四行视图侧未加（按需另立小刀）。

## 最新发布：v4.159.0（2026-09-08）「进度计划画布手感：滚轮缩放 + 双代号行距自适应」

- **起因**：用户实测反馈（附截图）：画布无法滚轮缩放；双代号「行距太小全挤在一起、又矮又长严重不协调」。根因=三块画布零 wheel 处理；AOA_ROW_H 74px 扣掉节点标注只余 18px 行隙+行距不随时标宽自适应（低并行长计划天然 20:1 扁条再被 0.5 适配下限压扁）。
- **①滚轮缩放**：共用钩子 wheelZoom.ts（光标锚缩放+Shift 原生横移;锚定走 layout effect 回写滚动量;原生 {passive:false} 监听）接 AoaView/PdmView；横道 Ctrl+滚轮缩日宽（普通滚轮保持滚动行,dayG 锚定）。图例加提示+flex-wrap。
- **②双代号松绑**：ROW_H 74→112+AOA_ASPECT_MAX=7 自适应放大（clamp 2×,波形语义不变）；通道层距 12→16 治标注叠压；PdmView 补 jsdom 0 宽适配防护。
- **门禁**：vitest 2658→2665、tsc/eslint 0、build 过；Go 仅版本常量（go build+app 包绿）。
- **欠账**：滚轮手感/自适应行距真机走查挂池；节点尺寸随行距等观感优化待反馈。

## 最新发布：v4.158.0（2026-09-09）「AI 组价复核闭环：确认留痕 + 拆解合理性校验」

- **方向**：造价板块（路线图最可防御垂直）。前置两路调研子代理钉出「AI 组价 v4.2 已在产、roadmap 欠账描述过时」——不重做已产能力,销真缺口;现状基线落档 docs/gaea-cost-domain-survey-2026-09.md。
- **①确认留痕**：SchemaV16 快照完整组价视图(价格带/人材机/证据链/校验),Records 绑定回看,条目详情「组价依据」折叠区;②**拆解校验**：CheckComposeComponents 纯函数(金额一致性/非正值/合计偏差)进响应,面板徽标,校验随留痕入档。
- **门禁**：Go 全量绿(+18)、vitest 2650→2658、tsc/eslint 0、drift PASS@599、版本三处 4.158.0、build+冒烟过。
- **欠账**：造价刀路池见 survey 文档;组价依据区 mock 恒空真机走查挂池。

## 最新发布：v4.157.0（2026-09-08）「Office 编辑链一致性小刀：docx 证据链补齐 + pptx 面板字符级对比」

- **docx_apply 补证据链**（pptx 设计 §6 推荐项）：快照+Journal 对齐 pptx/xlsx 口径，ApplyTrackedReplace 语义零改动；accept=true 同款、拒绝分支天然回滚不加——docx 编辑从此可经版本时间线回滚。
- **PptxEditPanel 对比区升级 ChangesDiff**：句级 LCS 归一 DiffRow，changed 对改蓝配对+字符级高亮；删句级降级标注。
- **门禁**：Go app 包全绿(+3)、vitest 2650、tsc/eslint 0、drift PASS@598、版本三处 4.157.0、build+冒烟过。
- **欠账**：pptx 刀2 真机走查挂池；刀4 待反馈；Verifier 通道 B 对 docx_apply 复核口径未动。

## 最新发布：v4.156.0（2026-09-08）「pptx 真编辑刀2+刀3：编辑面板 + 版本对比（Office 三件套编辑闭环）」

- **起因**：用户拍板「进度计划暂时到此,优化迭代其它方向」。侦察发现 pptx 编辑设计（docs/gaea-pptx-edit-design-2026-09.md）刀1 数据层早在 v4.109.0 落地,刀2/刀3 因主线转入进度计划而搁置——接续刀序。
- **刀2 编辑面**：Go 新绑定 `GaeaPptxSlideText`（段落全文,大纲截断预览不可当 target）;PptxOutline 两级导航;PptxEditPanel（P1 Plan→Apply:段落单选→预设动作/指令→双栏对比→应用→新预览刷新）;FilePreview 挂面板;桥接六处同步。
- **刀3 对比**：pptxTextDiff（页对齐+段落 LCS,降级结构化）;versionCompare kind:"pptx"（取数走 AttachmentDataURL,Preview 对 pptx 是 PDF 缩略拿不到字节）;VersionTimeline 第四种 kind 收口 unsupported。
- **实施**：三线并行（Go/刀2/刀3,足迹互斥）;主代理 gen_bindings+集成门禁。
- **门禁**：Go 全量绿(+3)、vitest 2617→2650(+33)、tsc/eslint 0、drift PASS@598、版本三处 4.156.0、build+冒烟过;flaky=TestCreateChapter_SameChapterConcurrentRejected TempDir 清理竞态(复跑绿)。
- **欠账**：真机走查挂真机池(mock Preview 无 pptx 分支);刀4 修改队列泛化待反馈拍板;docx_apply 证据链另立小刀;面板字符级高亮未接(句级诚实降级)。

## 最新发布：v4.155.0（2026-09-08）「双工期欠账放开：SS/FF/SF×cd 全搭接（§3.2.5 重推，零不动点）」

- **起因**：双工期设计 §6 欠账池首项——v4.150 刀1 曾收窄 cd 任务仅 FS 搭接（fail-closed），§3.2.5 放开矩阵标注「实施前重推」。观察池三项全绑真机，本项为唯一不绑真机的既排队列。
- **重推结论**：原矩阵四格「需不动点」系 wd 代数形误判。FF/SF-to 用新原语 cdEarliestStart 单调逆查（fwd 单调不减有平段，逆像确定）；SS/SF-from 直接 ls 下界（约束本就落在开始上，不经 lf+durFrom 换算）+后继 effLf=cdToEf(ls) 诚实传播。八格全放开，单趟拓扑零迭代，wd 路径逐位不变。
- **实施**：并发双子代理（Go 线=引擎+Validate 拆闸+文案+golden 扩例；TS 线=引擎镜像+UI 文案+测试），足迹互斥，golden fixture 归 Go；主代理先钉六张锚点表+用例 A-E 契约再派线。两侧独立发现契约用例 D 的 SS/FS 数字笔误并收敛同组修正值，镜像无损。
- **拆闸**：Go Validate「仅 FS」/引擎防御拒绝/analyze 防御 finding 三处全删，cd 余四闸不动；文案四处同步（锚点锁 37 不变）。
- **门禁**：Go 全量绿（+2 函数/5 子用例）、vitest 2601→2617（+16）、tsc -b/eslint 0、drift PASS@597、版本三处 4.155.0、build+冒烟过；设计文档 §3.2.5/§6 回写。
- **欠账**：双工期欠账池剩=导入任务日历转 cd 迁移助手/斑马导入口径探测/等效跨度灰显双读数（按需）；观察池不变（全绑真机）。

## 最新发布：v4.154.0（2026-09-08）「MPP 导入支持 Project 2013+ 变体（真机样本驱动修复）」

- **起因**：用户真实工程文件（重庆干休所总进度计划，Project 2013+）被 ParseMpp 拒收（缺 CompObj）；强拆后系统性错乱（27 空名/全 0 工期/全里程碑）。
- **五处漂移修复**（字节级取证）：无 CompObj→目录编号判版；工期 @42→@84；Var 回链键 uid→ID；parentUID 失效→大纲层级 @172+层级栈；里程碑位失效→零工期语义。
- **结果**：38 任务/8 分组/42 搭接/总工期 136 天零缺名，CPM 自洽；门控样本测试落档（clones/mpp2013/），旧三样本零回归。
- **诚实降级**：2013+ 资源/分配键位未钉死，宁缺勿错暂不解析（观察池）。
- **门禁**：Go 全量绿、版本三处 4.154.0、drift PASS@597、build+冒烟过；前端零改动。

## 最新发布：v4.153.0（2026-09-08）「双工期口径刀4：mspdi 互通」

- **导出**：cd 叶任务 DurationFormat=8 + PT{自然日×24}H；wd 恒 7 逐位不变；分组恒工作日口径。
- **导入**：Format 8 → cd（分钟÷1440）；其余/未知格式 ÷480 宽松容错；里程碑/汇总不标 cd；parseDurationMinutes 按格式分流。
- **门禁**：vitest 2596→2601（+5：roundtrip 不丢口径不变值等）、tsc -b/eslint 0、drift PASS@597、版本三处 4.153.0、build+冒烟过；Go 零改动。
- **双工期四刀全收官**（模型引擎/agent/板块 UI/mspdi）；拍板池三项全部收官。
- **观察池**：真机 Project 往返走查（本机未装 Project——PT×24 序列化钉死/WPS/斑马行为；真机通过前 Export 端兼容性视为待验证，Import 端失真修复收益确定）。

## 最新发布：v4.152.0（2026-09-08）「双工期口径刀3：板块 UI」

- **工期列单位 chip**：cd 行常显/wd 行 hover 浮现（静态视觉零变化）/分组与里程碑无入口；点击循环 wd↔cd 不换算数值；工期列宽 48→84。
- **拖拽缩放自然日回写**：resizeToNaturalDuration（右缘=新 ef 工作日吸附，回写自然日差=所见即所得）；右缘起点改 dayNo(ef) 顺带修 cd 条形画过宽；浮标「日历 X → Y 天（自然日）」。
- **口径透明**：条形悬停等效工作日跨度（只读）；前锋线 dur 换源 ef−es；检查器工期行显等效；状态栏「（工作日）」；单/双代号 cd 标「(日历)」+图例注记。
- **门禁**：vitest 2589→2596（+7）、tsc -b/eslint 0、drift PASS@597、版本三处 4.152.0、build+冒烟过；Go 零改动。
- **待续**：刀4 mspdi 互通（DurationFormat 8 导出导入，绑真机池，不真机不发布）。

## 最新发布：v4.151.0（2026-09-08）「双工期口径刀2：agent 通道」

- **对话链路打通**：ops patch_task 增 durationUnit 指针三态（空串 no-op 同 Mode；单位分支先于工期分支=工期词尾随新单位）；upsert_task 直带 cd（五闸校验）；回执口径词「工期口径→日历天（自然日定时）」「28 日历天」。
- **对拍扩容**：Go/TS golden fixture +12 例（49→61，含 cd 全链 upsert+FS+基线）；opsSim.golden.test.ts 63/63 过。
- **三工具**：get 带 durationUnit（wd 不出）；analyze 增 cdTasks（自然日数/等效跨度/锚点日期）+ cd 非 FS 防御发现；apply 回执「总工期 X 天（工作日）」。
- **技能/compact**：cd 纪律入 schedule-edit（自然日定时才标 cd/仅 FS/成本按等效跨度），锚点锁 35→37；compact 三工具同步。
- **门禁**：Go 全量绿（+3）、vitest 2576→2589、tsc -b 0、drift PASS@597、版本三处 4.151.0、build+冒烟过。
- **待续**：刀3 板块 UI（工期列单位切换+chip+悬停等效提示+拖拽 resize 换算）→刀4 mspdi 互通（绑真机池）。

## 最新发布：v4.150.0（2026-09-08）「双工期口径刀1：任务级工期单位（模型+引擎）」

- **拍板池收官项启动**：docs/gaea-schedule-dual-duration-design-2026-09.md 推荐项全采纳——`task.durationUnit?: 'wd'|'cd'` 缺省 wd 零迁移零行为变化；cd=日历天（养护/干燥类自然日定时，mspdi DurationFormat 8 同语义）。
- **引擎**：cdToEf（ceil 吸附，26/27/28cd 同 ef 吸附折叠）/cdLatestStart（镜像回退+有界双侧校正，fwd(ls)≤lf<fwd(ls+1) 钉死）纯函数对；cpm 可选 ctx（Go 双入口 ComputeCpmCal/ComputeCpmPlanCal）；快路径铁律=无 cd 逐位一致；缺开工日期/cd 涉非 FS 均 fail-closed（日历缺省回落周一~五=对设计 §3.2.2 的细化）。
- **成本/基线换源**：work 分配与基线 dur 改用 cpm 行等效工作日跨度 ef−es——养护期周末不记工日（28cd=20 工日计费），wd 恒等有 pin；倒排/摘要卡零改动。
- **校验**：Go Validate 五闸（枚举/分组行/里程碑/3650/FS-only）+normalizeProject 容错回落；TS↔Go 同批镜像用例（TS +26 / Go +10）。
- **门禁**：Go 全量绿；vitest 2550→2576；tsc -b 0；drift PASS@597；版本三处 4.150.0。
- **待续**：刀2 agent 通道（patch_task.durationUnit+analyze cdTasks 清单+技能条款）→刀3 板块 UI（工期列单位切换）→刀4 mspdi 互通（绑真机池，不真机不发布）。

## 最新发布：v4.149.0（2026-09-08）「diff 确认卡刀D：ops 通道投影模拟器 + Go/TS 对拍收官」

- **收官**：diff 确认闭环设计四刀全落地（A 后置回滚 v4.146 / B project diff 卡 v4.147 / C 引擎强制 v4.148 / D ops 投影对拍本刀）。
- **opsSim.ts**：Go ApplyOps 逐语义 TS 镜像——深拷贝顺序应用 fail-closed；指针三态/零值语义/remove_task 级联/set_links 替换/set_meta 口径/auto_chain/set_baseline/资源操作全对齐。
- **对拍主阵地**：internal/schedule/ops_golden_test.go 生成校验 frontend/src/schedule/ops_golden.fixture.json（49 例=21 成功+28 失败；`-update-golden` 重生成）；opsSim.golden.test.ts 双跑逐例比对——一侧漂移炸对端，50/50 过。
- **卡体**：ops 通道缺省路径真 diff 投影（「ops 投影」标注）+三级诚实降级；project 标注「文件实况对比」。
- **门禁**：Go 全量绿；vitest 2499→2550（+51）；tsc/eslint 0；drift PASS@597；版本三处 4.149.0；build+冒烟过。
- **坑**：jsdom import.meta.url 非 file 协议→resolveJsonModule+JSON 直接导入；canonical 丢空数组（Go omitempty vs TS []）；control 同包测试 strPtr 重名→gStrPtr；if 头复合字面量加括号。
- **闭环全貌**：AI 改计划=事前 diff 卡（project 整量强制逐条+ops 投影）→批准落盘→回执核对「成功≠正确」→事后工具卡/变更 tab 一键回滚。

## 最新发布：v4.148.0（2026-09-08）「diff 确认卡刀C：project 整量替换引擎强制逐条确认」

- **闸门**：controller_approval.go——schedule_apply project 通道（args.project 非空）在 hardAskSet 之后、auto 快捷之前分支 → requestApproval(alwaysPrompt=true)：任何级别（含 auto/yolo）逐条弹卡、不读不写 granted；ops 通道维持现状。
- **可读 subject**：scheduleApplyProjectSubject=解析 args.project→Project.Analyze()→「整计划替换（目标文件）：N 项工作，总工期 Y 天，关键 K 项」；CPM 不过标注批准也将被拒；解析失败诚实降级。
- **前端**：scheduleApplyIsProjectChannel（applyDiff 镜像）→ ApprovalModal project 卡三钮形态（hardConfirm 统一分支，快捷键 3/5 调整）；ops 五钮不变。
- **纪律同步**：schedule-edit Body 增「确认与回滚」分节（逐条批准/禁止原样重发/超时=拒绝/以回执为准/回滚入口），锚点锁 31→35；scheduleApply.Description+compact.go 同步。
- **门禁**：Go 全量绿（+5 闸门用例：ask 弹/auto·yolo 仍弹/禁会话记忆双弹/ops ask 弹+auto 静默/subject 可读与降级）；skill 锚点过；tsc/eslint 0；vitest 2499；drift PASS@597；版本三处 4.148.0；build+冒烟过。
- **待续**：刀D=simulateOps TS 镜像（12 op 对齐 Go ApplyOps）+Go/TS 对拍单测（设计最大风险对冲主阵地）。

## 最新发布：v4.147.0（2026-09-08）「diff 确认卡刀B：schedule_apply 审批卡结构化 diff 预览」

- **设计**：diff 确认闭环刀B（§2.2）。ask 级审批卡本就弹出，此前只有 path 一行字；本刀卡体升级为结构化 diff——批准前先看清改动与工期/成本影响。
- **纯函数层 schedule/applyDiff.ts**：`diffProjects`（两侧 normalize 后纯比较）任务 id 键控字段级增删改/搭接按 to 分组入边比对/资源级联标注/分配增删改/meta 四项/汇总行（双方 CPM+成本+倒排+基线漂移预览）；after CPM 不过=「引擎将拒绝」预览 fail-closed；`scheduleApplyArgsOf` 宿主取 running 工具卡 args（放纯函数层守 react-refresh 单组件导出）。
- **卡体**：ScheduleDiffCard + ApprovalModal 新 prop `scheduleApplyArgs`（approval.tool==="schedule_apply" 替换通用卡体；双宿主各传 items）；降级三级=非缺省路径/读取失败/ops 通道（simulateOps=刀D）；「预览数字，落盘以回执为准」；60 行截断。
- **门禁**：tsc -b/eslint 0；vitest 2483→2499（+16）；drift PASS@597（零绑定）；版本三处 4.147.0；build+冒烟过。
- **坑**：CpmResult 从 types 导入（cpm.ts 不再出）；SchedCalendar 字段 holidays 非 exceptions；全角空格踩 no-irregular-whitespace；i18n schedDiff.* 键有意识不做（域内容层 zh-only §405）。
- **待续**：刀C（Go approvalSubjectFor project 分支=整计划替换 hardAsk 化+schedule-edit 锚点锁 31→N）→刀D（simulateOps+Go/TS 对拍）。

## 最新发布：v4.146.0（2026-09-08）「对话改计划回滚闭环（diff 确认卡刀A）」

- **启动**：v4.125 落档的 diff 确认闭环设计（docs/gaea-schedule-diff-confirm-design-2026-09.md）按刀序启动——刀A 后置回滚补全（设计原文：即使确认卡不做也独立成立）。用户连续「继续」按「按建议刀路推进」理解。
- **变更 tab**：WRITE_TOOL_NAMES/WRITE_ONLY_TOOL_NAMES +schedule_apply；extractChangedPaths(args, tool?) 缺省 path 回填当前计划；buildChangeDiff 显式降级说明。
- **工具卡**：新组件 ScheduleApplyRollback——schedule_apply done 后常驻「回滚本次」（Journal 按 target 匹配最新带基线记录→GaeaRollbackRecord；无匹配整行不渲染；标题带 turn）。
- **门禁**：tsc -b/eslint 0；vitest 2477→2483（+6）；drift PASS@597（零绑定）；版本三处 4.146.0；build+冒烟过。
- **待续**：刀B（diffProjects 纯函数+ScheduleDiffCard+ApprovalModal 变体，纯前端）→刀C（Go approvalSubjectFor project 分支+锚点锁 31→N）→刀D（simulateOps TS 镜像+Go/TS 对拍）。
- **坑（重犯）**：文档头插新刀条目吃掉上版标题（第三次）——「old_string=上版标题」式插入必须把标题带回 new_string 尾部。

## 最新发布：v4.145.0（2026-09-08）「工程复制（另存为）：管理面板第四动作 · 签证迭代底座」

- **销项**：v4.139 多工程「欠账转移」候选池（该池三项清算：导入为新工程=v4.144 已销；工程复制=本刀；基线跨工程直接复制=裁定不做——不同源文件 id 无对应，按 id 漂移全噪音；跨工程资源池=设计 §7 维持不做）。
- **Go**：`GaeaScheduleProjectCopy(rel,name)`——Load 全套校验→SafeSlugName 去重→深拷贝仅改 name 落新文件（基线槽/AOA 布点/日历随行）→索引显式登记；指针不动（文件级动作同归档）；回执=ScheduleProjectsResult。
- **store**：`copyProject`——当前工程先 flushDirty（拷已存盘内容）；回执列表直接入缓存；失败只落 syncError 返回 false。
- **UI**：管理面板每行「复制」→弹窗默认「-副本」名、空名禁用、失败弹窗不关。
- **接线**：绑定面 596→597（gen_bindings 门面+bindingNames 手工同步+bridge 双向断言+spaceBindings 锁 310+mock+api 窄接口）。
- **门禁**：tsc -b/eslint 0；Go 全量绿（+TestGaeaScheduleProjectCopy）；vitest 2472→2477（+5）；drift PASS@597；版本三处 4.145.0；build+冒烟过。
- **浏览器 DOM 走查补记（2026-09-08，v4.141~145 首次真浏览器走查，零缺陷）**：mock 模式七项全过——①导入菜单四项结构；②工程复制全链（面板行→弹窗默认「-副本」名→改名确认→副本行入列表→弹窗关闭）；③多工程切换器（副本切换生效，信息条随动）；④AOA 渲染（147 路径/45 文本，15 项工作+141 天与 20 行=5 分组口径一致）；⑤缩放步进 ×1.2（50→60→72%）、全览钳 0.3%、缩小 25%（v4.142/143 语义实证）；⑥横道列头显式宽（160/44px，v4.142 修复实证）；⑦mock 保存链通（状态栏「已保存 HH:mm」；不带 ?mock=1 会走 HTTP 代理报 404 保存失败——非 bug，走查必须带参数）。一次性 scrollTop=128 空画布现象无法复现（干净挂载恒 0），判定走查自动化杂散滚轮。**走查方法论（可复用）**：`?mock=1` 必须；用 `window.dispatchEvent(new CustomEvent("navigate",{detail:{page:"schedule"}}))` 直达板块（首页能力矩阵卡片坐标点击不稳）；IAB 里 role 定位 click 恒超时（页面持续重渲），改 `evaluate`+`data-testid` 原生 `.click()`；React 受控输入走原生 setter+input 事件；antd 弹窗关后 DOM 残留（wrap display:none），存活判定必须查 computedStyle；走查前 `localStorage.clear()`+reload 防跨版本残留。
- **坑**：①Edit 工具多行替换把「注释+签名行」当 old_string 而 new_string 漏带签名=函数被腰斩（本刀两次）——替换后必须核对函数完整性；②bindingNames.ts 的 `-names` 模式只打印清单不写文件，需对照手工按字典序插入。
- **观察池余**：E1 负数对称哨兵（动逆推时按 ProjectLibre E1 准绳收口）· 刀3 list_projects 真机实测 · 用户截图反馈驱动的新对标项。

## 最新发布：v4.144.0（2026-09-07）「导入为新工程：三路导入安全化 · 非破坏口径」

- **销项**：观察池「mspdi 导入为新工程候选池」。此前 MPP/XML/Excel 三路导入一律 `importProject` 原地整体替换当前工程（防抖落盘后原文件被静默覆盖，仅撤销兜底）。
- **store**：新动作 `importAsProject`（模块函数 importThenSwitch）——名字空兜底「导入工程」→ createThenSwitch（slug 去重+登记索引+自动切指针+重水合）→ importProject 内容替换 → flushDirty 立即落盘 → refreshProjectsCache；slug/文件内容/列表摘要三处同源一名；Create 失败=返回 false+syncError+当前工程原状（fail-closed）；成功不触碰原工程文件。
- **页面**：「导入为新工程…」扁平主入口按扩展名分发（xml/xlsx/xlsm/mpp，文件名兜底工程名）；三路替换入口显式标注「导入 X 替换当前工程…」（TemplatesPanel Popconfirm 不变）。
- **门禁**：tsc -b/eslint 0；vitest 2467→2472（+5：store 成功链/名字兜底/Create 失败、页面 MPP 分发/不支持格式；全量复跑一次绿——ProgrammingPage 并发 flaky 单跑复现过 1 例，与本刀无关）；drift PASS@596；版本三处 4.144.0；build+冒烟过（/api/health 200）。
- **坑**：①versioninfo.rc FILEVERSION 逗号位 v4.140 起停在 4,139,0,0 四版未随动（字符串位正常）——提版必须跑 sync-version.ps1 而非只 sed 字符串位；②createThenSwitch 吞错只置 syncError，importThenSwitch 判成败只能比对 currentPath；③antd 子菜单 jsdom 难测——菜单用扁平四项不搞 submenu。
- **观察池余**：E1 负数对称哨兵（动逆推收口，需拍板）· 刀3 list_projects 真机实测 · 多工程资源池（设计先行）。

> 最后更新: 2026-09-06（**当前状态：v4.126.0「本地模型使用：切换器模型粒度化+换模预估按目标模型全覆盖」已发布（588 零变更；GaeaModelSwitchEstimate 仅扩展签名）**——刀1=GaeaModels 按引擎展开全部对话模型（本地组置前/ModelInfo +local·status·label/空清单回退 "(默认)"/非 llm 过滤）+GaeaSetModel("engine/model") 精确设默认模型（fail-closed）+前端分组「本地」标+运行徽标+展示名；刀2=换模预估按目标模型全覆盖诚实化（herdsman 目录/ollama 原生 /api/ps+/api/tags :latest 归一/modelhub Studio loaded；未加载不假报秒数、不可达 unknown——旧「非 herdsman 恒 hot」T5-3c 旧账销账）；vitest 2216（+2）；?mock=1 走查六项 DOM 全过（坑：antd confirm 关闭后 DOM 残留 wrap display:none）；真机池+本机 Ollama/Studio 实测预估与精确切换端到端；**前版：v4.125.0「摘要卡设为当前计划+拍板池三设计文档落档」已发布（588 零变更）**——摘要卡非当前计划一键复制为当前计划（fail-closed 通道+即时回读，循环依赖不显示入口）；**拍板池三项设计文档齐备待用户拍板**：diff 确认卡（混合分级确认/4 刀/8 项，docs/gaea-schedule-diff-confirm-design-2026-09.md）、双工期口径（durationUnit 标记/4 刀/9 项，docs/gaea-schedule-dual-duration-design-2026-09.md）、多工程（每文件一工程+索引+Go 指针/绑定 590 或零新增备选/8 项，docs/gaea-schedule-multi-project-design-2026-09.md）；vitest 2214；**下一步：等用户拍板三方案即进实施；资源成本刀4 绑真机池；AOA 刀2 观察后拍板；真机池：真机端到端+联动跳转+AOA 拖拽手感**；v4.124.0「资源成本刀2+刀3：agent 通道+板块 UI」已发布（588 零变更；并行双线子代理实施+主代理合并走查）**——刀2=ops 扩资源四操作+patch_task.fixedCost/apply 回执强制 totalCost/get costs/analyze 成本叙事+未定价 finding/compact 同步/技能分节（锚点锁 31）；刀3=资源工作表弹层+甘特成本列+任务资源 Popover+状态栏总成本段（无数据诚实隐藏）/removeTask 级联删分配（Validate 接缝缺陷先行修复）；vitest 2213（+19）、Go +18；?mock=1 全链走查贯通（录入→挂分配→成本列→状态栏→自动保存）；新 mock 场景 ?mock=calm；**欠账：刀4 mspdi 绑真机池（不真机不发）**；AOA 刀2 观察后拍板；拍板池：diff 确认卡/双工期口径/多工程；真机池：真机端到端+联动跳转+AOA 拖拽手感**；v4.123.0「AOA 手动布局刀1」已发布（588 零变更；按 docs/gaea-schedule-aoa-manual-layout-design-2026-09.md 推荐拍板项实施：混合锚定/pins 内嵌/mode 不入文件/半格吸附/agent 不暴露布局）**——AoaNode.anchor 锚点键（事件业务身份跨拓扑稳定）；aoaLayout.ts 纯函数（snapPt/normalize/applyPins/prunePins）；gsched.json 内嵌 aoaLayout.pins（Go 结构 pass-through，维持无 aoa.go）；AoaView 拖拽布点+布局 Segmented+重置（刀9 纪律同构）；布局=展示层 buildAoa 口径零变更；TS +15 Go +3；vitest 2194；**坑：zustand selector 内 ??{} 新引用→无限重渲（派生放渲染体）；setState updater 内禁副作用**；vitest flaky 新增 CostProjectsView（负载型）；欠账：?mock=1 拖拽走查+真机手感；刀2 对齐辅助线观察后拍板；资源成本刀2 agent 通道→刀3 UI→刀4 mspdi（绑真机池）；拍板池：diff 确认卡/双工期口径/多工程**；v4.122.0「资源成本刀1：模型+成本rollup引擎+持久化」已发布（588 零变更；按 docs/gaea-schedule-resource-cost-design-2026-09.md 推荐拍板项实施：元/工日/fixed-units 简化/材料固定总量/分组行禁挂）**——types 双侧同构三类资源+分配+fixedCost（旧文件零迁移）；cost.ts/cost.go rollup 镜像（循环 fail-closed/悬空跳过/到分舍入）；前端 normalize 容错+Go Validate fail-closed（分组行禁挂分配）；TS +13 Go +14 镜像测试；vitest 2179；**AOA 手动布局刀1（docs/gaea-schedule-aoa-manual-layout-design-2026-09.md，pin 混合锚定）顺序实施中（与资源成本共用 SchedProject schema 不并行）**；资源成本后续：刀2 agent 通道→刀3 UI→刀4 mspdi（绑真机池）；拍板池：diff 确认卡/双工期口径/多工程；真机池：真机端到端+联动手感**；v4.121.0 刀12 走查完成+两大设计方案落档待拍板（2026-09-06 傍晚）**——①?mock=1 DOM 走查三件套全过（摘要卡 chips 与横道状态栏同口径 141 天/15/13；原始 JSON 开关；周报一键 toast+气泡+回合执行中；跳转双向互通；冷启动首挂载复验绿）；**走查发现非缺陷**：mock SubagentRuns 恒有 running 子代理→办公冷挂载触发既有「子代理任务自动置前」（openTasksAuto→openPaneView→closeFilePreview）→预览 ~3s 被顶掉，真机无子代理运行时不触发，mock 场景开关入欠账池；mock/office.ts 补 .gsched.json 预览分支（真实 mock 计划态）。②两份拍板用设计文档落档（调研+设计不动代码）：docs/gaea-schedule-resource-cost-design-2026-09.md（资源成本：4 刀全 0 绑定，费率口径推荐元/工日导出÷8 换算，最大风险=Project 对 Assignment Cost 重算行为未核实→刀4 绑真机池，拍板 8 项）+ docs/gaea-schedule-aoa-manual-layout-design-2026-09.md（AOA 手动布局：布局=展示层 pin 混合锚定，核心=锚点键匹配降级，Go pass-through 不进引擎，3 刀刀1 零绑定，拍板 7 项）。**下一步：等用户拍板两方案（资源成本刀1/AOA 刀1）或拍板池其他项。**；v4.121.0「进度计划刀12：办公联动三件套」已发布（588 零变更）——办公×进度方向拍板不并板只联动（数据/AI 层刀4~11 已终态，本刀补交互层）：①办公文件预览 .gsched.json 计划摘要卡（ScheduleFileCard：工期/关键/搭接/里程碑 chips+开竣工+基线漂移+倒排+循环依赖告警；原始 JSON 开关保留文本视图；解析失败回落文本视图）；②板块互跳（摘要卡「在进度计划中打开」/进度板块页头「办公侧查看」反向按钮=usePreviewStore 预置+navigate，office 未挂载也落地；跳转/周报限当前计划文件，其余只读摘要）；③「AI 进度周报」一键发共享线程（运行中 Steer/空闲 send 同构 Submit；审批挂起禁用）；gschedSummary.ts 纯函数（isScheduleFilePath/parseSchedSummary）+SCHEDULE_FILE_PATH 与 Go DefaultRelPath 镜像；i18n +27 键；vitest 2166（+15）；icons 集**无 ChevronUp**（ArrowUp 有）——icon 先查再引否则运行时炸；联动候选：完成率口径/周报模板化/另存为当前计划；拍板池：diff 确认卡/双工期口径/多工程；非拍板余：双代号手动布局/资源成本；真机池：真机端到端+联动手感**；v4.120.0「进度计划刀11：左栏细节完善」已发布（588 零变更）——拖宽分隔条/偏好持久化/新会话确认/快捷指令条/线程副标题；进度计划非拍板仅余双代号手动布局/资源成本（需设计方案）；拍板池：diff 确认卡/双工期口径/多工程；真机池：真机端到端+手感**；v4.119.0「进度计划刀10：左 AI 对话·右工作台」已发布（588 零变更）——双栏版面（左 420px 可折叠对话栏+右工作台）与办公板块共享同一工作线程；store 事件绑定提升模块级恰好一次防 keepAlive 双订阅；进度计划欠账：对话栏宽度拖拽/双代号手动布局/资源成本（需设计方案）；拍板池：diff 确认卡/双工期口径/多工程；真机池：真机端到端+手感**；v4.118.0「进度计划刀9：横道拖拽调排程」已发布（588 零变更）——拖移 auto=转手动锁定落点/manual=改锁定/右缘缩放=改工期（最近工作日吸附 drag.ts 纯函数）、Esc 取消、循环依赖禁拖、GanttView 首次拥有组件测试；进度计划非拍板欠账余：双代号手动布局/资源成本；拍板池：diff 确认卡/双工期口径/多工程；真机池：真机端到端+拖拽手感**；v4.117.0「进度计划刀8：倒排工期」已发布（588 零变更）——deadline 目标竣工字段+TS/Go 镜像 checkDeadline 可行性裁决（工作日换算/超期量/关键清单）+ops set_meta deadline 三态+三工具接线+板块 UI（页头输入/状态栏倒排段/横道紫虚竣工线）+技能锚点锁 23；进度计划线剩余拍板池：diff 确认卡/双工期口径/多工程；非拍板：横道拖拽调排程/资源成本；真机池：真机端到端+基线/倒排 UI 手感**；v4.116.0「进度计划刀7：基线对比」已发布（588 零变更）——TS baseline.ts↔Go baseline.go 镜像引擎（snapshotBaseline fail-closed+computeBaselineDrift：总工期漂移/推移·新增·移除/关键链进出；rows 只含偏差行、移除行按 id 排序）+ops set_baseline/clear_baseline（缺 savedAt 拒绝、无基线报错）+三工具接线（get 元信息/apply 回执 baselineDrift/analyze checks「较基线」发现）+板块 UI（基线弹层/横道灰描边基线条/状态栏漂移段）+schedule-edit 技能基线节（锚点锁 20）；进度计划线剩余拍板池：diff 确认卡/双工期口径/多工程；真机池：真机端到端+基线 UI 手感**；v4.115.0「进度计划刀6：推荐逻辑关系」已发布（588 零变更）——ops auto_chain 确定性原语（无前置叶任务按 WBS 顺序补 FS 串联，手动/已有逻辑不动，无可补拒绝）+ schedule_analyze「无前置」质检发现（工具闭环验证）+ schedule-edit 技能推荐工作流/分析报告四段模板；v4.114.0「进度计划刀5：对话即排程」已发布（588 零变更）——schedule-edit 内联技能+agent 写计划→板块即时回读（schedule_apply 回执触发）+ schedule_* 工具卡摘要；v4.113.0「进度计划刀4：AI 原生通道地基」已发布（586→588 +ScheduleLoad/Save）——internal/schedule Go 引擎+agent 工具三件套 schedule_get/apply/analyze+计划文件化（进度计划/当前计划.gsched.json 板块与 agent 共享，自动保存+轮询回读）；调研 docs/market-research-2026-09-06.md，15 原始稿在 docs/research-2026-09-06/**；v4.112.0「进度计划刀3：斑马 UI 对齐——六色分组横道（饱和六色分组行+▲组名+行号列+自然日轴+非工作日底纹）· 网络图统计牌（图例行右端红字大数字）· 底部状态栏」，586 零变更；v4.111.0「进度计划刀2：Project/斑马对齐——日历/模式/WBS/XML/前锋线」，586 零变更；v4.110.0「进度计划一级板块刀1：CPM 引擎+三视图自由切换」，586 零变更；v4.109.0「pptx 真编辑刀1 数据层 GaeaPptxApplyEdit」，585→586；v4.108.1「?mock=1 三链走查全过+mock 走查态升级」，585 零变更；v4.108.0「导图画布编辑 M2 自研 v1」，585 零变更；v4.107.0「多维表 B2 首刀：看板视图」，585 零变更；v4.106.0「办公 U4 缺口收口：xlsx 条件格式预览 · herdsman HS-obs 实测销账」，585 零变更；v4.105.0「Model Hub 蒸馏 MH4 常驻预热 · ComfyUI 预热 CU1+量化档位 CU2」，584→585 +WarmComfyUI；v4.104.0「Model Hub 蒸馏 MH1–MH3：采样让位+默认关思考 · 加载状态收敛 · UD 档位引导」，绑定面 584 零变更；v4.103.0「办公搜索对齐 unsloth：web_search url 直取整页 · 结果域名策略过滤 · 日期钉定」，绑定面 584 零变更；v4.102.0「Hub 落库 + 围栏 slot 口径统一 · 图像域 17
> 绑定转正 · Model Hub mock」，绑定面 584；Model Hub（Unsloth）并行会话线完结
> 落库 6cd891df + v4.101 漏提交补录 efe80310；v4.101.0「三线并行：GenUI 围栏
> Go 侧收口 · 画室模型目录 · 深检误报缓解」，绑定面 581 零变更；v4.100.0
> 「三线并行：画室 T1 余件 · 办公 U4 前半 · GenUI 围栏审计」，绑定面 581 零
> 变更；v4.99.0「三线并行：图像域 T1 收口 ·
> 办公 U2 回合投影 · GaeaListDir 硬化」，绑定面 581 零变更、
> ImageHubAssets/ChapterArtList 前端转正 AppBindings；v4.98.0「图像域 T0
> 契约落地：登记底座 · 素材库 ·
> 参考槽 v0」，579→581；v4.97.0「GenUI 蒸馏：回答即 UI · 办公会话面板」
> 579 零变更——**补记：该版发布说明/产物/SHA256 齐备但当时漏 commit+tag，
> 本会话已补提交 e9baae3c + tag v4.97.0，并经隔离 worktree 门禁验证**；
> v4.96.0「三线并行：下钻联动收尾 · Verifier 逐页
> 缩略图 · pptx 真编辑设计」，579 零变更；v4.95.0「三线并行收欠账：版本
> 对比入统一查看器 · README 内嵌 HTML 白名单 · 子代理歧义选择器」，579
> 零变更；v4.94.0「Agent 网络会话跳转」，578→579；
> v4.93.0「失败子代理恢复入口 + diff 行内语法着色」，578 零变更；v4.92.0「Mermaid strict 安全线成文 + MemoMarkdown
> 消毒层」，578 零变更，阶段三 3b 收口；v4.91.0「CodeMirror 语法高亮
> 编辑器」，578 零变更；v4.89.0
> 「成本费率 hover」，578 零变更；
> v4.88.0「/context 居中弹层 + 常驻剩余上下文% 徽标」，578 零变更；v4.87.0「统一 diff 渲染升级」，578 零变更，
> 阶段二收口；v4.86.0「Git 面板
> 最小集」，571→578；v4.85.0
> 「本轮文件三态折叠：写入/编辑/读取独立成层 + 类型筛选」，571 零变更；v4.84.0「HTML 沙箱预览 · 外链协议分流」，
> 571 零变更，阶段一收口；v4.83.0「工具结果图片缩略卡：官方 patch 口径
> token 估算」，571 零变更；v4.82.0「上下文趋势跳转浏览器：brief 行锚点 ·
> 偏好持久化 · 设置中心默认」，571 零变更；v4.81.0「文件活动行级增量：
> ±徽标 · 操作日志展开 · 详情跳转」，571 零变更；v4.80.0「上下文工具结果
> 深读：完整调用懒加载 · 来源 chip · 分类内排序」，570→571；v4.79.0
> 「上下文对比上一步」，570 零变更；v4.78.0「任务强制终止收口」，569→570；
> drift 571=权威口径——**勘误：v4.67~v4.77 所记 561 为过期口径**；
> v4.71~v4.77 七版已补档提交（ae462b20）+ 补 tag；releases/README.md
> 索引（101 个发布说明）已刷新。本会话另落 GitHub 市场调研三路
> （docs/research-2026-09-05/ + market-research-2026-09-05.md）与
> 长期规划回填）

## 最新发布：v4.111.0（2026-09-06）「进度计划刀2：Project/斑马对齐」

- 对齐清单五项全落：工作日历（周工作制+节假日例外，工期/时距口径从自然日修正为工作日，三视图口径统一）、手动/自动任务模式（Project 口径：manual 锁定开始/不回传约束/不标关键）、WBS 编码列（分组 n/叶 n.k）、MS Project XML 导入导出（mspdi 务实子集+roundtrip 测试，真机互开入真机池）、横道图前锋线（按完成进度取点+检查日期线）。
- 引擎 +16 例（calendar 8/cpm 手动 3/mspdi 5，schedule 合计 42）；导入导出纯前端（file input+Blob，绑定面 586 零变更）；persist merge 兼容 v4.110 旧数据。
- 门禁：tsc -b/eslint 0、vitest 2110/2110（ProgrammingPage 负载 flaky 单跑复跑全绿）、Go 零改动例行回归绿、版本四处 4.111.0、build.bat 冒烟 /api/health 200。
- 欠账：真机互通验证；倒排工期；基线对比；横道图拖拽/双代号手动布局；资源成本；后端持久化多工程。

## 最新发布：v4.110.0（2026-09-06）「进度计划一级板块刀1：CPM 引擎 + 三视图自由切换」

- 一级板块「进度计划」（工位，menuOrder 12）：一套任务表数据驱动横道图/单代号/双代号三视图 Segmented 自由切换（斑马「一表多图」口径）；绑定面 586 零变更（刀1 纯前端自治，localStorage gaea.schedule.v1）。
- 引擎纯函数 27 例：cpm.ts（FS/SS/FF/SF+时距、环 fail-closed、正逆推、TF/FF、关键、里程碑）15 例；aoa.ts 双代号转换（唯一 FS(lag0)/SS(lag0) 安全合并、虚箭线按搭接类型自动插入+去重、一始一终、i<j 编号、事件正逆推、关键虚工作、时标分层）11 例；layout.ts 分层共用。
- 三视图：横道图（任务表+前置 Popover 编辑器+月日轴/周末底纹/今日线/缩放/关键红/汇总黑条/时差尾/里程碑菱形/搭接箭线）；单代号六格节点；双代号圆圈事件+虚工作虚线。
- 接线：Go builtins.go+CanonicalIDs+space 断言表；前端 manifests/launcher/PageRegistry/图标表；boards 快照同步。
- 门禁：tsc -b/eslint 0、vitest 2094/2094、Go board 包+全量绿、版本四处 4.110.0、build.bat 冒烟 /api/health 200。
- 欠账：工作日历口径（自然日刀1）；横道图拖拽调排程；双代号手动布局；后端持久化/多工程；P6/MPP 互转。

## 最新发布：v4.109.0（2026-09-06）「pptx 真编辑刀1 数据层」

- 设计六拍板全按文档推荐落地（A=Go 自研同构 docxedit；P1 对齐 xlsx_apply；表格/组内包含，备注/图表边界外；Journal 对齐 xlsx_apply；docx 补账另刀）。
- **pptxedit 新包**：slide 序映射（sldIdLst+rels，Token 模式属性命名空间匹配——struct tag URL 属性匹配不可靠坑复用 v4.106 结论）；DrawingML 段落解析（a:fld 内 a:t 无 a:r 包装的真实形状覆盖——文本可见记 blocker 不可编辑）；LocateText/ApplyTextReplace（跨 run 命中、新文本继承最后受影响 run 的 a:rPr 原字节=保格式、完全覆盖非最后 run 省略）；zip 条目序+原子写、未知条目字节零扰动（测试锁定）。
- **App 层**：GaeaPptxApplyEdit（rollback 快照+Journal pptx_apply+GaeaPreview 返回）。
- 绑定链：586（gen_bindings→bindingNames→bridge PptxApplyEdit→spaceBindings work→锁 299）。
- 门禁：pptxedit 6 用例+Go 全量绿、vitest 2068/2068、tsc -b/eslint 0、drift PASS@586、版本四处 4.109.0。
- 欠账：刀2 编辑面（大纲扩展+编辑面板）；备注/图表边界外；PowerPoint/WPS 兼容性真机走查；docx_apply Journal 补账另刀。

## 最新发布：v4.108.1（2026-09-06）「?mock=1 三链走查全过 + mock 走查态升级」

- **走查实锤（DOM+计算样式）**：①条件格式 B2:B4>100 规则命中，实测红底 FFC7CE/红字 9C0006/加粗 600 三属性覆盖；②看板 4 泳道 4 卡 + 拖拽跨泳道（XlsxSetCell 真改内存工作簿→泳道重算，空泳道不保留=既定语义，固定泳道值列表记 B2 后半候选）；③导图改名/Tab/Delete/保存全链，落盘=规范大纲逐字一致、改名持久。
- **mock 升级**：office.ts 会话内可变态（mockXlsxState/mockFileBodies，XlsxSetCell/WriteFile 真改+Preview 保存优先回读）；新增阶段列+condRules 样例、board 视图样例、项目大纲.md 纯大纲样例、FileSearch 索引同步。
- **新坑入册**：①合成事件同 tick 连发撞 React 批处理（dragstart 后立刻 drop 读到陈旧 state），必须分 tick 派发；②CUA 输入对后台 IAB 页面不达（document capture 零捕获），原生 DnD/双击手势走查需真人；③该 Playwright surface 的 locator(selector,{hasText}) 不过滤，要用 .filter({hasText})。
- 门禁：tsc -b/eslint 0、vitest 2068/2068、drift PASS@585、版本四处 4.108.1。零产品缺陷。
- 欠账：原生拖拽/双击手感留真人复核；拍板池与真机补验池不变。

## 最新发布：v4.108.0（2026-09-06）「导图画布编辑 M2 自研 v1」

- M2 选型按蒸馏纪律定自研（与 M1 自研树同构、零新依赖；不引 mind-elixir），决策可逆（编辑层独立纯函数文件），设计文档状态行已回写。
- **纯函数层 mindmapEdit.ts**：不可变树操作（add 儿/兄弟、rename、remove、move 成环守卫）+ 规范序列化（H1/H2/嵌套列表），parse∘serialize 幂等钉死。
- **MindMapView 编辑态**：单击选中+M1 折叠兼容、双击改名、Tab/Enter/Delete、HTML5 拖拽挂载、脏态保存条 Ctrl+S/保存/放弃；FilePreview save(override) 复用 WriteFile+回读状态机。
- **防丢内容闸（关键安全设计）**：parse 上报 skipped（段落/代码块/围栏标记等未进大纲的非空行），混合内容或截断时编辑禁用+琥珀横幅——回写会永久丢非大纲内容，宁禁勿损；未传 onSave 保持 M1 只读零变化（M1 测试原样全绿）。
- 门禁：Go 全量绿、vitest 2068/2068、tsc -b/eslint 0、drift PASS@585、版本四处 4.108.0。
- 欠账：M2 后半（拖拽手感真机走查、折叠态保持策略、勾选/有序列表序列化保真）；拍板池（pptx 刀1/B2 后半/沙箱/终端/侧聊）；真机补验池不变。

## 最新发布：v4.107.0（2026-09-06）「多维表 B2 首刀：看板视图」

- 已批刀序 M1→B1→M2/B2 余件；B2 只做看板（价值最独立），后半（字段面板/画廊/validate 工具）与 M2（自研 vs mind-elixir 未决）留拍板。
- **看板**：type:"board" 放行（必须带 groupBy=泳道列，缺失丢弃+横幅）；泳道=列值（首现序/空值「（空）」）、卡片=行（cardFields 首字段标题、≤5 行、缺省前 4 字段）；计算复用 applyGbaseView/gbaseRowColor 零新语义。
- **拖拽改值**：拖到泳道=写该行 groupBy 单元格（XlsxSetCell 直编通道，与表格双击直编同口径；设计文初稿 Plan→Apply 表述已按实际修正）；「（空）」=清空；原地不写盘；moving 禁拖；cardFields 纳入列失配降级。
- 数据模型：fieldCols（字段→列号）+ cardFields（去重截断 8）+ 未知 type 仍拒（文案改 grid/board）。
- 门禁：Go 全量绿（零 Go 改动例行回归）、vitest 2056/2056、tsc -b/eslint 0、drift PASS@585、版本四处 4.107.0。新增 gbase 3 例 + GbaseBoardView 4 例。
- 欠账：B2 后半/M2 待拍板；看板 HTML5 DnD 真浏览器走查（?mock=1）；真机补验池不变。

## 最新发布：v4.106.0（2026-09-06）「办公 U4 缺口收口：xlsx 条件格式预览 · herdsman HS-obs 实测销账」

- **xlsx 条件格式预览（U4 缺口 #2，零绑定）**：后端 xlsxpreview/condfmt.go 经 f.Pkg 原始 XML 三层解析（workbook rels→worksheet cfRule→styles dxfs）提取 CellIs 静态子集（range+常量阈值+dxf 底/字色/加粗）进预览 JSON（condRules/condSkipped omitempty）；前端 lib/xlsxCondFmt.ts 纯函数判定 + XlsxPreview 命中覆盖基础样式（priority 小者整体胜出/文本大小写不敏感/between 无序归一/空格不参与）。expression/色阶/数据条/引用阈值诚实跳过计数。
- **实测坑成文**：①Go xml 带 URL 属性命名空间匹配不可靠，r:id 按本地名匹配；②excelize 写侧 SetConditionalFormat 不落 dxfs 表（dxfId=内部样式 id），真实 Excel 产物才有完整 dxfs——测试夹具需 zip 后处理注入（教训：excelize 写侧≠真实文件形状，读侧实现必须按真实文件口径测）。
- **HS-obs 实测销账**：herdsman v0.6.4 /props 404=采样面不可外部观测，坐实不立项；/api/benchmarks 自报 avg_ttft_ms=119 vs 真实聊天 2.8s 固定开销 → HS-obs-2 具象化为网关/调度路径差异（herdsman 侧，gaea 不可改）。
- 门禁：Go 全量绿、vitest 2049/2049、tsc -b/eslint 0、drift PASS@585、版本四处 4.106.0。
- 欠账：条件格式真机视觉走查（真实造价样例）；缺口 #1/#3/#4 维持盘点口径不做；真机补验池（MH4/CU1/CU3）不变——本机 ComfyUI 未配置实锤（comfyui_path 缺失+8188 拒连）。

## 最新发布：v4.105.0（2026-09-06）「Model Hub 蒸馏 MH4 常驻预热 · ComfyUI 预热 CU1+量化档位 CU2」

- **真机前置**：本轮 unsloth Studio(8888)/ComfyUI(8188) 均未运行（连接拒绝实锤）、herdsman 8080 在跑。MH4 幂等走规划 §四-2 保守路径（预热前查 /v1/models 已含即跳过，从不重复 load）；CU3 POST /free 确认不了维持观察项。
- **MH4（Go）**：启动自动预载扩 modelhub——四重门控（modelHubPreloadArmed 武装位 / auto_preload 总闸 / 活跃引擎跟随 / herdsman 预载将在途让路）+ 已加载跳过 + StartModelHubModel 后 5s/6min 轮询收敛，全程静默降级。新增 Manager.ModelHubModelLoaded（轻量 /v1/models 探测）+ ModelHubKeyConfigured。
- **CU1（Go+前端，+WarmComfyUI 绑定）**：ComfyUIBackend.Warmup=64×64/1 步空跑复用既有构建器（预热的就是下次真实生成的模型文件），绘梦页首入触发（非 gaea 启动），门控=引擎/模型登记/运行中/无生成在途/武装位+一次闸，跳过带 reason 静默。gen_bindings 585；分类锁 297→298。
- **CU2（纯前端）**：COMFY_MODEL_CHECKPOINT 映射（与 Go 构建器同源锚定），fp8/scaled=量化高效档——krea2「fp8」徽标+置顶；bf16/无标记诚实不猜。
- 测试：Go +10 例（gaea_schedule_modelhub_test 6 + image_comfyui_warmup_test 4）、前端 +2；门禁 go 全量绿、vitest 2042/2042、tsc -b/eslint 0、drift PASS@585。
- 欠账：真机端到端补验（MH4 日志链/CU1 首图收益量化/CU3 /free 支持性）；herdsman 预载与 modelhub 的对称互斥留观察；HS-obs 维持；乐园人格思考默认值待拍板。

## 最新发布：v4.104.0（2026-09-06）「Model Hub 蒸馏 MH1–MH3：采样让位+默认关思考 · 加载状态收敛 · UD 档位引导」

- 按 unsloth 蒸馏规划 §三刀序收 MH1–MH3 三把小刀（MH4 与 CU1–CU3 留待后续）；§七 A/B 实测硬口径直接进实现：unsloth 默认开思考烧光 token → modelhub 必须显式关；Studio 按模型自动采样调优 → 客户端 0.7 恒兜底是在顶掉它。
- **MH1（Go）**：ChatStreamChunks 按引擎 Type（非 id 硬编码）判定 modelhub——用户未显式配置 temperature 时不再兜底 0.7（omitempty 丢弃，让位 Studio 自动调优；全仓温度兜底仅此一处）；请求恒带 `chat_template_kwargs.enable_thinking`（默认 false，显式开 true + max_tokens≥4096 守护），只走实测证实的 kwarg 通道、不发顶层 enable_thinking。
- **MH2（前端）**：一键加载 stopped 模型不再谎报「已启动」——「加载中」徽标（hubLoadingIds，按钮 loading+禁用）+ 轮询 getEngines 到 running（5s/3 分钟上限，单次失败不终止），收敛成功才设默认模型；超时诚实提示且不设默认（冷加载实测 50s+）。
- **MH3（前端）**：`isUDVariant`（id 含 UD-）+ `sortModelHubUDFirst` 稳定置顶 + 「推荐」徽标；先 UD 后 pinned 组合排序=手动置顶优先、UD 顺序组内保留（测试锚定）。
- 测试：Go 新增 client_modelhub_test 3 例（httptest 捕请求体：默认/显式/非 modelhub 守护）；前端新增 6 例。门禁全量：Go 全量绿、vitest 2040/2040（首跑 28 例负载 flaky 复跑全绿）、tsc/eslint 0、drift PASS@584、版本四处 4.104.0。
- 欠账：MH4（前置=幂等真机核对+活跃引擎判定）；CU1–CU3 可并行；herdsman HS-obs 观察；乐园人格思考默认值「另议」（现可经 EnableThinking 显式开）；v4.103.0 专项 exe 不再补（版本源已前移，产物按 v4.104.0 一步到位）。

## 最新发布：v4.103.0（2026-09-05）「办公搜索对齐 unsloth：web_search url 直取整页 · 结果域名策略过滤 · 日期钉定」

- 用户反馈 unsloth Studio 的搜索工具「很好用」，希望 gaea 对齐其**行为**（非照搬 Python）。unsloth 源码本环境 web 抓取被拦（github/unsloth.ai/deepwiki/jsdelivr 均解析到非公网 IP），改经 `git clone`（`clones/unsloth`，已 gitignore `/clones/`）研究真实实现（`studio/backend/core/inference/tools.py` `_web_search`/`web_access_policy`/`search_images`、`web_search_tool_with_images`。
- **关键失败经验**：本环境 web_fetch 对多域名被拦截（"非公网 IP"），但 `git clone`/`git ls-remote` **可达**——研究第三方源码优先试 git 而非 web_fetch；`url.Parse("not a url")` 不报错（解析成 path-only），过滤搜索结果必须校验 scheme http(s)+非空 host。
- **蒸馏结论**：unsloth 搜索"好用"= 一个工具两条路（搜索 + `url` 直取整页文本）+ 结果受域名 allow/deny 约束 + 策略受限时过度抓取再过滤 + 末尾引导用 `url` 取全文 + 注入当前日期。
- **改动（Go 内部，绑定面 584 零变更，未触及前端/绑定）**：web_search 新增 `url` 直取整页（复用 web_fetch 的 SSRF/`checkDomainPolicy`/HTML→文本 `doFetch`，搜索→取全文→引用一次调用，url 优先）；`[search] allow/deny`（沿用 `checkDomainPolicy`）作用于搜索结果（`filterSearchResults`：deny 优先、allow 非空须匹配、丢弃非法非 http(s) 无 host 结果）；受限时过度抓取（`topK×3`，`searchPolicyOverfetch`）再过滤；注入当前日期（url 结果头部 `as of <date>`）+ 描述/`Schema`/`compact` 同步（去 `required:["query"]`、加 `url`）。
- **测试**：新增单测 6 例（`websearch_policy_test`：受限判定/allow-deny 过滤/非法 url 拒绝/无策略原样）+ 联网端到端实测（`websearch_live_test`，`GAEA_LIVE_TEST=1` 才出网、默认 SKIP——真实 Bing 搜索 JSON 1498B/source=bing + example.com 整页抓取+日期钉定生效）。
- 门禁：`go build ./...` OK、`go vet builtin` OK、builtin 全包 `-count=1` ok（live 默认 SKIP）；vitest/tsc/drift **未实跑**（纯 Go 内部、无绑定变更，drift 理论 PASS@584）。
- **未做（用户确认核心 Scope A）**：图片结果（`[[img:<id>]]` 令牌 + 前端 envelope，需动前端，Scope B）、工具调用内联确认 UX（Allow/Always/Deny）、Deep Research；RAG 已有 `knowledge_search`。日期钉定放在 web_search 内部（未动全局 sysprompt，避免 golden prompt 漂移）。

## 最新发布：v4.102.0（2026-09-05）「Hub 落库 + 围栏 slot 口径统一 · 图像域 17 绑定转正 · Model Hub mock」

- 用户确认 Model Hub（Unsloth）线完结后落库（6cd891df，835 行：modelcenter
  Unsloth 设置区/engine Key 管理/config/modelengine/model_router），**绑定面
  权威口径 579→584**（+3=SetModelHubKey/GetModelHubKeyStatus/StartModelHubModel，
  legacy 直调面）。**附带修复 v4.101 提交事故**：第一批 add 整批失败被吞、第二批
  漏列围栏接线 5+2 文件 → 补提交 efe80310（tag 不移，release 补记；教训=多步
  add 后必须 git diff --cached --stat 对照清单核数）。
- **§8-5 resume 槽位口径统一**（GenUI 审计最后一项）：实时 assistantSlot 优先
  事件日志序（logSeq 缺省回退计数器=旧后端逐字节兼容）；loadItemsFoldedFirst
  三路装载（resume/回退/启动）统一「GaeaResyncEvents(0) 折叠快照优先（id=日志
  序）+ History 保底」——genui 交互状态跨重启可命中；旧 key 不迁移任其 LRU
  逐出；resumeSnapshotItems（running 工具卡收尾 stopped、空数组=空会话短路）。
- **图像域 17 绑定转正**（GenerateFreeImage 等 15=play、GetCharacters/
  SetCharacterPortrait=shared；分类锁 280→297）：api/image.ts 直调迁 appFacade
  三态回退（wailsjsCompat import 清零，facade 类型=消费端形状消灭 any）；
  mock/imagegen.ts 17 方法（查询中性空态/动作诚实失败）+ 契约 3 例。
- **Model Hub/OpenCode Key mock 补齐**：七方法（Key 内存态联动+脱敏对齐
  maskKeyStatus+Start 诚实失败）+ 契约 4 例；?mock=1 modelcenter 全区块走查
  CLEAN（零 is-not-a-function，Unsloth 卡片真机配置后出现=预期）。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest **256/2034**（净增 2 文件/
  10 用例）、drift PASS（584）。
- 详见 releases/v4.102.0.md。

## 最新发布：v4.101.0（2026-09-05）「三线并行：GenUI 围栏 Go 侧收口 · 画室模型目录 · 深检误报缓解」

- 「继续」惯例三线并行；**绑定面 581 零变更**（子代理禁区继续排除并行会话
  Model Hub 文件族与 bridge/spaceBindings/bindingNames）。
- **线 A GenUI 围栏纪律 Go 侧收口**（审计 §8 六项落地；第 5 项 resume 槽位
  口径统一明确不做另行排期）：共享剥离 helper internal/gaea/genui/fence.go
  （行扫描照搬前端 splitGenuiFences，围栏折叠 `[genui 组件]` 占位、正文逐字
  保留；选位=internal/app 与 internal/whisper 已导入该包零新增依赖边）；做梦
  dreamInput/BuildCompactSummary pendingItems/whisper companion_reply 三处
  剥离（JSON 不再占窗口与入记忆，无围栏输入逐字节回归锚）；压缩
  summarySystemPrompt 增补「围栏 JSON 不原样收录」指引；面板 append 去重键改
  spec 指纹（resync 不重复追加）；会话删除按 stateKey 前缀清理交互状态与面板
  （App 删除点接线，删除成功判定后才清）。行为红线：剥离只影响提炼/摘要/记忆
  输入，正文/压缩尾部/转录/导出原样。
- **线 B 画室模型目录**（T1 剩余件）：imagegen 新 tab 读 HerdsmanModelCatalog
  （mock 契约不变、样例 +6；api/image.ts 本地类型三态回退零绑定），按目录能力
  字段分族（生图/改图/视频/识图，落位优先级+多族归最高族+徽标全量；纯 LLM
  不入视图）；**目录无档位/成本字段→「未定价/目录未标注」不伪装 0（T0 口径，
  明示目录没有的字段）**；当前生成台模型「当前使用」高亮（herdsman 后端限定，
  创作语境不做管理功能）。?mock=1 走查 PASS（截图）。
- **线 C 小说深检误报缓解**：误报分类盘点（精确串比对/别名/时间粒度/全半角/
  无中生有过重五源）；缓解=deepNormalizeText 归一化+deepNormContains（相等
  优先→唯一包含→歧义不命中）+deepAliasResolver（项目无 alias 字段，canon
  名单+称谓剥离表 30 项，歧义即放弃）+confidence/reason 分类与 UI 三档（冲突/
  疑似/提示，**只降不升零静默吞**）+单条忽略记忆（项目级 localStorage 上限
  500、指纹不含漂移 description、横幅保持可见可恢复）。gate 消费键不变。
- 收口修 3 处 tsc 错（ModelDirectory 模板拼接 GROUP_KEY 已是完整 DictKey 再拼
  前缀）。i18n imagehubT1.modelDir* +38、novelDeep.* +11 ×三语（126 键体检
  none）。
- 门禁：Go build/test/vet 全量 0 FAIL（含并行会话在途代码如实注明）、tsc -b/
  eslint 0、vitest **254/2024**（净增 4 文件/31 用例）、drift PASS（581 口径）。
- 详见 releases/v4.101.0.md。
- **补记（同日）**：v4.101.0 提交漏列围栏接线 5 文件 + 2 测试文件（第一批 add 整批失败被吞、第二批清单漏列），已补提交；tag 不移，详见 release 补记。**教训：多步 add 后必须 git diff --cached --stat 对照预期清单核数；2>/dev/null 会吞 add 的 fatal。**

## 最新发布：v4.100.0（2026-09-05）「三线并行：画室 T1 余件 · 办公 U4 前半 · GenUI 围栏审计」

- 「继续」惯例三线并行；**绑定面 581 零变更**（本刀口径；**并行会话 Model Hub
  线在同一工作区在途开发**，其 +3 绑定未提交未收编，drift 在含其改动树上
  PASS@584；子代理禁区清单显式排除其文件族与 bridge.ts/spaceBindings）。
- **线 A 画室 T1 余件**：①识图「读/懂」试用入口 VisionTrial（paste/选图→
  SavePastedImage→GaeaRecognizeImage/GaeaOCRText，原语 Tag+诚实错误原文+
  localStorage 最近 5 条，8 用例）；②创作资产 AssetStudio（角色槽 CharacterList
  分页/模板槽复用 TEMPLATES 231 个/近期作品 ledger 前 12 张；选中经既有
  applyTemplate/applyRefCharacter 回填，复制设定剪贴板兜底，10 用例）；
  **走查实锤并修复**：三视图 tab 互斥缺陷（onClick 只开不关→aria 双 selected
  内容不切换），修=三处 onClick 互斥关闭，序列验证过。
- **线 B 办公 U4 前半**：①渲染证据盘点 docs/gaea-u4-render-evidence-inventory-
  2026-09.md（6 通道对照，结论=写后反馈首选 GaeaPreview 单口刷新零绑定，缺口
  6 条只列不立）；②写后预览实时跟随（officeUpdatedPathsFromResult 派生→
  createPreviewRefreshScheduler 800ms 防抖→paneTabs.reloadTicks 总线→
  FilePreview 静默重载不清屏不重挂、DocxPreview 保滚动位+同文件不作废修改
  队列、XlsxPreview 重读 sidecar；**协同 U2：刷新绝不置前/已关闭不弹/编辑态
  跳过**；badge 三语；目标测试 108）。真模型场景 mock 驱动不了=jsdom 验收面
  （A1 先例口径）。
- **线 C GenUI 围栏审计**：docs/gaea-genui-memoryfence-audit-2026-09.md 五链路
  结论（压缩/投影/回放/导出=无害或防线有效；记忆链 3 个 Go 侧低风险吸收点
  登记）；**genui 内修 1 项**=password 只回传长度信号不回传明文（堵交互值→
  日志→做梦记忆链泄漏）；Go 侧 6 项裁决清单待后续。
- 门禁：Go 全量 0 FAIL（含他线在途代码，如实注明）、tsc -b/eslint 0、
  vitest **250/1993**（净增 2 文件/39 用例，首轮 1 例 flaky 复跑绿）、
  ?mock=1 走查 PASS（AssetStudio 三槽/VisionTrial 全要素/互斥修复序列）。
- 详见 releases/v4.100.0.md。

## 最新发布：v4.99.0（2026-09-05）「三线并行：图像域 T1 收口 · 办公 U2 回合投影 · GaeaListDir 硬化」

- 「继续」惯例三线并行（文件所有权互斥子代理），**绑定面 581 零变更**
  （drift PASS；ImageHubAssets/ChapterArtList 前端转正 AppBindings/spaceBindings
  shared/play，分类锁 278→280，Go 侧不变）。
- **线 A 图像域 T1 收口**：①GenerateDiagram 登记接线（media.diagram 第二试点：
  成功后 .mmd 落盘 .gaea/uploads + 写 Asset Ledger，Startup 武装位闸控、失败只
  warn、model/cost 诚实留空，Go 用例 +4）；②任务中心素材库 tab 轻扫（激活重读
  +30s 可见性门控轮询，缩略按 path 缓存）；③画室素材库独立页 AssetLibrary
  （顶部「生成模式」新增「素材库」入口；grid 懒加载分页/原语与来源筛选/点选溯源
  详情/play+work 双空间切换/返回即还原；ChapterArtList 未接入=按章清单语义不匹配）。
- **线 B 办公 U2**（蒸馏规划 §4.2 拍板 2/3/4/5，绑定面 0）：①officeTurnProjection
  纯函数（callId 配对，写入/验证/生命周期三归约，失败不提交转换，乱序/孤儿/重复
  容错，30 用例）；②统一 Office 回合卡 draft/ready 徽标（DeliverableCards/
  VersionTimeline 同判定；登记表/证据链/置前不动，**regress 锁原样全绿**）；
  ③预览浮窗状态机 previewAutoFrontReduce（写弹读不弹/关闭优先不复活/写意图跨
  回合/终态清理；挂载/恢复/resync 只建基线；Office 扩展名+专注/窄屏守卫）；
  ④草稿轻量版（证据链首写=draft、Plan→Apply 批准=ready，零新实体零新按钮）。
- **线 C GaeaListDir 硬化**（v4.96 登记）：IsAbs 分支（相对路径行为逐字节不变
  回归锁）+ 结构化错误码 GAEADIR_NOT_FOUND/NOT_DIR/READ_FAILED（对齐 U1 先例）；
  **签名 []DirEntry→([]DirEntry, error)**（成功负载不变，Completeness PASS）；
  osStat/osReadDir 注入缝使权限用例全平台确定性；前端 verifyArtifacts 切错误码
  优先+文案匹配兜底（旧后端兼容），四态诚实降级不变。
- **收口**：wailsjsCompat 消费族欠账部分销账（转正+api/image.ts 三态回退
  window.go?.app?.App ?? bridgeApp）；dev mock 补 mock/imagehub.ts 中性样例
  （生图×2/图示/视频，未定价诚实留空）；i18n imagehubT1.* 27 键+officeTurn.* 4 键
  ×三语（重复/缺失体检 none）。
- **?mock=1 真浏览器走查 PASS**（DOM+截图双验收）：绘梦→素材库入口→AssetLibrary
  （3 卡/图示筛选=1/点选详情/创作空间 1 视频卡/返回恢复）+ 任务中心素材库 tab
  （play 1 卡+计数徽标）。U2 回合卡/浮窗依赖真实办公回合，mock 无法驱动，
  验收面=174 个 jsdom 用例+regress 锁（A1 先例口径），真模型端到端待用户复验。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest **248/1954**（净增 3 文件/56
  用例；首轮 FilePreviewModal 1 例负载 flaky，单独+全量复跑均绿=既有模式）、
  drift PASS（581）。
- 详见 releases/v4.99.0.md。

## 最新发布：v4.98.0（2026-09-05）「图像域 T0 契约落地：登记底座 · 素材库 · 参考槽 v0」

- 图像能力域第一步（设计 docs/gaea-image-domain-t0-contract-design-2026-09.md，
  权威路线 docs/gaea-image-domain-longterm-plan-2026.md）。**绑定面 579→581**
  （+ImageHubAssets/ChapterArtList 只读绑定）。
- **T0 契约**：五原语能力注册表（识图-读/懂、生图、图示可用；改图 fail-closed）
  + Asset Ledger v1（按空间 append-only JSONL：play=.gaea/play/imagehub/
  assets.jsonl、work=.gaea/imagehub/assets.jsonl；只存路径+溯源元数据，坏行
  容错、2000 上限折叠不删文件）+ 模型中心目录只读静态视图（档位/成本，未知
  模型诚实留空不伪装 0）。三试点：书封登记、绘梦落盘登记（失败只 warn 不拖垮
  生成）、GaeaOCRText/GaeaRecognizeImage 入口注册表校验（行为不变）。
- **T1 提前量**：章节配图落盘 play exports + 登记 + 项目清单 chapter-art.json
  （ChapterArtList 只读取，ChapterIllustration 展示本章历史配图）；绘梦任务
  中心新增「素材库」tab（ledger 缩略卡：模型/成本/来源/视频/时间）；角色剧照
  保存后进溯源（characterlib）。
- **T2 参考槽 v0**：绘梦左栏选角色库角色 → 取参考图（≤4，首张作图生图种子）
  自动切图生图（denoise 0.65）；ComfyUI txt2img 带参考自动转 img2img，
  ipadapter/pulid 诚实报错未实现；GLM/OpenAI 兼容端点不支持参考图诚实拒绝；
  character_id 随生成进登记。
- **办公纪律两刀**：U1 工具错误码（format_convert 全出口 `Error [FORMAT_*]`
  结构化：INVALID_ARGS/SOURCE_MISSING/UNSUPPORTED/CONVERT_FAILED/
  OUTPUT_WRITE_FAILED，模型按 code 路由恢复，蒸馏 dsh-univer-office 拍板项 4）
  + 内置 office-edit 技能（先读后写/写后回读验证/宁拒不误改/逐 run 编辑/
  soffice 渲染取证/错误码路由/.gbase.json 与思维导图纪律）。
- **修复**：登记运行态闸测试进程污染——原闸 gaeaCfgSnapshot()!=nil 在 app 包
  测试进程恒真（其他测试初始化全局配置），TestGenerateFreeImage_SafeMode 把
  登记写进源码树 internal/app/.gaea/；改为 App.Startup 显式武装位
  （imageHubRuntimeArmed），测试进程恒不落盘 + 回归钉。
- 门禁：Go 全量 0 FAIL（闸修复后复跑）、tsc -b/eslint 0、vitest **245 文件/
  1898 用例全绿**（净增 4 文件/38 用例）、drift PASS（581）；v4.97.0 tag 树
  隔离 worktree 验证（Go/tsc）补做通过。真机验收（生成后 assets.jsonl 出
  登记、素材库 tab、章节配图历史）待用户复验。
- 详见 releases/v4.98.0.md。

## 最新发布：v4.96.0（2026-09-05）「三线并行：下钻联动收尾 · Verifier 逐页缩略图 · pptx 真编辑设计」

- 「继续」惯例三线并行（文件所有权互斥），**绑定面 579 零变更**。
- **刀A 三级下钻收尾**（调研中期候选第 4 条，**四条全部落地**）：TokenCard
  「查看趋势」入口（可选回调向后兼容）→ jumpToTrend tick 锚点（与 brief
  跳转同款机制/令牌）→ scrollIntoView + accent outline 强调 3s；不碰趋势卡
  选中态；contextview.* +2 键 ×三语。
- **刀B Verifier 逐页缩略图**（老账销账）：证据卡「视觉复核」行内
  before/after 逐页缩略卡（页码标注/缺页诚实占位/懒加载/并发≤4/四态诚实
  降级）。**零绑定变更**：verifyArtifactRelPath 按固定标记截取相对路径 +
  GaeaPreview 探测定性，绕开 GaeaListDir 无 IsAbs 分支且吞错的缺口
  （**Go 小刀候选登记**：IsAbs+错误透传/结构化错误码）。
  **走查实锤并修复两个 jsdom 测不出的真缺陷**：①setState updater 内副作用
  被父级轮询竞争吞掉（副作用移回事件处理器本体）；②liveRef 只写 cleanup
  在 React18 dev StrictMode effect double-invoke 下恒 false → 组件 dev 下
  永远「已卸载」（改 effect 本体重置 true 标准写法）。
- **刀C pptx 真编辑设计文档**（待拍板，不动代码）：
  docs/gaea-pptx-edit-design-2026-09.md + research-2026-09-05b/。现状=
  docx 自研字节级 OOXML 手术（docxedit 零依赖）/xlsx excelize 直编/
  **pptx 编辑为零且格式无修订制**（改走 xlsx 同款 Plan→Apply+基线快照）；
  推荐 Go 自研 pptxedit 与 docxedit 同构（排除 gooxml AGPL/unioffice
  商业授权）；分期四刀（数据层 579→580→编辑面→结构化对比→队列泛化）；
  **待拍板 6 项**见文档末节。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest **1825/1825**（净增 39）、
  drift PASS（579）、SHA256SUMS-v4.96.0.txt 当场生成。一轮 31 failed
  （4 文件含 NovelSettingPage）为负载 flaky 漂移，复跑两轮全绿——如实记录。
- 走查：缩略图全链路 PASS（产物 tab→证据链→双通道复核→查看缩略图→6 卡
  成对+页码标注；img 不显系 mock dataUrl 为截断样例）；Token 卡→趋势
  PASS（outline 强调+定位视口内）。走查新坑：evaluate click 对热区被遮挡
  的开关无效，elementFromPoint 校验后 CUA 真实点击；antd 菜单/tab 用
  mousedown+mouseup+click 三连 dispatch。

## 最新发布：v4.97.0（2026-09-05）「GenUI 蒸馏：回答即 UI · 办公会话面板」

- 文档：docs/gaea-dsh-genui-distill-plan-2026-09.md（完整规划 + 执行状态）。
- P1 共享内核 frontend/src/genui：spec/guard/parse/interaction/fingerprint/
  GenuiBlock/renderNode/styles/scope/action-context（34 种白名单组件、LIMITS 权威、
  未知 type 丢弃、流式部分解析、LRU 200 持久化、本地判卷/防抖/secret 禁令）。
- P2 双板块 markdown 缝：办公 Markdown/MemoMarkdown/Message/App（office scope +
  action 宿主 steer/send）；聊天 ChatMarkdown/MarkdownContent/ChatRow/ChatPage。
- P3 模型侧：internal/gaea/genui（embed Handbook/ChatRule/OfficePointer +
  ValidateSpec）+ genui_validate 只读工具 + genui inline 技能 + boot/app/whisper
  提示词接线（人格统一注入点带门控）。
- P4 办公「UI」面板：genuiPanel store（REPLACE/APPEND/去重/会话隔离）+
  GenuiPanel + workspaceTabs/sidebarRegistry 第六 Tab + /panel open|clear|<指令>。
- 门禁：tsc/eslint 0；vitest 241 文件 1860 用例全绿（P5 面板/命令/验收走查 +10 已含）；
  前端生产构建 npm run build 通过；GenuiPanel/命令/Go 校验工具 Execute 契约测试已补。
  Go genui/skill/tool·builtin/boot/app/whisper 全绿；绑定面 579 不变。
- P5 剩余（需真机/发布决策）：真模型端到端（办公面板原地更新/聊天出 UI）、?mock=1
  视觉走查（发布说明已如实记录待用户复验）、记忆/压缩侧围栏剥离审计（若影响确认）。
- 发布产物：releases/v4.97.0.md + SHA256SUMS-v4.97.0.txt；冒烟 /api/health 200；
  wails.json/versioninfo.rc/README/CHANGELOG 已同步 4.97.0。

## 最新发布：v4.95.0（2026-09-05）「三线并行收欠账」

- 「继续」惯例三线并行子代理（文件所有权互斥），**绑定面 579 零变更**。
- **刀A docx/xlsx 对比迁移 ChangesDiff**（v4.87 成文计划最后一项销账）：
  DiffRow 可选 marker 列（docx 段号/xlsx 单元格 ref，pairModifications 整行
  spread 防丢）；VersionTimeline 对比体经 ChangesDiff；xlsx 每 sheet 一
  hunk、change 单元格→相邻 del+add 对（改蓝配对+字符级高亮）、formula
  后缀；diffstat/截断提示/展开全部全保留。
- **刀B README 级内嵌 HTML 白名单**（3b 遗留销账）：rehype-raw+
  rehype-sanitize 显式 schema（46 白名单/27 strip/className 按值放行
  KaTeX+language-*）；协议收口走渲染层（mdUrlTransform+classifyExternalLink；
  schema.protocols 浅合并坑实测踩中）；transformer 必须 Pluggable 元组否
  则静默 no-op；**收口修正 GFM 任务列表 checkbox 误伤**（input 移入白名单
  按值受限 ["type","checkbox"]——styles.css .md input[type=checkbox] 既有
  样式依赖，红线不许丢）；MemoMarkdown 聊天流有意不动。
- **刀C 子代理歧义选择器**（老账销账）：matchRunningCandidates 纯函数+
  歧义两槽位（resolver/handler）；ToolCard 歧义卡可点→App 居中选择器
  人工挑选跳转；**宁缺勿错不变**（绝不自动跳，0/1 候选与现状一致）；
  taskpick.* 三语 +7 键。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest **1786/1786**（净增 28）、
  drift PASS（579）、SHA256SUMS-v4.95.0.txt 当场生成。**ContextView.test
  全量负载三连 5s 超时（单独复跑绿、与刀零接触）→ 文件级
  vi.setConfig({testTimeout:20_000}) 只放宽时限，处置成文**。
- 走查：?mock=1 README 内嵌 HTML DOM 断言六项过（白名单渲染+消毒剥净；
  mock README 样例补内嵌 HTML 段）；VersionTimeline 对比/taskpick 歧义
  mock 不可驱动，以单测为验收面（A1 先例）。**走查新坑：产物面板 mock
  无产物行、IAB 截图通道故障转 DOM 断言（沿例）**。

- **蒸馏规划滚动中**：阶段一、二.5（含 2.5e 弹层+徽标）、阶段二
  2a/2b/2c 全部收口（v4.78~v4.88）；3a CodeMirror（v4.91）/3b Mermaid
  strict（v4.92）已收口，**语法着色随 v4.93 落地**。**销账（v4.95）**：
  docx/xlsx 对比迁移 ChangesDiff（v4.87 成文计划最后一项）、README 级内嵌
  HTML 白名单（3b 遗留）、子代理队列非唯一命中交互式确认（老账）。
  **剩余候选均为拍板项**：阶段三 3c 人工沙箱浏览器多开；阶段四真实终端
  （D1 推荐默认=暂不做交互终端）；中期候选见 docs/market-research-2026-09-05.md（成本费率 hover v4.89、
  终止级联 v4.90、失败子代理可恢复入口 v4.93 已落地）；微信文件收发（抓包前置）；
  Agent Network 会话跳转已落地（v4.94）。
- **dsh 剩余借鉴**：2.5e /context 弹层与 Agent Network 会话跳转均已落地（v4.88/v4.94）。
- **老账**：run_skill AllowedTools 真机观察；pptx 真编辑；Verifier 通道 B
  逐页缩略图。
- **v4.95 已知边界**：taskpick 选择器候选为点击瞬间快照（点选后 5s 轮询
  自校正）；raw `<input type=radio>` 现剥成空 input，若要支持需拍板；
  vcompare.cellRef/cellOld/cellNew 三键不再被消费（键保留字典）。

## 下会话续做（待办清单，2026-09-05 v4.101.0 后更新）

- **GenUI 审计余项**：§8 第 5 项 resume 槽位口径统一（实时 `a${seq}`/重放
  `h${index}`/resync `a<日志seq>` 三套锚点，跨重启状态恢复实际不生效）——
  跨层设计改动需排期单独刀。其余六项已落地（v4.101）。
- **U4 后半**：pptx 面板接续编辑与刀2 联调（随 pptx 真编辑拍板）；渲染证据缺口
  6 条真模型走查后再定是否立绑定。**U2/U4 真机复验**：写弹预览/关闭优先/写后
  自动跟随（badge）需真模型回合。
- **图像域**：T2 一致性方法实现（ipadapter/pulid）、识图入口真机走查（paste
  真图）；真机验收：真实生成后 ledger 登记、AssetLibrary/AssetStudio/VisionTrial/
  模型目录真数据（模型目录若目录携带档位/成本元数据回填替换「未定价/目录未标注」）。
- **小说深检**：别名真值数据源（项目无 alias 字段，现为启发式名单）；粗粒度
  时间降级与忽略记忆真机观察。
- **并行会话 Model Hub 线（非本会话所辖）**：其 +3 绑定与 modelcenter 改动未提交；
  其收尾后 bridge.ts/spaceBindings/bindingNames 恢复可动，「GenerateFreeImage 等
  直调族转正」欠账再启动。
- **蒸馏规划拍板项**：阶段三 3c 人工沙箱浏览器多开；阶段四真实终端（D1 暂不做）；
  微信文件收发（抓包前置）；**pptx 真编辑（=U3）按 docs/gaea-pptx-edit-design-2026-09.md
  待拍板（6 项），拍板前不动刀**。
- **老账**：run_skill AllowedTools 真机观察；待解锁复核真机验收（弹层关闭/Git
  面板/CodeMirror 编辑态/径向图跳转/缩略图真数据）。
- **走查新坑（沿记）**：evaluate click 对热区被遮挡开关无效；antd 菜单/tab 用
  mousedown+mouseup+click 三连 dispatch；antd Segmented 点 .ant-segmented-item
  （label.title 定位）；**页面级多视图互斥是 jsdom 分组件测试盲区，新视图 tab
  必须走 ?mock=1 序列切换**；IAB 细节断言勿匹配 <style> 标签 textContent；
  vite dev 残留实例占端口（netstat 查 PID taskkill）后再走查。

## 最新发布：v4.94.0（2026-09-05）「Agent 网络会话跳转：子代理上下文按会话查看」

- 双源蒸馏规划阶段二.5 2.5e 后半，**2.5e 全部收口**。绑定面 578→579。
- Go：GaeaSubagentContextView(sessionPath, ref)——子代理 transcript 直读
  （ReadLogRepaired）+ 同一 FoldTimeline 管线；ref 非法/缺失诚实处理。
- 前端：ContextView fetchTimeline 数据源抽象 + onViewSubagentContext
  回调；AgentRadial sa_ 节点「查看上下文」入口；ContextModal
  fetcher/title 透传；App 接线（径向图 → 子代理上下文弹层）。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 231/1758、drift PASS（579）、
  Go 绑定测试（合法/缺失/非法三态）-count=2 绿。
- 详见 releases/v4.94.0.md。

## 最新发布：v4.93.0（2026-09-05）「失败子代理恢复入口 + diff 行内语法着色」（双小刀合并）

- 刀A（调研回填 opencode「失败≠终点」）：SubagentThread 失败态恢复提示条
  ——RunFollowUp 本支持 failed ref 续跑，入口可发现化。
- 刀B（2c 遗留）：diffHighlight.ts 按路径 Lezer parser 单行 token 切分
  （tok-* 色板，600 字上限防退化），ChangesDiff 接线（配对行字符高亮
  优先），ChangesPanel/GitPanel 传路径。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 231/1756、drift PASS（578）、
  ?mock=1 DOM 走查通过（ts diff 12 个 tok 片段；截图通道沿例故障）。
- 详见 releases/v4.93.0.md。

## 最新发布：v4.92.0（2026-09-05）「Mermaid strict 安全线成文 + MemoMarkdown 消毒层」

- 双源蒸馏规划阶段三 3b。绑定面 578 零变更（纯前端刀）。
- 新增 sanitize.ts（DOMPurify）：MemoMarkdown 流式尾部接 sanitizeHtml
  （兜底转义回归）；**Mermaid SVG 外层再消毒经实验证伪后有意不做**——
  strict 上游已内置消毒，外层 svg profile 剥 foreignObject 文字（决策
  成文 lib/sanitize.ts 头注）。sanitize.test +3；mock README 补 mermaid
  样例；?mock=1 走查 labels 完整、无脚本注入。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 229/1753、drift PASS（578）。
- 详见 releases/v4.92.0.md。

## 最新发布：v4.91.0（2026-09-05）「CodeMirror 语法高亮编辑器」

- 双源蒸馏规划阶段三 3a。绑定面 578 零变更（纯前端刀）。
- 新增依赖 codemirror@6 + 六语言包（懒加载 chunk）；CodeEditor 组件
  （cmLanguageFor 按扩展名选语言/行号/撤销历史）；FilePreview 编辑态
  双层回落（Suspense fallback + EditorBoundary→textarea）编辑能力永不丢失；
  2c 遗留的 diff 语法着色能力随依赖就位。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 228/1750、drift PASS（578）、
  ?mock=1 DOM 走查通过（go.mod 编辑态 .cm-editor/.cm-content/.cm-gutters）。
- 详见 releases/v4.91.0.md。

## 最新发布：v4.90.0（2026-09-05）「终止级联：父任务中止连带终止派生后代」

- 调研回填中期候选（claude-code/cline 终止即级联共识）。绑定面 578 零变更。
- jobs.StartIn 从调用方 ctx 检出父 job ID 登记父子链（复用既有 jobIDKey）；
  Kill 追加 BFS 级联取消全部存活后代（bash ctx watcher 强杀进程树）；
  杀子不动父；后台 task/bash 两派生点改道 StartIn，主回合派生=原行为。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 227/1740（勘误 v4.88/89
  计数）、drift PASS（578）、jobs 并发单测 -count=2 绿（引擎语义 mock 不可
  驱动，沿 A1 先例以单测为验收面）。
- 详见 releases/v4.90.0.md。

## 最新发布：v4.89.0（2026-09-05）「成本费率 hover：单价快照 · 三档明细 · 诚实降级」

- 调研回填中期候选第一项（langfuse/ccusage 费率口径）。绑定面 578 零变更。
- Go：fold 跟踪最近一次 usage 上报的非零单价（每 1M tokens），Timeline
  透出 rate{inputPer1M,outputPer1M,cacheHitPer1M,currency}；无定价 → nil。
- 前端：SummaryBar 成本单元格 hover 五行明细（来源口径+三档费率+合计，
  币种 CNY/USD）；无费率诚实「费用未估算」；costHoverTitle 纯函数；
  i18n 三语 +5 键。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 227/1742、drift PASS（578）、
  ?mock=1 DOM 走查通过（hover title 五行断言；截图通道沿例故障）。
- 详见 releases/v4.89.0.md。

## 最新发布：v4.88.0（2026-09-05）「/context 居中弹层 + 常驻「剩余上下文%」徽标」

- 双源蒸馏规划阶段二.5 2.5e 与调研回填徽标合并刀。绑定面 578 零变更（纯前端刀）。
- ContextPill：Composer 上方常驻「剩余 N%」胶囊（store ContextUsage 数据，
  三档配色，点击开弹层，win≤0 不渲染）；ContextModal：居中弹层复用
  ContextView（打开挂载/关闭卸载）；/context 命令改道弹层、主区 tab 保留。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 227/1743、drift PASS（578）、
  ?mock=1 DOM 走查三项通过（徽标/点击弹层//context 两段 Enter；截图沿例故障）。
- 详见 releases/v4.88.0.md。

## 最新发布：v4.87.0（2026-09-05）「统一 diff 渲染升级：改蓝配对 · 行内字符高亮 · 上下文折叠」

- 双源蒸馏规划阶段二 2c，**阶段二全部收口**。绑定面 578 零变更（纯前端刀）。
- diffRender 纯函数：改蓝配对（相邻删块+增块按行两两配对蓝底替代红绿，
  data-pair 标记，交错输入先规范化）+ 行内字符高亮（字符级 LCS 变化片段
  着色，240 字上限）+ 上下文折叠（ctx 中段收起可展开，fold 携带被收起行）；
  ChangesDiff 统一查看器承接变更面板 LCS + Git 面板 unified diff；语法着色
  留阶段三。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 226/1741、drift PASS（578）、
  ?mock=1 DOM 走查通过（折叠占位/展开渲染/配对标记；截图通道沿例故障）。
- 详见 releases/v4.87.0.md。

## 最新发布：v4.86.0（2026-09-05）「Git 面板最小集：status/diff/stage/commit/history」

- 双源蒸馏规划阶段二 2b；D3 采纳推荐默认（单仓库无 push）。绑定面 571→578（+GaeaGit*7）。
- Go：gaea_git.go——git CLI exec 列表（无 shell 注入），仓库锚定 gaeaCwd；
  porcelain 状态、unified diff、stage/unstage/discard/commit/log；非仓库/git
  缺失诚实错误。前端：Git 一级 Tab（清单派生）+ GitPanel 三分组/状态徽标/
  行内 diff（buildGitDiff 复用 ChangesDiff）/两击确认丢弃/提交门禁/历史懒加载；
  绑定三件套同步（数量锁 270→277）。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 225/1723、drift PASS（578）、
  ?mock=1 DOM 走查四项通过（截图通道沿例故障如实记录）。
- 详见 releases/v4.86.0.md。

## 最新发布：v4.85.0（2026-09-05）「本轮文件三态折叠：写入/编辑/读取独立成层 + 类型筛选」

- 双源蒸馏规划阶段二 2a。绑定面 571 零变更（纯前端刀）。
- ChangesPanel 重构：写入/编辑/读取三层独立折叠（同文件跨层独立出现；
  读取层轻量行默认收起；写/编辑层 diff+回滚保真）；类型筛选 chips 横贯
  三层（categoryOf 扩展名分桶）；items 为权威源、changes prop 兼容回退；
  buildChangeCalls/buildSessionChanges 工具集参数化零破坏。
- 门禁：Go 全量 0 FAIL、tsc -b/eslint 0、vitest 224/1720、drift PASS（571）、
  ?mock=1 DOM 走查通过（三层计数/读取展开/分类过滤/空提示；截图通道沿例故障）。
- 详见 releases/v4.85.0.md。

## 最新发布：v4.84.0（2026-09-05）「HTML 沙箱预览 · 外链协议分流」

- 双源蒸馏规划阶段一 1c，**阶段一收口**。绑定面 571 零变更。
- GaeaPreview 增 .html kind=html（原文截断读）；前端 SandboxedHtml——
  独立 iframe `sandbox="allow-scripts"`（无同源=不透明源）+ Chromium csp
  属性 `default-src 'none'`（禁网络外链，只放内联样式/脚本与 data:/blob: 图）
  双保险 + 顶条标注；FilePreview/FilePreviewModal 双消费点接线。
- 外链分流：browserPolicy.classifyExternalLink（http/https 放行 loopback 拒、
  mailto/tel 交系统、其余 blocked）；Markdown 渲染链接与价格源两处接线
  （此前任意 href 直接 openExternal）。
- 门禁：Go 全量 0 FAIL、tsc/tsc -b/eslint 0、vitest 224/1712、drift PASS（571）、
  ?mock=1 DOM 走查通过（iframe sandbox/csp/srcdoc/标注条全验；截图通道沿例故障）。
- 详见 releases/v4.84.0.md。

## 最新发布：v4.83.0（2026-09-05）「工具结果图片缩略卡：官方 patch 口径 token 估算」

- 双源蒸馏规划阶段二.5 2.5b 后半，**阶段二.5 全部收口**。绑定面 571 零变更。
- Go：imgtoken.go 官方 patch 口径（⌈w/28⌉×⌈h/28⌉ 先档位缩放再封顶，官方例
  1000×1000→1296 单测锚定，弃 /750）；imgrefs.go 图片引用确定性提取（上限 4，
  非法 JSON 诚实不猜）；App 层 resolveNodeImages（DecodeConfig 头部取尺寸，
  缺失/不可解码诚实降级）；fold 修 stats.Images 死字段；x/image 转 direct。
- 前端：NodeImageCard 缩略卡（缩略图懒加载+点击预览+尺寸→缩放尺寸+「≈N tok ·
  标准档」悬停完整口径）；缺失灰态/尺寸未知；i18n 三语 +6 键；mock vision 样例。
- 门禁：Go 全量 0 FAIL、tsc/tsc -b/eslint 0、vitest 224/1700、drift PASS（571）、
  ?mock=1 DOM 走查通过（截图通道沿 v4.82 故障如实记录）。
- 详见 releases/v4.83.0.md。

## 最新发布：v4.82.0（2026-09-05）「上下文趋势跳转浏览器：brief 行锚点 · 偏好持久化 · 设置中心默认」

- 双源蒸馏规划阶段二.5 2.5d。绑定面 571 零变更（RequestRecord 增可选 JSON 字段）。
- Go：fold 跟踪 brief 锚点 seq（user/assistant=消息节点；工具交换结果到达锚
  结果节点、未到退化 assistant）；RequestRecord.briefUserSeq/briefRespSeq；
  header/usage/turn_done 三处同拍。前端：brief 行跳转按钮→浏览器组展开+滚动+
  高亮 3s（归档同款）；粒度/模式/排序初值读 gaea.context.prefs 变更写回；
  设置中心办公分组「上下文页偏好」卡；i18n 三语 +11 键。
- 门禁：Go 全量 0 FAIL、tsc/tsc -b/eslint 0、vitest 224/1698、drift PASS（571）、
  ?mock=1 DOM 走查通过（IAB 截图与 Edge 无头备援均故障，实拍缺席如实记录）。
- 详见 releases/v4.82.0.md。

## 最新发布：v4.81.0（2026-09-05）「文件活动行级增量：±徽标 · 操作日志展开 · 详情跳转」

- 双源蒸馏规划阶段二.5 2.5c。绑定面 571 零变更（详情跳转复用 v4.80 绑定）。
- Go：FileActivity+Added/Removed/Hits（fileDeltaFromArgs 四写类工具参数
  确定性提取 + grep 结果行数下界；recordFile dispatchID 回填）。前端：
  文件行 ±徽标、N 次操作展开、操作行详情懒加载跳转（NodeDetailPanel/
  useNodeDetails 抽共享）；i18n 三语 +2 键。1b 勘误销账。
- 门禁：contextview -count=2 绿、Go 全量除 1 个既有 TempDir flaky（复验绿）、
  tsc -b/eslint 0、vitest 223/1688（与 Go 并发跑时 20 个超时失败复跑全绿，
  负载 flaky 先例）、drift PASS（571）、?mock=1 走查通过（截图存 artifacts）。
- 详见 releases/v4.81.0.md。

## 最新发布：v4.80.0（2026-09-04）「上下文工具结果深读：完整调用懒加载 · 来源 chip · 分类内排序」

- 双源蒸馏规划阶段二.5 2.5b 前半。绑定面 570→571（+GaeaContextNodeDetail）。
- Go：SurfaceNode+Tool/Err 零成本透出；detail.go NodeDetailFor 纯函数读端
  （tool_result 全文+同 id dispatch 参数回读双 kind、user/assistant 全文、
  1MB 截断 Clamped UTF-8 安全）；App 懒加载绑定。前端：来源 chip+✗error 点、
  完整调用面板（OK/error、行数、截断双来源提示、参数行、26rem 有界滚动、
  原文/渲染切换默认原文）、分类内 时间序/大小序 chips；i18n 三语 +10 键。
- 门禁：detail/contextview -count=2 绿、Go 全量 0 FAIL、tsc -b/eslint 0、
  vitest 223/1687（首轮高负载 19 个无关用例 flaky 复跑全绿，沿先例记录）、
  drift PASS（571）、?mock=1 实机走查通过（截图存 artifacts）。
- 详见 releases/v4.80.0.md。

## 最新发布：v4.79.0（2026-09-04）「上下文对比上一步：逐类 signed delta · 跨压缩近似标注」

- 双源蒸馏规划阶段二.5 2.5a（收 v4.68 起三版连记 P1 欠账）。绑定面 570 零变更
  （delta 搭 GaeaContextView 既有返回结构）。
- Go：fold 请求组装点 surface 快照（与 Category 同拍；system/tools 最新 header
  整体估算防历史头重计）→ RequestDelta 逐类 signed delta；跨压缩 Approx、首请求
  First。前端：趋势卡请求详情「较上一步」delta 条（data-testid=ctx-delta-strip）+
  i18n 三语 +5 键 + mock 场景补样例。边界：不做 dsh 式逐步节点回放（蓝图成文）。
- 门禁：contextview -count=2 绿、tsc -b/eslint 0、vitest 223/1685、drift PASS（570）、
  ?mock=1 实机走查通过（browser-use 截图存 artifacts）。
- 详见 releases/v4.79.0.md。

## 最新发布：v4.78.0（2026-09-04）「任务强制终止收口：进程树击杀 · 两击确认」

- 双源蒸馏规划阶段一 1a；决策门 D1 采纳推荐默认。绑定面 569→570（+GaeaTaskKill）。
- Go：Progress.OnForceKill 进程树击杀钩子（尝试结束三处同拍清理）+ Manager.Kill
  （queued 原子取消/running 锁内快照记 cancelReq、锁外先杀进程再传播取消/幂等/
  无钩子诚实降级等价 Cancel）。前端：running「强制终止」两击确认（首击 3s 确认态
  防误杀，queued/stopping 保持单击）；bridge/spaceBindings/mock/i18n 三语 +3 键。
- 窄屏自动激活策略审计通过零改码（CSS 1239px ↔ JS <1240 一致）。
- 门禁：go vet 0、go test 全量除 1 个既有 TempDir 清理 flaky（单跑复验绿）、
  tsc -b/eslint 0、vitest 223/1683、drift PASS（570）。走查受限如实记录：mock
  无常驻 running 种子，以 TaskCenter 9 个 jsdom 交互用例为验收面（v4.62.0 A2 先例）。
- 详见 releases/v4.78.0.md。

## 最新发布：v4.77.0（2026-09-04）「任务页自动激活补全 · 强制终止」

- 纯前端、绑定面 561 零变更。新增：后台任务事件自动激活任务页；自动激活统一
  openTasksAuto（≥1240px 宽屏展开、窄屏不强制、沿用设置开关）；运行中任务按钮
  明确「强制终止」（queued=取消/stopping=停止中）。vitest 223/1681。
- 详见 releases/v4.77.0.md。

## 最新发布：v4.76.0（2026-09-04）「任务面板修正：整树折叠 · 圆角 8px · 树形线」

- 「子代理」分组头整体折叠/展开整棵树；点卡片也可折叠自身子级；卡片圆角显式
  rounded-[8px]；子树加 1px 树形线；打开对话收敛为卡片独立按钮。
  vitest 223/1680。详见 releases/v4.76.0.md。

## 最新发布：v4.75.0（2026-09-04）「右侧任务面板卡片化」

- AgentTree 子代理独立卡片：状态胶囊 + 模型/工具/耗时/token 指标行 + 运行实时
  预览 + 完成摘要；主 agent 主色底；视觉模型验收 92/100。vitest 223/1678。
  详见 releases/v4.75.0.md。

## 最新发布：v4.74.0（2026-09-04）「记忆界面技能重设计」

- 记忆主区页：hero 卡 + 事实/文档/建议三统计小卡 + 快速添加 + 单张视图大卡
  （分段/搜索/筛选/内容同卡）；TabButton 紧凑胶囊；视觉验收 9/10。
  vitest 223/1678。详见 releases/v4.74.0.md。

## 最新发布：v4.73.0（2026-09-04）「记忆迁入主区标签页」

- 删除左侧「记忆」入口（展开/折叠态）；ChatTabs 增「记忆」tab 于上下文旁；
  记忆抽屉改主区卡片页；/memory 与 Ctrl+K 改切主区 tab；useDrawers 收敛。
  vitest 223/1678。详见 releases/v4.73.0.md。

## 最新发布：v4.72.0（2026-09-04）「删除概览标签页」

- ChatTabs 收敛 对话/轨迹/上下文；删除 OverviewPanel 容器 + 命令条目；
  历史 overview 自动回落对话；StatsPanel 统计模块暂留未接线。vitest 223/1677。
  详见 releases/v4.72.0.md。

## 最新发布：v4.71.0（2026-09-04）「上下文页卡片化：8 统计小卡 · 行卡化」

- 用户点名「上下文统计应是 8 个小卡片」；自研规划（redesign/ui-ux-pro-max/
  ds-vision 读参考图）：8 个 ctx-tile 统计小卡、三大仪表卡图标章、事件/文件/
  浏览器节点行改 ctx-row cardlet、卡片表面抬升 + 零硬编码。vitest 224/1683。
  详见 releases/v4.71.0.md。

## 最新发布：v4.70.0（2026-09-04）「上下文页视觉重设计：数字层级 · 构成强调 · 仪表化」

- 用户点名「重新设计」后 v4.69 交互精修静态不可见（承认，本轮改肉眼可见）。
- 纯前端，绑定面 561 零变更、Go 零改动；逐项对齐 dsh-context styles.css
  实测数值（rc 10px/padding 14×16/title 600/stat value 14px/seg 圆角 5px）。
- ①数字层级放大（统计格 15/17px、当前上下文大数字+百分比 26px bold、环心
  16px、各行 11.5px）；②当前上下文宽卡强调（分段条 h-3→h-4 rounded-md、
  卡头 12.5px semibold、图例 11.5px）；③卡头「标题左+副注右」统一；④环形
  图 84→92px/stroke 10px；⑤v4.69 事件多选/趋势内联详情/99.89% 保留。
- 门禁：tsc -b/eslint 0（全量）、vitest 224/1683、drift PASS（561）、冒烟 200。
- 走查受限如实记录：mock 走查浏览器视口 756px（模拟面板仅 ~123px 高），宽版
  网格仪表需桌面实机复核；jsdom 27 用例为交互验收面。详见 releases/v4.70.0.md。

## 最新发布：v4.69.0（2026-09-04）「上下文页第三轮精修：图例联动 · 趋势卡内联详情 · 事件多选」

- 用户实拍 dsh-context v0.41.3 上下文页两张截图 + 源码复核（本机
  node_modules client.js / .tmp/dsh-context 检出）后继续对齐；技能
  （ui-ux-pro-max + design-taste-frontend）全程约束（Subtle motion/
  密度/语义色单源/禁 AI 紫）。纯前端，绑定面 561 零变更、Go 零改动。
- ①当前上下文宽卡图例 chip hover 联动（dsh hover-key 同款：悬停分类该段
  保持、其余段+空闲段 150ms 淡出 opacity 0.28，chip 微高亮，data-testid
  铺点）；②趋势卡 master-detail 单元——请求详情内联进趋势卡（删独立
  StepDetail 行，顶部分隔线）+ 默认选中最新请求（打开即有内容；钉住选择
  保留、请求消失自动回退最新）；③事件筛选改 dsh 多选 chips（去「全部」：
  全亮点一=单选、点掉=排除、单选再点=恢复全选，aria-pressed）；④四仪表
  卡头「标题左+副注右」单行排版；⑤Token 环心命中率两位小数；⑥死键
  contextview.pickHint 三语删除（点击引导已由趋势图例行承载）。
- 门禁：tsc -b/eslint 0（全量）、vitest 224 文件/1683 用例（净 +2）、
  drift PASS（561）、冒烟 200。蓝图 design-system/gaea/pages/context.md
  已更新为 v4.69 全宽网格仪表现状。
- 欠账（沿 v4.68）：浏览器「对比上一步变动」下拉（需 per-request 快照）；
  真实供应商用量卡；图例 hover 跨卡联动（浏览器同分类高亮）为远期。
  详见 releases/v4.69.0.md。

## 最新发布：v4.68.0（2026-09-04）「上下文页对齐 dsh-context」

- 用户展示 dsh-context v0.41.3（本地 ~/.dsh/profiles/web/node_modules/
  dsh-context，client.js 6760 行已读）并点名对齐。四线并行 + 主代理收口：
  线A Go FoldTimeline 单趟折叠 ContextTiming（wall/ttft/gen/toolsMs/tools
  排行数组；秒粒度近似如实注记；全零省略）；线B 四仪表卡（context/cards：
  统计 8 格/Token 环形/耗时环形/会话信息）+ 当前上下文宽卡（空闲段）+
  底部汇总条；线C 上下文浏览器分类折叠组（项数/搜索/归档/分页）+ 文件
  活动聚合树（三排序）；线D Agent 径向树（SVG，agentNetworkStore 接线）。
- 布局 v4.67 双栏 tab → dsh 全宽网格仪表（用户意图照 dsh）；i18n 三语
  +47 键；功能零删减。
- 门禁：Go 定向包全绿、tsc -b/eslint 0、vitest 224/1681、drift PASS（561）、
  冒烟 200；judge 三图 pass 零 must_fix。
- 欠账：浏览器「对比上一步变动」下拉（需 per-request 快照）；真实供应商
  用量卡。详见 releases/v4.68.0.md。

## 最新发布：v4.67.0（2026-09-04）「上下文标签页重设计：驾驶舱三区布局」

- 用户点名技能刀（ui-ux-pro-max --design-system --density 8 --motion 3）：
  设计蓝图落盘 design-system/gaea/pages/context.md（继承星枢 Master 令牌）。
- ContextView 单列 8 卡 → 三区：①ContextHeader 融合原统计卡/水位头/当前
  构成（9 chips+六分类分段条+图例+水位+告警）②左过程轴（趋势→StepDetail
  就地联动→事件流）③右 inspector 三 tab（浏览器/文件活动/Agent；
  localStorage gaea.context.inspectorTab 偏好；<1100px 回落单列）。
- 功能零删减（八块信息只重组）；测试结构同步 4 处（水位 1 处显示/tab
  先切后断言），13/13 全绿；judge 走查 ?mock=1 双宽截图 pass 无 must_fix。
- 门禁：tsc -b/eslint 0、vitest 221/1647、app+contextview 包全绿、
  drift 561、冒烟 200。详见 releases/v4.67.0.md。

## 最新发布：v4.66.0（2026-09-04）「子代理会话提升 · TasksWorkbench 轮询收敛」

- GaeaPromoteSubagent（+1 绑定，560→561）：transcript 忠实投影为独立新
  顶层会话——写前写后投影往返双校验（不等价不落盘）、诚实降级（system
  提示不随迁/孤立工具记录丢弃）、ref 仅 sa_ / running 拒绝 / 原运行逐字
  节不动、每次提升新副本。SubagentThread 头部「保存为新会话」按钮 +
  三语 +3 键。+8 Go 用例。
- TasksWorkbench net+runs 迁两 store：四消费点全部共享单轮询；失败横幅
  +重试不再吞错；新测试文件 11 用例。
- 门禁：Go 全量 exit 0、tsc -b/eslint 0、vitest 221/1647、drift PASS（561）、
  冒烟 200。详见 releases/v4.66.0.md。

## 最新发布：v4.65.1（2026-09-04）「追问失败感知 · 任务退出码 · 轮询收敛」

- 线A 任务 ExitCode（指针语义+Retry 清旧码+独立锁防自锁），TaskCenter
  失败行常显 exit N；强杀欠账过期销账（协作取消已足够）。+6 用例。
- 线B meta.FollowUpError 经 SubagentRunView/TranscriptView 带出（omitempty），
  SubagentThread 失败判定先于快照增长；**修 v4.64.0 真回归**（defer stop()
  时序致 meta 永久卡 running）+ 回归钉。+9 用例。
- 线C agentNetworkStore（单例轮询器 9 用例）+ SubagentsPanel net 迁入 +
  runsLoadFail 三语键。TasksWorkbench 双源轮询收档为下一消费点。
- 门禁：Go 全量 exit 0、tsc -b/eslint 0、vitest 220/1636、drift PASS（560）、
  冒烟 200。详见 releases/v4.65.1.md。

## 最新发布：v4.65.0（2026-09-04）「三线并行收欠账」

- 线A 追问失败诚实化（SubagentThread）：tab 内联错误条+失败气泡保留原文
  +一键重试/撤销；快照接管守卫修正（失败态不误清、不空转轮询）。+3 用例。
- 线B 「办公工作台偏好」设置卡（设置中心 → 办公置顶）：四个自动展开偏好
  开关+说明+即时生效标注；新 lib/tasksPrefs.ts；澄清 autoOpenJobs 键不存在
  （过期欠账销账）。+9 用例。
- 线C SubagentsPanel/Sidebar 迁共享 subagentRunsStore：同屏 3 路重复轮询
  收敛为 1 路；store 每路径建册+loading/ready/error 状态机+reload+失败保留
  旧快照自愈（向后兼容，App 零改动）；失败态不再静默白板。+7 用例。
- 线D releases/README.md 重写为归档索引（原为主 README 错位副本；历史文件
  零删除）。
- 收口：tsc -b/eslint 0（抓 1 处测试类型收窄修复）；vitest 219/1624；
  drift PASS（560）；冒烟 200；实机走查（设置新卡+任务面板）PASS。
  详见 releases/v4.65.0.md。

## 最新发布：v4.64.3（2026-09-04）「任务管理树呼吸感优化」

- 用户点名树过于紧凑。AgentTree 节点行 py-1.5/gap-1/缩进 depth×12、标题
  12px、统计 10px、状态点 8px；节点卡间距 gap-1.5；运行活动预览行与
  「本地模型工具」区块同步放宽；信息零删减（简化≠删除红线）。tsc -b/
  eslint 0、vitest 217/1605、冒烟 200、实机走查 PASS。绑定面 560 零变更。
  详见 releases/v4.64.3.md。

## 最新发布：v4.64.2（2026-09-04）「修复：任务管理树丢失零工具子代理」

- 用户实机报告：任务管理面板不出现新派发子代理（running 计数会变、列表
  缺行）。根因=FoldAgentNetwork 以「拥有子工具记录」定义子代理节点，纯
  调研型（零工具调用）永远成不了节点；enrich 只富化不补挂。修复=enrich
  AgentNetwork 两段式：未被承载且非 model_tool 的 run 补挂合成节点
  （id=sa_ ref，前端可开转录）。+3 回归（internal/app/
  gaea_ui_contextview_test.go）；重建后实机回归：历史零工具 run 全部
  出现在树上。绑定面 560 零变更。Go 全量 0 FAIL、vitest 217/1605、
  drift PASS（560）、冒烟 200。详见 releases/v4.64.2.md。

## 最新发布：v4.64.1（2026-09-04）「修复：mt_ 信封双层嵌套转义墙」

- 用户实机截图复检发现 mt_ 输出仍是信封转义墙：信封**双层嵌套**（外层
  data.result 里装工具自身 message 信封），v4.62.2 单层拆包不足；且历史
  转录已落盘写端修复无效。修复=写端递归拆包（unwrapModelToolOutput，
  4 层上限）+ 读端 unwrapEnvelopeText 显示侧同语义拆包（SubagentThread
  mt_ 内容渲染前调用，旧数据即刻可读）。双侧回归测试；vitest 217/1605、
  drift PASS（560）、冒烟 200。详见 releases/v4.64.1.md。

## 最新发布：v4.64.0（2026-09-04）「Side Chat 式追问：子代理会话 tab 内可持续提问」

- 用户点名对标 dsh Side Chat。TaskTool.RunFollowUp（continue_from 管道：
  PrepareContinue 校验 running/mt_/空间 + MarkRunning/TrackProgress 快照 +
  SaveCompleted/Failed）+ FollowUpSink（只放行文本增量走专用通道，产出
  留在子代理会话内）+ boot Options 接线（EmitSubagentText/OnFollowUpReady）
  + App 绑定 GaeaSubagentFollowUp（后台 goroutine 即刻返回/同 ref 去重/
  主回合运行中拒绝）+ FE 追问输入框（乐观气泡/追问期轮询/mt_ 隐藏）。
  **绑定面 559→560**。vitest 217/1603、drift PASS（560）、冒烟 200。
  详见 releases/v4.64.0.md。

## 最新发布：v4.63.4（2026-09-04）「mt_/长文本输出 Codex 式有界渲染」

- 用户点名本地模型工具输出渲染优化。BoundedAssistantMessage：mt_ 标签页/
  超 4000 字 assistant 内容默认限高 26rem 滚动（Markdown 照常渲染）+
  「展开全部（N 字）/收起」+字数标注；流式行保持跟随。i18n 三语 +3 键。
  vitest 217/1602、drift 559、冒烟 200。详见 releases/v4.63.4.md。

## 最新发布：v4.63.3（2026-09-04）「对标 dsh：单轮询聚合 + 自动切任务视图」

- 用户点名借鉴 dsh-better-sidebar（源码级对照：subagents.live 批量接口
  #298、0→N 自动展开去抖 #314、服务端折叠 LastActivity、Side Chat 设计）。
  采纳两条：①共享单轮询 store（lib/subagentRunsStore.ts，App 两处独立轮询
  并入，任务树/左栏子行后续刀）；②新子代理 0→N 自动切右栏任务视图（500ms
  去抖重臂+偏好 localStorage 默认开）。vitest 217/1601、drift 559、冒烟
  200。Side Chat 式追问列后续大刀。详见 releases/v4.63.3.md。

## 最新发布：v4.63.2（2026-09-04）「并行子代理：批量派发不再串行排队」

- 用户实测三路子代理串行。实锤：账本同秒 3 条 task dispatch、三个 sa_
  运行创建时间相隔 ~4 分钟=串行点在分区器 getConflictKey 的全局冲突键
  "!spawn"。修复=task/run_skill 改每调用唯一键 spawn:<callID>（N 路同批
  并行，runParallel ≤8、panic recover；ID 缺失退化共享键串行宁慢勿错）；
  TaskTool 用量 usageMu 互斥合并（并行安全）。install_skill 保持串行。
  如实说明：本地模型推理服务端仍可能排队，工具段真实重叠。新增分区回归
  测试 3 例。vitest 216/1597、drift 559、冒烟 200。详见 releases/v4.63.2.md。

## 最新发布：v4.63.1（2026-09-04）「主对话子代理卡片整卡可点」

- 用户点名：单击主对话里的子代理卡片直接打开子代理会话 tab。taskActivity
  新增 openTarget/openHandler 注入点（App 注册：runs 缓存预填+唯一 running
  命中回退，宁缺勿错）；ToolCard task/run_skill 卡整卡可点（title 提示），
  运行中活动行同入口；tab 打开后 5s 轮询自校正。i18n 三语 +1 键；
  vitest 216/1597、drift 559、冒烟 200。详见 releases/v4.63.1.md。

## 最新发布：v4.63.0（2026-09-04）「子代理会话 tab 输出对齐主对话 Codex 式渲染」

- 用户点名「子代理的输出也要参照父代理的 Codex 样式」：SubagentThread 消息
  流整体换主对话同款组件——正文/思考 AssistantMessage、工具 ToolCard；
  映射层 lib/subagentRender.ts（toolCallId 配对/乱序/孤儿降级/运行中
  running）纯函数可单测（+4 例）；流式实时行同款。vitest 214/1594、
  drift 559、冒烟 200。详见 releases/v4.63.0.md。

## 最新发布：v4.62.2（2026-09-04）「修复：对话标签页实时输出失聪」

- 用户实机报告三问题（对话无过程/任务中心恒空/mt_ 转义墙）→ 实锤定位：
  **EventsOff(channel) 全清语义**——v4.61 SubagentThread 卸载时把主对话
  gaea-event 订阅连带炸掉（账本 306 条完整+前端零报错+轮询面板正常=铁证；
  wails v2.13 runtime 源码确认 EventsOn 返回按监听者注销函数）。修复=
  lib/wailsEvents.ts 精确注销+前端禁用 EventsOff+3 回归测试；附带 mt_
  信封拆包（unwrapModelToolOutput）与 GaeaTaskList 传 []。
- 验证：Go 全量绿、tsc/eslint 0、vitest 214/1590、drift 559、冒烟 200
  （首次构建因运行实例锁 exe 未写入，taskkill 重建后 hash 已核异）。
  详见 releases/v4.62.2.md。

## 最新发布：v4.62.1（2026-09-04）「修复：子代理流式打断对话窗过程可见性」

- 用户报告「对话窗又看不见过程」→ 根因实锤：v4.62.0 的 SubagentText 走
  gaea-event 消费 seq 但 wire-only 不落账本，破坏 v4.26 缺口防线前提，
  密集流丢件→不可愈合缺口→反复 resync 整体重建对话视图。修复=分道专用
  通道（gaea-subagent-text，无 seq、有损无妨）+ 死映射移除 + forwarder
  不变量成文 + bridge onSubagentText + 回归测试（seq 无断号钉子）。
- 验证：Go 全量绿（1 个 Windows TempDir 清理竞态 flaky 复跑通过）、
  tsc/eslint 0、vitest 214/1587、drift 559、冒烟 200。详见 releases/v4.62.1.md。

## 最新发布：v4.62.0（2026-09-04）「办公板块：子代理逐 token 流式 · 交付验收闭环 A2」

- **两刀快照发布**：①线 A 子代理逐 token 流式——`SubagentText` 事件
  **wire-only**（EventLogSink 免落盘：增量全文由 SubagentMessage 收尾 +
  子代理自身 transcript 承载），task 路径 subSinkFor 增 refSrc、run_skill
  路径 RunPersistedSubAgent 外层 refTextSink 注入，双路殊途同归；前端
  SubagentThread 流式缓冲实时行（MemoMarkdown streaming）+ **快照接管
  reconcile**（快照尾条含缓冲开头或长过基线 → 清缓冲），P1 销账。②线 B+C
  交付验收闭环 A2——Word 修改队列（docxAnnotationQueue 纯逻辑：状态机/
  归一化定位坐标映射/runQueue 串行编排再定位；DocxPreview 队列侧栏：攒批
  去重、执行进度 n/m、汇总、单条重试；「执行全部」走 OfficeEditText→
  DocxApplyEdit→DocxAcceptChanges(accept) 通道，定位不到诚实 skipped 绝不
  错位替换）+ 版本结构化对比（docxTextDiff 段级 LCS/xlsxCellDiff sheet+
  单元格对齐；versionCompare 按扩展名分派，结构不可信降级 unsupported 宁
  漏勿误；VersionTimeline docx 序号列/xlsx 分组差异表+截断提示）。
- **i18n**：三语 +35 键（docxQueue.* 28 + vcompare.* 7，zh 逐字）。
- **验证**：go vet/test 全量绿；tsc -b/eslint 0；vitest **214 文件/1586
  用例**；drift PASS（**559** 零变更）；build.bat 冒烟 /api/health 200。
  **走查受限如实记录**：新能力依赖真机 docx/子代理数据，?mock=1 无法驱动，
  以 60+ 新 jsdom 用例为验收面（同 v4.59 A1 先例）。详见 releases/v4.62.0.md。

## 最新发布：v4.61.0（2026-09-04）「子代理会话闭环 · Word 目录侧栏」

- **四个未发版快照合并发布**：①Word 预览目录侧栏（eb84c82c：docxOutline
  解析/定位高亮/章节修改指令，纯前端）；②子代理 tab 对齐主代理（5c52a5b8：
  MemoMarkdown 正文 + 状态点 + 完整 title）；③子代理 transcript 真机接线 +
  本地模型工具同 UI（1f70e06d：惰性 SubagentStore 全量落盘 + ~1s 快照实时化、
  后台子代理落盘修复；ModelBacked 标记 vision/summarize_file → mt_ 变相子
  代理，同一行/区块/tab；kind/tool/title 读端扩展）；④子代理入口收敛两级
  （aa57784c：task + run_skill，删三办公顶层包装与 explore 等分类残留）。
- **验证**：Go 逐包全量绿（test-all.ps1）；vitest **211 文件/1535 用例**；
  tsc -b/eslint 0；check-bindings-drift PASS（**559**）；版本三源 4.61.0
  sync/check PASS；产物 gaea-v4.61.0.exe 冒烟 /api/health 200 通过；SHA256
  见 releases/SHA256SUMS-v4.61.0.txt。记录：releases/v4.61.0.md +
  CHANGELOG/README 版本表；欠账清单见发布说明（逐 token 流式 P1 等）。

## 最新发布：v4.60.0（2026-09-03）「better-sidebar pane 化三刀 · 文件打开统一开 tab」

- **三个未发版快照合并发布**：①右栏 pane 工作台（d856353e：欢迎卡→视图/
  文件/浏览器/任务 tab、点子代理独立会话 tab、旧两级组件删除）；②左栏子代理
  会话入口（cf1bf35：父会话行展开→子代理子行→独立 tab，复用 GaeaSubagentRuns，
  绑定面 **559 不变**）；③文件打开统一开 pane 文件 tab（4a0cae7a+6ca03e4d：
  sidebarRegistry.openPaneFileTab + lib/paneFileOpen 注入，产物/权威登记/正文
  交互卡/变更行与资源管理器同 tab 条，未注册回落大预览）。
- **习惯固化**：并发子代理写入 .gaea/AGENTS.md「执行纪律」（d6246f99），默认
  执行无需点名。
- **验证**：Go 全量 **121/121 包**、vitest **210 文件/1525 用例**、
  tsc -b/eslint 0、drift PASS（559）；产物 gaea-v4.60.0.exe 冒烟
  /api/health 200 通过；SHA256 见 releases/SHA256SUMS-v4.60.0.txt。
- 记录：releases/v4.60.0.md + docs/better-sidebar-port-2026-09-03-worktree.md
  + docs/snapshots/2026-09-03-better-sidebar-port/。

## 在途快照：Word 预览目录侧栏（eb84c82c，未发版）

- 用户确认「已实现单独 WPS 打开」后点名下一步：强化 Word 打开后的编辑/预览
  能力，例如可打开 Word 目录。本刀落在 gaea 内置 Word 版式预览
  （DocxPreview，文件 pane tab/大预览共用）——纯前端、**绑定面 559 零变更**。
- **docxOutline.ts 纯解析**（docxOutline.test.ts 6 用例）：解 word/document.xml
  + styles.xml，标题判定优先级 = 段落 outlineLvl（9=正文显式排除）→ 样式
  outlineLvl / heading(标题) 样式名/id / basedOn 链继承；TOC1 与页眉页脚不计
  标题，防「目录页/页眉同名」抢锚点。
- **DocxOutline.tsx 目录侧栏**：工具栏「目录」按钮开合；标题按级缩进、计数；
  点条目 scrollIntoView + 短暂高亮锚点段落（jsdom 无 scrollIntoView 也安全）；
  条目右侧 Pencil = 插入「请修改 <文件名> 中『<节>』一节：」composer 模板
  （与 PptxOutline 修改指令/引用到对话同通道，不自动发送）。
- 布局改造：DocxPreview 根 flex 化，渲染容器与目录侧栏同行；渲染期间容器
  隐藏（docx-preview 纯 DOM 构建无布局依赖），加载/降级状态块让位；
  renderAsync 完成后解析+锚点链接，失败只降级目录不伤版式。
- 验证：vitest 新增 8 用例（docxOutline 6 + DocxPreview 目录集成 2，净
  +8 → 1533）；tsc -b / eslint 0；全量 210 文件 1532/1533 过（1 个
  ProgrammingPage「重新检查」既有 flaky 单跑通过，与本刀无关）。

## 在途快照：子代理会话 tab 对齐主代理（5c52a5b8，未发版）

- 用户拍板 **不做 WPS COM**；下一步把子代理会话 tab 显示向主代理对齐。
- **SubagentThread 正文 Markdown 化**：assistant 消息从纯文本
  whitespace-pre-wrap 改为 MemoMarkdown（与主对话 AssistantMessage 同一
  渲染器，加粗/列表/代码块/链接同款）；system/user/tool/思考折叠不变。
- **tab 实时状态点**：ChatTabs 会话 tab 增加 status 字段——运行中青色点/
  失败红点/完成绿点 + title 完整详情（任务 ｜ 状态 · 模型），替换此前裸
  ref title；App 侧新增 5s 轮询（usePollingGate 门控，与左栏子代理子行同
  数据源 GaeaSubagentRuns 同口径），tab 状态与 SubagentThread 头部徽标不再
  冻结在点击快照——子代理跑完/失败后 tab 状态点与面板同步变色。
- 验证：vitest 净 +2 → **211 文件/1535 用例全绿**；tsc -b/eslint 0；
  绑定面 559 零变更。

## 在途快照：子代理 transcript 真机接线 + 本地模型工具同 UI（1f70e06d，未发版）

- 用户以市场对照为反馈「开始」P0：真机数据源 + 运行中可看；并追加口径
  「调用本地模型的工具（vision/summarize_file）也是变相子代理，用同一 UI」。
- **真机接线**：boot 惰性 SubagentStore（目录随 ctrl.SessionPath 解析，
  与 EventLogSink 同晚绑定时序）→ taskTool.WithTranscripts 生产启用 +
  skillRunner 派生（run_skill/explore/research/review/security_review）经新
  RunPersistedSubAgent 同等待遇（meta.Title=任务本体，UI 标题不以技能正文
  开头）；task 工具每次尝试 MarkRunning + TrackProgress（~1s 原子快照写盘，
  stop 先 final flush 再终态写，终态 CreatedAt/Title/Kind 守恒——顺带修旧
  后台 run_in_background 子代理从不落盘缺陷，job 闭包内 finalize）。
- **本地模型工具 mt_**：tool 新增 ModelBackedTool 标记（vision、
  summarize_file 一行声明）；boot 收集集合注入主执行器
  SetModelToolRecorder；AgentRunner 在 pre-exec 起点开 mt_ 记录（参数齐后
  更新标题）、ToolResult 收尾（成败如实）、回合 defer 兜底失败（流中断/
  抑制不残留 running）。子代理 runner 不装配——其内部工具活动已在 sa_
  transcript，不重复制造噪音。
- **读端/UI**：SubagentRunView/Transcript 加 kind/tool（旧数据 subagent
  降级）与 meta.Title 优先任务摘要；valid ref 扩 mt_（防穿越同口径）；
  左栏会话展开子行、任务页「本地模型工具」区块、ChatTabs detail、三语字典
  新增 label/section 两键；SubagentThread 运行中订阅 tool_dispatch/
  tool_result 事件 800ms 节流补拉（工具边界即时，3s 轮询兜底）。
- 验证：Go 相关包全绿（agent/boot/tool/largefile/app；整树 go test 仅
  control 单测跨包并发干扰复跑单包通过，与本刀无关）；vitest 全量
  **211 文件/1535 用例**、tsc -b/eslint 0、check-bindings-drift 559 PASS；
  新增 store 生命周期/惰性目录/进度 flush + app 绑定 mt_ 用例。
- 遗留（如实）：运行中仍是「消息/工具边界级分段刷新」，逐 token 真流式
  需要独立 SubagentDelta 事件通道 + streaming 渲染（P1）；技能子代理
  transcript 首条 user 仍含技能正文（Title 已独立，展示不受影响）。

## 在途快照：子代理入口收敛 task + run_skill 两级（aa57784c，未发版）

- 用户问「子代理是否分类过多且限制能力？Codex/zcode 简单、靠父代理任务消息
  」→ 核对属实后拍板收敛。真注册的「分类工具」只有 format-convert /
  chart-builder / doc-assemble 三个顶层包装；explore/research/review/
  security_review 只是分类/模板残留（无注册点）。
- **移除**：boot 对 skill.BuiltinSubagentTools 的注册（类型+工厂+相关测试
  一并删除）；explore/research/review/security_review 从 subagentMetaTools /
  批次冲突表 / 任务分类增配清单移除；compact 隐藏四分类的死代码删除。
- **保留为模板/技能**：三办公技能仍在内置 Skills 索引，经 run_skill 或
  slash_command 按名调用；explore 等四模板前缀仍供同名 runAs=subagent 技能
  共享 L4 前缀缓存（缓存层，不构成用户可见入口）；per-skill 模型覆盖保留。
- **提示面收敛**：系统提示「子代理入口只有两级：task + run_skill，任务消息
  必须自包含」；技能子代理默认仍继承父工具全集（剔除 task/run_skill 防递归
  + persist-write 护栏不变）；前端能力矩阵去掉三包装工具卡、欢迎页 chips 改
  run_skill 措辞、mock 去掉 research 幽灵技能。
- 验证：Go skill/boot/cache/agent/config 与 internal/app 全量绿；vitest 全量
  211 文件/1535 用例；tsc -b/eslint 0；绑定面 559 零变更。

## 当前状态

- **此前发布：v4.59.0（2026-09-03）「继续：i18n 二批 · 搜索落划线 · 自定义
  引擎用户价目」**：A——设置五面板+SettingsSection 入三语字典 +192 键/语言
  （682→874，设置中心九面板全量 i18n）；B——搜索命中「落为划线」永久标注
  （区间→摘录口径适配）+ReadingPrefsPanel 拆分净减 47 行 +13 用例；C——
  自定义引擎用户价目 v1（user_price_in/out 指针三态+折算最高优先层+零值
  语义回归锁，559 不变，models 重生成）；收口抓潜伏雷——ChatPanel 直调
  wailsjsCompat 浏览器同步抛致设置聊天分组白屏（`?.` 不防执行），try 兜底
  修复。559 零变更，vitest 204/1457，?mock=1 九分组零错误。详见
  releases/v4.59.0.md。

- **此前发布：v4.58.0（2026-09-03）「继续：三线并行收欠账 · 同章搜索重定位
  缺陷修复」**：A 小说域——同章搜索重定位缺陷根因实锤+最小修复（searchLocateSeq
  入定位 effect 依赖；回归测试反向验证），ChapterPage 拆分第三批净减 67 行
  +41 用例；B dev mock 域——GaeaBenchmark 五方法+GetModelMonitor 中性空态/
  诚实失败+契约 7 用例；C i18n 域——设置三面板入三语字典 34 键/语言（zh
  保真，648→682）；主代理收口——GetModelMonitor 三消费点迁 getModelMonitor()
  三态回退（wailsjsCompat 直读绕过 bridge mock =「wailsjsCompat 生成物消费族」
  欠账真身）、mock 补 GetEngines 空态。559 零变更，vitest 202/1442，?mock=1
  零横幅。详见 releases/v4.58.0.md。
- **此前发布：v4.57.0（2026-09-03）「设置中心化繁为简：删四补一 · 界面语言
  入口」**（用户点名刀）：删四（grep 核真伪、零功能损失）——绘梦纯展示卡、
  小说剧照零交互卡（并入 desc）、关于「系统信息」→「存储路径」、api/
  settings.ts 七个零消费死导出；增一——通用分组「界面语言」切换（i18n
  setPref 首个入口，跟随系统/简体/繁體/English）；修一坑——ImageGenPanel
  补 comfyui_url/image_save_dir 回填防清空已存配置。559 零变更，
  vitest 197/1393。走查注记：IAB 内 antd 下拉鼠标点不开、键盘可开（环境
  怪癖），选项派发点击验证语言双向切换。详见 releases/v4.57.0.md。
- **此前发布：v4.56.0（2026-09-03）「继续完善：拆分第二步 · mock 补 Herdsman
  族 · 并行 task 卡关联」**：三线并行——A：ChapterPage 拆分第二批（三函数再
  搬 chapter/readingHighlight.ts，累计净减 ~111 行+14 用例；ref 包装保留论证
  「可简化≠应简化」；发现疑似既有缺陷：同章重复点搜索命中不重定位）；B：
  mock 补 Herdsman 七方法（中性空态+诚实 ok:false，契约 5 用例，引擎管理
  横幅消除）；C：task 卡 provider 升级 (ref,args)+matchRunningRun 唯一命中
  （+13 用例，宁缺勿错）。收口补 GetModelCallStats 空聚合（统计横幅消除）。
  559 零变更。**新欠账：wailsjsCompat 生成物消费族浏览器 mock 缺口
  （ResourceMonitor 直读 window.go 报资源加载失败，建议独立刀迁 bridge）；
  GaeaBenchmark* 五方法未 mock**。详见 releases/v4.56.0.md。
- **此前：v4.55.0（2026-09-03）「继续完善：拆分补测起步 · mock 补面 ·
  failover 文案 label 化」**：三线并行——A：ChapterPage 首次拥有测试（阅读
  高亮三函数搬 chapter/readingHighlight.ts 净-49 行+15 用例；拆分第二步=
  applyTextHighlight/textAtScrollTop 等仍在组件内）；B：mock 补
  Get/SetEngineFailover（+engines.ts App() 浏览器回退 ?? bridgeApp——注意
  mock-scenarios 锁 window.go 必须为空，回退只能在调用点做；mock 缺
  HerdsmanModelCatalog 新欠账）；C：failover toast 统一 engineLabel（三级
  回退不变）。销账：右舷虚线交叠（DOM 证伪）。走查：?mock=1 调度三开关点亮
  +CUA 三方核对。559 零变更。详见 releases/v4.55.0.md。
- **此前：v4.54.0（2026-09-03）「继续完善：三线并行收欠账」**：
  A 办公面板（任务中心空态文案+MergedPanel 分隔线）；B 首页「编程」span 4×1
  宽瓦片收末行空位（30 单位整除，四档核算入 home.md）；C eslint 三 warning
  清零（**全量首次 0/0**）。559 零变更；judge 2/2 pass。详见 releases/v4.54.0.md。
- **此前：v4.53.0（2026-09-03）「办公欢迎界面化繁为简：四点降噪 · 右栏 6→4」**：
  用户四点拍板——删 ContextBar（上下文走主区标签页）、删侧栏底部模型卡
  （FeatureModelBar 连组件清，入口统一顶栏）、产物+变更与任务+分工**直接合并
  为一个面板**（用户纠正：非二级标签/段切换；MergedPanel 上下分区同屏全可见；
  一级 Tab 6→4；旧 id changes/subagents 裸 id/记录/启用集三路径别名收敛）。
  零功能删除。judge 3/3 pass 无 must_fix。**欠账：任务中心空态副文案与办公
  语境不符（占位残留）；产物/变更分隔线偏淡**。详见 releases/v4.53.0.md。
- **此前：v4.52.0（2026-09-03）「首页重设计：星枢港 · 双舷驾驶舱」**：
  用户点名「使用技能重新设计首页」（ui-ux-pro-max --design-system AI-Native UI
  方向+星枢令牌）。ModuleLauncher/css 全量重写：左舷=紧凑 Hero（左对齐，27px）+
  命令条五要素+Bento（办公旗舰 4×2 + 板块/编程(独立窗口徽标)/设置瓦片全入格，
  manifest 驱动）；右舷 300px=内核遥测（模型/引擎/CPU·MEM·GPU 三表+ComfyUI
  徽标）+写作进度环+最近会话+记忆脉搏+晨报（仅 work）。零功能删除：chips 收编、
  状态细条+底部信息条并右舷、门廊瓦片化。≤1180 侧舷下落+旗舰单行横向排布
  （judge must_fix）。i18n 三语 648 键（+3/改3/删22 含 9 v3 死键）。
  judge 两轮 overall pass。**新欠账：矩阵末行右一空位（10 瓦片+3 列固有）**。
  详见 releases/v4.52.0.md。
- **此前：v4.51.0（2026-09-03）「壳层左缘修复 · 创建青鸟助手深链直通绑定」**：
  双线并行子代理——A：MainLayout 右列预留 --v3-rail-w 48px（根因=rail fixed 浮层
  热区，v4.50 欠账销账）；B：创建青鸟助手 → wxFocus sessionStorage 焦点 → NAVIGATE
  crossSpace 跨空间 → 选中未绑定助手直开扫码（收口修复 S2.1 同空间守卫静默丢
  弃缺口；MainLayout 新增显式 crossSpace 分支）。附带修造价「最近更新」备注窄
  列叠压。judge 视觉验收 overall pass。**工具欠账：IAB 截图管道两次卡死，Edge
  无头 puppeteer-core 备援通道已建（%TEMP%\pptr-shot）**。详见 releases/v4.51.0.md。

- **最新发布：v4.50.0（2026-09-03）「造价数据库化繁为简」**：绑定面 559 零变更——
  导航 8→6（价格源+价格仓库+询价库归并「价格数据」三段；知识图谱降为概览「关联图
  谱」镜头）；询价库从成本条目隐藏 icon 视图升格一等子页；概览快捷入口 7→4；
  CostLibraryView 拆 inquiry 模式与 compact/onInsert 死管线；删不可达 memoryhub/
  CostLibrary；dev mock 补询价/五算九方法（走查抓到真缺口）。judge 视觉验收两轮
  overall pass。**新欠账（建议壳层刀）：全局 main 区未给收起态 rail 预留左边距，
  全板块最左列首字符被裁（ref-weixin 基线证明非本刀回归）**。设计蓝图
  pages/cost.md。详见 releases/v4.50.0.md。

- **最新发布：v4.49.0（2026-09-02）「青鸟助手生命周期补全」**：双线并行子代理——
  ①编辑已有助手（改名/换人格/立绘，选择器抽 PersonaPickerPanel 新增/编辑共
  用，自定义人格 id 不在选项时保留原值）；②角色库 custom 角色卡一键创建未绑
  定助手；③**镜像守卫**：EnsureAssistants 跳过 custom 命中行（修复 v4.48 隐
  患：custom 角色被选为人格后启动时被镜像覆写）。**微信侧剩余欠账：从青鸟板
  块深链跳回角色库（创建后引导绑定目前靠文案）**。详见 releases/v4.49.0.md。

- **最新发布：v4.48.0（2026-09-02）「青鸟：板块更名 + 人格选择器」**：微信助手
  更名「青鸟」（青鸟传信；board id/绑定面不动，意图别名加青鸟，原名兼容）；
  新增助手弹窗手填人格 ID → 双栏选择器（轻语预设+角色库可聊天角色、搜索、
  立绘/人设详情预览、18+ 过滤、portraitUrl 落库回显）。**微信侧下一刀候选：
  编辑已有助手人格/立绘（现仅新增可选）、从角色库角色卡一键创建助手**。
  详见 releases/v4.48.0.md。

- **最新发布：v4.47.0（2026-09-02）「微信助手星枢化：通讯枢纽工作台」**：UI 重构刀
  （绑定面 559 零变更、功能零删减）——三分区布局（玻璃细条+左通道轨道+主区三视图）、
  通道状态三重传达、扫码流三步指示、dev mock 补微信域、设计蓝图 pages/weixin.md。
  本刀无新增欠账。详见 releases/v4.47.0.md。

- **最新发布：v4.46.0（2026-09-02）「小说板块第二轮」**：伏笔登记表闭环（写入口+合
  并语义+面板 CRUD）、导出扩展（EPUB 封面/仅主线/DOCX）、伴读问书多轮化、一致性 AI
  深检 v0（Continuity Linter MVP，诚实降级）。绑定面 557→559。**小说侧下一刀候选：
  ChapterPage 拆分补测、搜索高亮落划线、branches.json 历史**。详见 releases/v4.46.0.md。

- **最新发布：v4.45.0（2026-09-02）「百炼全量下线」**：用户拍板删干净——引擎/配置/UI/
  微信改图链（v4.9 起）全量退役，img2img 保留 ComfyUI/Herdsman；SetImageBackend 收 4 参
  （绑定面 557 零变更）；wx_agent 工具面 7→6；gen_bindings 空白参数名修复。详见
  releases/v4.45.0.md。

- **最新发布：v4.44.0（2026-09-02）「绘梦专项三刀：百炼模型残留修复 · 引擎枚举
  单源化 · 模板画幅落地」**：绘梦板块专项摸底后收三条互不相交线（主代理直改 +
  测试收口，无并行子代理）：①**百炼模型残留修复（真 bug）**——dashscope 后端
  GetImageBackendInfo/SetImageBackend 空或残留模型（grok-imagine-*/krea2）归位
  qwen-image-edit-plus（手填官方编辑系保留，GetImageBackendConfig 同口径）；
  前端 modelOptions 对 dashscope 固定三档官方编辑模型 + 切后端 defaultModel 归位
  默认；queue 提交前 backendSupportsMode 拦截引擎固有模式残留（百炼仅改图/GLM
  仅文生图）。②**引擎枚举单源化 + 补 GLM**——meta.ts 收敛唯一 BACKEND_OPTIONS
  （能力位）+ backendLabel/isLocalBackend/backendSupportsMode；ControlPanel/
  ImageGenPage 顶条/启动消息/GenerationBar 门禁统一走单源（修复「xAI 云端 云端」
  拼接重复与 dashscope/glm 无 label 回退裸 id）；引擎下拉新增 GLM（txt2imgOnly
  禁用+残留专属警告）。③**模板推荐画幅落地**——templateSizeToPreset 把模板 size
  比例标签映射到实际画幅（2:3 立绘→自定义 768×1152，仅 txt2img 生效）；
  applyTemplate 同步画幅、TemplatePickerModal 不再丢弃 size 字段。**验证**：
  Go 全量 exit 0（+8）、tsc -b/eslint 0、vitest 1285/1285（+11）、drift 557、
  版本四处 4.44.0。**下一刀候选（绘梦侧）**：dashscope 图生图 UI 内「参考图+
  指令」一键改图入口（v4.40 引擎能力就绪）、百炼 txt2img（qwen-image-2.0 系）
  后端放行、GLM 切换前置引导。详见 releases/v4.44.0.md。

- **上一发布：v4.43.0（2026-09-02）「小说板块优化四刀」**：小说板块自 v4.3.1
  后首次专项投入（摸底盘点后四条互不相交线并行子代理，零 UI 结构变更）：
  ①章节生成上下文增强（伏笔/世界观/角色卡进生成 prompt，4000 rune 预算截断，
  读失败静默跳过）；②分支链路收账（branches.json 持久化+ApplyBranch 零重调+
  syncCharactersFromOutline 真同步）；③全文搜索升级（全部命中+段级定位+
  「共 N 处·M 章」）；④一致性两 bug（分支章节纳入扫描、断档不停扫）；
  死代码清理 5 文件（未挂载分支组件+孤儿 search.ts）。**下一刀候选（小说侧）**：
  伏笔登记表写入口、Continuity Linter AI 化、导出扩展（EPUB 封面/DOCX/仅主线）、
  ChapterPage 拆分补测。详见 releases/v4.43.0.md。

- **上一发布：v4.42.0（2026-09-02）「微信智能体 v1」**：用户拍板微信消息由 LLM
  工具调用派发（7 工具零改动复用 exec，ChatStream tools 管道既有，4 轮/60s，
  能力门目录 Caps tools 宁缺勿滥整链回落）；正则路由降兜底，提醒/文件快路径
  保留。**真机验证**：自然语言任意派发（「把产物发给我」验证出站文件卡；无工具
  可做时应如实说做不到不再幻觉）。**下一刀候选**：办公板块工具化（文件整理调用
  办公板块，用户点名）。详见 releases/v4.42.0.md。

- **最新发布：v4.41.2（2026-09-02）「产物推送放宽+反幻觉护栏」**：真机实证
  「重新整理后发给我」未命中推送意图、模型幻觉声称已发送——意图第四式+复合
  请求诚实能力答复+聊天反幻觉提示；**入站链 turn 102 已验证通过**（确认收件+
  概括+询问需求）。**出站实测**：微信发「把产物发我」（黄甲工作区有 9-1 docx
  产物；失败读 wx_capture.jsonl upload_probe）。新欠账：微信触发办公任务闭环
  （改文档并回传）。详见 releases/v4.41.2.md。

- **最新发布：v4.41.1（2026-09-02）「真机修复」**：文件提取正文误过意图路由被
  「打开/看看+编程」碎片劫持（发报告回「打开编程」）——文件消息按注入头识别
  直通轻语聊天（跳过提醒+意图，追加确认收件+询问需求引导）。新欠账：导航子串
  匹配普遍松动（语音/Ctrl+K 同链）需单独设计。详见 releases/v4.41.1.md。

- **最新发布：v4.41.0（2026-09-02）「微信文件收发」**：入站 file_item 真机抓包
  定稿（与图片同构）→ 防线下载 → wx_files 自持 → docmd 提取注入对话；出站文件卡
  探针制（media_type=3 假设 + upload_probe 埋点 + 降级链）；「把刚才的报告发我」
  产物推送意图。**待真机复验**：①重发文件看提取回复 ②发「把产物发我」看文件卡
  （失败读 wx_capture.jsonl upload_probe errcode 迭代）。详见 releases/v4.41.0.md。

- **最新发布：v4.40.0（2026-09-02）「对话式改图」**：微信发图+一句指令→编辑出图→
  图片卡回推。百炼 DashScope 引擎（qwen-image-edit-plus，仅 img2img，官方契约核实
  实装）+ dashscope_api_key 密文 + ActionEditImage 保守正则 + 入站图旁路 hook→
  助手级缓存（TTL 10min）+ routeIntentForAssistant + CardPath 回推 + 绘梦「百炼改图」
  选项与三处门禁白名单。绑定面 557 零变更（EditImageFromCard 收口改未导出——教训：
  内部链路方法小写开头防门面完整性测试逼进绑定面）。三路并行子代理实施。
  **下一刀**：B 文件收发（file_item 真机抓包硬前置，可先抓包定稿协议）。详见
  releases/v4.40.0.md。

- **最新发布：v4.39.0（2026-09-02）「微信助手管理台 · 多微信并行」**：定位用户拍板
  纠偏=聊天/出图/改图/收发文件/多微信并行（调研 docs/market-research-2026-09-02b.md）。
  本刀：WeixinPage 管理台（助手卡/启停/删除/逐助手扫码/新增表单，修硬编码 gaea）+
  manager.Update 写回扩展（空值保留）+ Save 空 token 保留凭据 + AssistantName 锁外
  直写竞争修复（内部 whisperChat 链，注入入 LockTurn 窗口）。绑定面 557 零变更；
  两路并行子代理实施。**下一刀**：A 对话式改图（Qwen-Image-Edit+改图意图+InitImage
  接线）→ B 文件收发（抓包前置）。详见 releases/v4.39.0.md。

- **最新发布：v4.38.0（2026-09-02）「目录通用化」**：用户指出 v4.36.0 元数据目录只覆盖
  GLM——扩展到 deepseek/xai/opencode-zen（model_catalog.json v1，25 条目官方互证核实；
  opencode-go 订阅制无按量售价拍板不入目录防误导，引擎级订阅徽标留欠账）；estimatePrice
  目录优先层扩展+估算修正（deepseek-v4-flash 3.0→12.672 CNY、grok-4.5/4.6 129.6→57.6、
  zen 8 模型新增计价，旧条目回归锁）；fetchModels 动态列表 enrich（徽标自动点亮，前端
  零改动）。内置表过时暴露：deepseek-chat/reasoner 官方 2026-07-24 停用、grok-4/3 系
  已下架。绑定面 557 零变更；filewatch TestCloseStopsEvents 全量首跑超时为负载 flaky
  （单跑/整包复跑绿，先例一致）。详见 releases/v4.38.0.md。

- **最新发布：v4.37.1（2026-09-02）「模型中心四刀」（调研 docs/market-research-2026-09-02.md
  → 用户拍板 ABCD → 同日 v4.35.0/v4.36.0/v4.37.0/v4.37.1 四刀四 tag，绑定面 552→555→557）**：
  ①v4.35.0 自定义引擎（EngineCustom OpenAI 兼容任意服务商，Key 存 config 加密 map
  custom_engine_keys，BaseURL 校验防 Key 粘错框，聊天路径 custom 分支真可聊天）；
  ②v4.36.0 GLM 目录 v2（glm_catalog.json 44 条目带上下文/价格/免费档/能力/coding 积分系数，
  远程热更新 v0=glm_catalog_url 默认禁用仅影响展示估算，estimatePrice 目录优先单源化估算
  零回归，glm_alias 核对一致，前端能力/价格徽标+积分估算）；③v4.37.0 健康巡检+故障转移 v0
  （10 分钟周期探已启用非本地引擎、Error 永不含 Key；engine_failover_enabled 默认关，
  网络类/408/429/5xx 才转移、候选默认模型重试一次、流式仅首字节前；前端开关卡+双事件订阅）；
  ④v4.37.1 D 收口（卸载确认带释放大小；磁盘展示//health 经核实已存在剔除=伪欠账再验证）。
  **教训入册**：gen_bindings explicitOverrides 是显式门面归属清单，新增绑定方法必须先登记
  再跑生成器（否则被前缀规则误归，C 刀实测手写委托被覆盖进 OfficeB）；build.bat 同链
  git commit 中文乱码用 -F UTF-8 文件 amend。**验证**：Go 全量 test exit 0、tsc -b/eslint 0、
  vitest 1243/1243、drift PASS（557）。**欠账**：A2/B2、降噪折叠、palette 个性化、task 卡
  空 ref、-race、model-failover 文案 engineLabel 化、dev mock 补 failover、自定义引擎用户
  价目（目录 v3 候选）。详见 releases/v4.35.0.md~v4.37.1.md。

- **最新发布：v4.34.0（2026-09-02）「子代理气泡恢复 · 恢复会话不再丢失子代理答复」**：
  git tag v4.34.0；基线 v4.33.0；绑定面 **552 零变更**（HistoryMessage 字段级，
  wails generate module 已刷新）。收 v4.26 沿旧欠账「子代理气泡恢复暂缺」。
  **根因（本刀钉死）**：恢复链 ResumeFromDisk → session.ProjectMessages（日志→消息投影）
  → GaeaHistory，投影 switch 无 subagent_message case 整条忽略 → 子代理答复在 provider
  History 不存在。**约束**：投影结果直接喂模型，实时运行期模型上下文也不含子代理答复，
  **不能给投影加 case**（恢复后模型上下文会偏离实时语义）→ **UI 侧并行投影**方案。
  **线A（Go）**：session 新文件 subagent_anchor.go（projection.go 一字未动）——
  KindSubagentMessage 常量（补上此前字面量缺常量，测试双向锚定）+ ProjectSubagentAnchors
  锚点镜像（与 ProjectMessages 逐 case 同拍游标，subagent_message 记「插在第 K 条消息
  后」）；GaeaHistory 末尾 mergeSubagentAnchors 纯函数合并（读 ReadEntriesFor 失败/空
  静默降级=原行为）；**logOffset 校正**（子代理抓出 brief 漏洞：检查点 Snapshot 含日志
  从不投影的 system 提示，恢复后 provider History 系统性多若干条，锚点会提前一档——
  offset=len(消息)−len(投影)，负位/越界锚点宁漏勿误丢弃）；HistoryMessage 加
  SubagentRef（omitempty，golden 逐字节不变）；GaeaResumeSession 零改动自动生效。
  **线B（前端）**：rebuildHistoryItems assistant 分支透传 subagentRef（空串归一
  undefined），复用实时「子代理」徽标渲染；HistoryMessage 类型交叉扩展（生成物刷新后
  可回收）。
  **验证**：Go 全量 test exit 0（线A 范围 -count=2；投影×5/Restore×8/Golden/Resume
  回归全绿=投影语义零改动证明）；tsc -b/eslint 0；vitest **1210/1210**（+3）；drift
  PASS（552）。**欠账**：渲染层未单独加测试（复用 Message 两态覆盖）；types 交叉扩展
  待回收；沿旧 A2 帧流/接管、B2 pptx 真编辑（独立刀体量需先规划）、降噪折叠、palette
  个性化、空 ref 轮询窗口、-race 无 gcc。详见 releases/v4.34.0.md。

- **上一发布：v4.33.0（2026-09-02）「细节收口 · 第三刀：回滚守卫统一/pdf 占位比精确化/
  主区预览懒加载对齐」**：git tag v4.33.0；基线 v4.32.0；绑定面 **552 零变更**。三并行
  子代理 + 主代理集成（含主区测量比例接线）：
  ①**回滚守卫统一 + write_file >8KB 恒误报修复（线A，真 bug）**：rollback 卡接入「恢复
  后已被手工修改」守卫（撤销恢复前校验 AfterSummary 同口径一致，防覆盖编辑）；write_file
  守卫原精确比较 vs 落库截断 SummaryLimit(8KB)——>8KB 未手改文件必然误拒，改
  `evidence.ClampSummary` 同口径截断比较；截断单点化（evidence 新导出 ClampSummary 字节
  口径逐字节兼容，RecordChange/app clampSummary 复用）；**已知边界**：8KB 摘要窗口外手改
  不可检（与 editLike Contains 同源，宁漏勿误，测试注记）。测试 app+4/evidence+1，
  -count=2 绿。
  ②**pdf 占位比按实测精确化（线B）**：pageLazy 新 nextPageAspect（首个有效测量=整档比例
  不被后续页推翻）/placeholderAspect（无测量回落 LAZY_PAGE_ASPECT）；FilePreviewModal
  img onLoad 读 naturalWidth/Height（无效值不记），state 增文档级 aspect（渲染期重置同
  mounted/forced）；占位→真身交换不再跳高，存比例不存绝对高度。
  ③**主区预览 pdf 懒加载对齐弹窗（线C）**：FilePreview pdf 分支接入同款 IO 单向懒加载
  （初始 4 页/800px/±1 buffer/大纲跳转 addForcedPage 强制渲染/ref 回调登记即补 observe
  真 bug 修法照搬）；无 IO 全量降级=既有行为；props 零变化；**主代理追加**：主区同样接
  测量比例（onLoad+placeholderAspect），占位表现与弹窗一致。
  **核实**：v4.26「TrajectoryView 未消费 subagent 记录」欠账已过期剔除（代码早已实现）；
  「子代理气泡恢复暂缺」=GaeaHistory（provider History 无来源字段）×磁盘事件日志
  （ResyncEvents v4.27.2 起折叠 subagentRef）跨源对齐，留独立刀先出方案。
  **验证**：Go build/vet/全量 test exit 0；tsc -b/eslint 0；vitest **1207/1207**（+11：
  线B +8/线C +3，旧锁零删改）；drift PASS（552）；版本四处 4.33.0。**欠账**：rollback
  守卫 8KB 窗口外边界（见①）；独立刀候选=子代理气泡恢复；沿旧 A2 帧流/接管、B2 pptx
  真编辑、行级降噪折叠、palette 个性化、-race 无 gcc。详见 releases/v4.33.0.md。

- **上一发布：v4.32.0（2026-09-02）「细节收口 · 第二刀：回滚可撤销/产物自动弹出/弹窗
  pdf 懒加载/预览最大化持久化」**：git tag v4.32.0；基线 v4.31.1；绑定面 **552 零变更**。
  用户点名「继续优化完善 gaea」——沿 v4.30/v4.31 先例从欠账池挑四条互不相交线，三并行
  子代理（A Go/B 产物面板/C 弹窗预览）+ 主代理自接线D（App.tsx）：
  ①**回滚先快照当前态**（线A，收 v4.28 B1 欠账）：GaeaRollbackRecord 恢复前把目标当前
  内容快照到原基线同目录（evidence 新导出 StageBaselineTo(dir,target,content)，命名/权限
  逻辑单点化），rollback 记录升级为完整证据卡（Before/After 原文+BaselinePath）——恢复
  动作本身在版本时间线成为可再恢复版本（撤销恢复=对 rollback 卡再点恢复）；目标缺失/快照
  失败降级不阻断。测试 gaea_rollback_test.go 三场景+evidence 2 单测，-count=2 绿。
  **取舍**：rollback 卡未接「手工修改」守卫（基线 >8KB 截断后精确匹配恒误报会阻断合法
  恢复），数据已就位待前缀匹配/快照比对方案。
  ②**产物自动弹出+偏好**（线B，收 v4.30 欠账）：新 lib/deliverablePrefs（gaea.
  deliverableAutoOpen **默认关** opt-in，API 对齐 browserPrefs）+ DeliverablesPanel 头部
  胶囊（data-testid=deliverable-auto-open-toggle，对齐 BrowserPanel 形状）；App 新产物
  diff effect 消费 shouldAutoOpenDeliverables()：偏好开且产物 tab 未停用 → 亮右栏切
  「产物」tab（激活即清零角标=自动弹出即已查看；不动 FilePreview）；单版本徽标 title
  细化「有 N 个历史快照，可预览/恢复」（收 v4.31 欠账，既有 5 处 title 断言最小替换）。
  ③**弹窗 pdf 逐页懒加载**（线C，收 v4.31 欠账）：新 lib/pageLazy 纯函数 + IO 单向懒
  加载（初始 4 页/rootMargin 800px/前后 buffer 1/已挂载不卸载杜绝滚动跳动），大纲跳转
  目标页并入强制渲染集合（scrollIntoView 不落估计高占位盒），无 IO 环境全量降级=v4.31
  行为；**顺带修真 bug**：preview/loading 两次异步提交致页 figure 晚于 IO effect 挂载、
  观察集为空、懒加载永不触发——pdfObserverRef 在 ref 回调登记时立即补 observe。
  ④**预览最大化持久化**（线D，主代理，收 v4.30 欠账）：layoutPreferences 新
  loadPreviewMaximized/savePreviewMaximized（gaea.previewMaximized 独立简单键——writePrefs
  只落 sizes 数字 map，布尔会被剥掉），App 懒初始化+toggle/拖拽退出三处落盘；半幅宽度
  本就落盘，还原仍回上次半幅。
  **集成**：tsc -b 抓到线C 三处 ReadonlySet/Set 类型口径不一致（expandMountedPages/
  addForcedPage 返回类型+消费方 state 字段诚实放宽为 ReadonlySet，已修）。
  **验证**：Go build/vet 全绿 + 全量 go test ./... exit 0；tsc -b/eslint 0；vitest
  **1196/1196**（+30：prefs 4+面板 4+pageLazy 19+弹窗 3，旧锁语义零删改）；drift PASS
  （552）；版本四处 4.32.0。**欠账**：rollback 卡手工修改守卫未接；弹窗 pdf 占位高为
  A4 估计值（滚动条比例非精确）；沿旧 v4.28 全部 + v4.30（降噪折叠/palette 个性化）+
  环境（-race 无 gcc）。详见 releases/v4.32.0.md。

- **上一发布：v4.31.1（2026-09-02）「-count>1 全量绿化 · 测试全局态 -count 不兼容根治 +
  whisper 末气泡真 bug 修复」**：git tag v4.31.1；基线 v4.31.0；绑定面 **552 零变更**
  （纯测试治理 + 1 处生产修复）。v4.31.0 线 D 收尾延伸：全量 `go test -count=2 ./...`
  从 FAIL → 全绿（exit 0），含生产修复按先例独立成版。**根因（统一）**：测试写进程级
  全局状态（provider/billing/boot/app 注册表 kind、app whisperSessions 会话缓存），
  `-count` 多次运行不兼容（非产品缺陷，whisper 除外）。**修法**：①注册 kind 改
  `testKind(prefix)`（进程级 atomic 单调计数后缀，19 注册点）；billing 无菌态断言改
  「含 deepseek」；②app whisper 会话隔离改唯一会话 ID + t.Cleanup 清理缓存（12 调用点）；
  ③**whisper 真 bug（唯一生产改动 +3 行）**：PacedStreamEmitter.pump streamDone 分支收尾
  末气泡（修 MarkDone 挂起/末气泡 OnBubbleEnd 永不触发）。**验证**：五包 -count=2/-count=5
  全绿、发射器 -count=300 全绿、tasks -count=20 仍全绿、**全量 `go test -count=2 ./...` 与
  -count=5 ./... 双绿 exit 0**、tasks -shuffle=on -count=10 无顺序依赖、go vet 全绿；前端
  零改动；drift PASS（552）；版本四处 4.31.1。**欠账**：-count>1 既有问题清零；-race 仍
  不可用（无 gcc）；沿旧 v4.28 全部 + v4.30/v4.31 欠账。详见 releases/v4.31.1.md。

- **上一发布：v4.31.0（2026-09-02）「细节收口 · 四线并行：单版本入口/弹窗 pdf 预览/历史轮
  耗时/tasks 竞态根治」**：git tag v4.31.0；基线 v4.30.0；绑定面 **552 零变更**（结构字段
  级，零新增绑定）。用户点名「开始，并行使用子代理」——从欠账池挑四条互不相交的线（文件
  足迹互斥），四并行子代理分线实现 + 主代理集成收口（v4.25/28 同款工作流）：
  ①**产物版本时间线单版本入口**（线 A，收 v4.28 B1 欠账）：徽标条件 `{rev && …}` 放宽为
  `{(rev || journalEntry) && …}`——versions>1 按现状 vN 徽标（旧锁不破），versions≤1 但有
  journal baselinePath 快照的产物渲染「版本」入口徽标（title 区分「更新 N 次」/「有版本
  历史」），无快照保持空态；VersionTimeline 本体零改动。测试 30→33。
  ②**FilePreviewModal pdf/pptx 逐页预览**（线 B，收 v4.28 欠账）：方案 b 弹窗内内联
  （**FilePreview.tsx 本体零改动**）——kind=pdf 分支逐页缩略（data-pptx-page 锚点）+dataUrl
  整本回退+诚实空态+PptxOutline 大纲卡（页锚点滚动/「针对第 N 页修改」composer 插入）；
  非 pdf 分支逐字节未动。测试 7→10。
  ③**轨迹历史轮耗时**（线 C，收 v4.26 欠账）：后端 Turn.DurationMs（fold turn_done 分支
  Ts>StartedAt 时 =(Ts−StartedAt)×1000，omitempty 向后兼容，golden 逐字节不变）+前端
  TrajectoryTurn.durationMs+TrajectoryView 轮次头「用时 Ns」（复用 formatElapsed，仅
  turn.end&&durationMs 时显示）；零新增绑定（GaeaTrajectory 返回 struct 字段级）。测试
  Go+2、前端+3。WorkHeader 消费历史轮耗时不可行（只吃实时 store 无 trajectory 数据源），
  已跳过记欠账。
  ④**TestCancelConcurrentStress flaky 根治（线 D，实现层真竞态）**：根因=pickNext 不做
  任务级预留→同一 queued 任务多 worker 同时 execute；claim 落选者无条件 unregisterCancel
  删 cancels+cancelReq（用户取消意图）→Cancel 已成功返回的任务终态被 succeeded 吞掉
  （v4.8.2 回归锁违背，探针轨迹恒 [queued running stopping succeeded] 实锤）。修复=tasks.go
  新 clearStaleCancel（只清残留预注册、**绝不删 cancelReq**，m.mu 下查状态仍
  running/stopping 归胜者不动）+claim 成功后胜者重登记 cancel；测试改事件驱动等待（50 终态
  事件到齐），断言不削弱（Cancel==nil ⇒ cancelled + 至少一个 Cancel 成功防空转）。验证
  -count=20/100 全绿。
  **验证**：Go build/vet/test 全量 0 FAIL；tsc/tsc -b/eslint 0；vitest **1166/1166**（+9：
  A3+B3+C3，未删改旧锁）；drift PASS（552）；版本四处 4.31.0。**欠账**：WorkHeader 历史轮
  耗时未消费；弹窗 pdf 不虚拟化；单版本「版本」徽标静态文案；tasks -count>1 既有全局注册表
  duplicate kind 与 whisper 超时沿旧；沿旧 v4.28（A2 帧流/接管、B2 pptx 真编辑、子代理气泡
  恢复暂缺/中途进度不回投）+v4.30（预览最大化持久化、产物自动弹 tab）。详见
  releases/v4.31.0.md。

- **上一发布：v4.30.0（2026-09-02）「办公 UI 化繁为简 · 第二刀：产物置前/行级降噪/
  命令面板视图重排/预览两档」**：git tag v4.30.0；基线 v4.29.0；绑定面 **552 零变更**
  （纯前端呈现重组）。用户点名「继续优化完善 gaea」——从 v4.29.0 欠账清单收齐四项，
  红线不变（**简化≠删除功能**，被隐藏的信息全部有确定性寻回路径：title/aria/悬停/激活
  即见）。①**产物生成自动置前/角标**（Devin Auto-open 式）：App diff 会话内新产物路径
  （首现即新，会话切换重置基线——恢复会话不误标「新」）→ 产物 tab 角标（未查看数，激活
  即清零，与运行角标同语义）+ DeliverablesPanel 新 freshPaths prop（经 sidebarRegistry
  ctx 接线）→ 行「新」徽标（Sparkles）+ data-fresh 高亮；②**面板行级降噪**（Cowork
  一行式）：产物/变更/任务三列表次级信息（路径/相对路径/时间/重试计数）group-hover
  悬停次行显现（opacity 150ms），title 全保留，主行断言零改动；③**命令面板按当前视图
  重排**（Linear 式）：新 lib/paletteRank.ts 纯函数（当前激活右栏面板 cmd 置顶 >
  chatTab=overview 时概览置顶 > 其余面板命令 > 模板/会话保序，稳定排序），App paletteItems
  接线，CommandPalette 组件零改动；④**预览「半幅↔最大化」两档**（VS Code Toggle
  Maximized Panel）：icons 补 Maximize2/Minimize2（antd Fullscreen 系列），FilePreview
  头部按钮（不传 onToggleMaximize 不渲染向后兼容），App previewMaximized 状态（最大化=
  占满可用宽度 视口−侧栏−360 与拖拽上限同源，还原回半幅 ref 记忆，拖拽分割条自动退出
  最大化）。**验证**：Go build/vet 0 FAIL（零 Go 变更）；tsc/tsc -b/eslint 0；
  vitest **1157/1157**（+10：paletteRank 6+DeliverablesPanel 新徽标 2+FilePreview 两档 2，
  未删改旧锁）；drift PASS（552）；版本四处 4.30.0。**欠账**：产物自动弹 tab（激进版
  Auto-open）暂不做可加偏好；行级降噪仅悬停次行未做折叠重构；命令面板个性化排序远期；
  预览最大化不持久化；沿旧 v4.28 全部。详见 releases/v4.30.0.md。

- **上一发布：v4.29.0（2026-09-02）「办公 UI 化繁为简 · 顶栏收拢/自适应标签/
  预览降噪」**：git tag v4.29.0；基线 v4.28.0；绑定面 **552 零变更**（纯前端
  呈现重组）。用户点名主轴「UI 界面化繁为简，参考市场同类产品」，派刀即立
  红线 **「简化界面不是删除功能！」**。先跑模块制调研两线（原始稿
  docs/research-2026-09-01b/ + 合成 docs/market-research-2026-09-01b.md）：
  化繁为简=复杂度从「常驻视觉空间」迁「按需检索空间」+出现时机半自动化
  （Linear「只隐藏数据，不删除 issue」为官方先例）。三交付点（功能/出口全
  保留）：①顶栏导出收拢（新 ExportMenu：Markdown/Word/PDF 三文字钮→单钮
  「导出 ⌄」下拉，管线原样，操作钮 7→5）；②右栏 tab 窄栏自适应图标化
  （<420px 文字 CSS hidden 只显图标，aria-label/title/角标保留，6 tab 集合与
  数量锁不动，340px 基线宽拥挤根治；对标 Notion Icon only）；③预览头部降噪
  （FilePreview 打开/定位图标化+头部按钮去边框；编辑/保存/取消状态语义文字
  保留——编辑能力保留红线测试钉住）。**验证**：Go 110 包 0 FAIL；tsc/tsc -b/
  eslint 0；vitest **1147/1147**（+9：ExportMenu 5+WorkspaceTabs compact 3+
  FilePreview 1，未删改旧锁）；drift PASS（552）；版本四处 4.29.0。
  **欠账**：产物自动置前/角标；面板行级悬停次行化；palette 吸附右栏项+按视图
  重排；预览半幅↔最大化两档；沿旧 v4.28 全部。详见 releases/v4.29.0.md。

- **上一发布：v4.28.0（2026-09-01）「浏览器与版本 · 观察窗/版本时间线/pptx
  交互」**：git tag v4.28.0；基线 v4.27.4；绑定面 550→552（+GaeaPptxOutline/
  GaeaBrowserObserve）。规划「浏览器与版本」刀，三并行子代理分线（文件所有权
  互斥）+主代理集成：
  ①**A2 浏览器观察窗**（线 B）：browser.Manager.Observe()（CDP
  captureScreenshot jpeg ≤1280 缩放；未运行 Available=false 绝不拉起）+
  GaeaBrowserObserve 绑定（Default() 单例 seam 可测）；右栏第 6 tab
  BrowserPanel（URL/标题+截图 zoom+操作时间线 browser_* 倒序 20+权限静态行+
  自动弹出胶囊 gaea.browserAutoOpen；App 接线新 browser_* 工具自动切 tab；
  2.5s 可见门控轮询）。帧流/接管远期。
  ②**B1 版本时间线**（线 A，纯前端零 Go）：产物 vN 徽标可点→内联
  VersionTimeline（聚合/倒序/过滤无快照卡）+基线预览（GaeaPreview abs 直接
  预览 rollback 快照）+恢复（RollbackRecord=写回基线+追加新证据卡）；对标
  Notion 版本史/Artifacts rewind，预览即护栏。留白：单版本无入口、恢复不先
  快照当前态。
  ③**B2/C3 pptx**（线 C）：GaeaPptxOutline（python-pptx 逐页大纲，python
  3.13+python-pptx 1.0.2 真机可用）+ GaeaPreview .pptx 分支（soffice→PDF
  缓存 7 天 TTL+poppler 逐页 ≤60 页）+ 前端逐页预览+大纲侧栏+页锚点滚动+
  「针对第 N 页修改」指令插入；真机冒烟 3 页 deck 全通过。
  **集成**：gen_bindings 552+删线 B 临时手工 wrapper；bindingNames/bridge
  （PptxOutline camel+映射、GaeaBrowserObserve 同名直调）/spaceBindings
  work×2（分面锁 264）；App browser_* 自动弹出；补更组件级
  WorkspaceTabs.test 数量锁 5→6（线 B 漏项——**教训：新增 tab 要全查三层
  测试锁：lib 清单/注册表/组件按钮条**）。**验证**：Go 110 包 0 FAIL
  （stress flaky 沿旧）；tsc -b/eslint 0；vitest 1138/1138（+43）；drift
  PASS（552）；版本四处 4.28.0。**欠账**：A2 帧流/接管/动态权限卡；B1 单
  版本无入口+恢复不先快照当前；B2 真编辑远期；沿旧（子代理气泡恢复暂缺/
  中途进度不回投/WorkHeader 历史轮耗时/窄栏适配/tasks flaky）。**下一刀
  候选**：v4.29 从欠账池+调研剩余挑主轴。详见 releases/v4.28.0.md。

- **最新发布：v4.27.4（2026-09-01）「todo 持久化改名 · progress.md 撞名根治」**：
  git tag v4.27.4；基线 v4.27.3；绑定面 550 零变更。**勘误**：本文件四次被
  覆写并非「并行会话」（用户核实无其他会话）——真凶=gaea 自身 `todo_write`
  内置工具 V10.6 计划进度持久化：每次 todo_write 写 `<工作区根>/.gaea/
  progress.md`，办公代理以本仓库为工作区跑任务时逐次覆盖（四次内容全是任务
  todo 表，时间与任务节点吻合；backups/ 四份快照即 todo 表）。文件名撞车：
  ①宿主仓库项目记忆 ②代理运行时 todo 持久化，用 gaea 开发 gaea 必然相撞。
  **修复**：写入端改名 **todos.md**（todo.go saveProgressMarkdown）+
  compaction 读取端 readProgressFile 优先 todos.md/回退旧名（compact_util.go，
  存量工作区兼容）。测试 +2（TestSaveProgressMarkdownWritesTodosNotProgress
  =事故直接回归锁；TestReadProgressFilePrefersTodosAndFallsBack——walk-up
  设计使「均缺失」断言在真实机器不成立，顺带实锤主目录
  C:\Users\wubi\.gaea\progress.md 有 8 月底代理 todo 残留可清理）。Go 110 包
  0 FAIL、前端零改动。**教训**：运行时产物文件名不得与宿主仓库约定文件同名
  ——自举项目工作区常驻本仓库，任何 <cwd> 相对写入都要过撞名审查；归因要
  先证伪（「并行会话」结论未核实就写进了三份发布说明）。详见
  releases/v4.27.4.md。

- **最新发布：v4.27.3（2026-09-01）「markdown 包裹符 · 交付卡片路径修复」**：
  git tag v4.27.3；基线 v4.27.2；绑定面 550 零变更。用户报告「交付卡片点击
  无法打开、定位打开的不是文件位置」→ computer-use 真实会话现场实锤：模型
  用反引号包裹路径（\`安全文明手册/….docx），卡片提取路径带开头反引号 →
  预览「文件不存在」、定位错位。根因=fileLinks 路径字符集不排除 markdown
  包裹符 \` 与 *（Windows 文件名非法字符，应作路径边界；v4.26.1 全角括号
  盲区第二弹）。修复=PATH_BODY/FIRST_SEG 排除+PATH_BOUNDARY 纳入+BARE_FILE_RE
  允许包裹符前缀；存量消息渲染时实时重提取、重启即恢复。+5 测试。
  vitest 1095/1095、tsc -b/eslint 0。**教训**：路径正则字符集以「目标平台
  文件名合法字符集」为准——非法字符（Windows: \ / : * ? " < > |）必然是
  markdown/包裹符，作边界不作路径体。**progress.md 第四次被并行会话覆写
  （backups/ 留档），再次恢复。**详见 releases/v4.27.3.md。


## 当前状态

- **最新发布：v4.27.2（2026-09-01）「细节收口」**：git tag v4.27.2；基线
  v4.27.1；绑定面 550 零变更。①**subagent_message 端到端收口**（v4.26 回投
  特性此前实际未通：后端发 kind=subagent_message、前端无消费整条被丢）——
  wire 层转译 kind="message"+subagentRef（gaeaEventMap，磁盘日志仍按原始
  kind 落）→ 前端 reducer message case 既有 subagentRef 语义接管（「子代理」
  徽标气泡）；补拉折叠同步：GaeaResyncItem 加 subagentRef（恒全键契约测试
  同步扩键）、fold subagent_message → 独立 assistant 条目 + closePending
  （其后 text 不误续写）；恢复会话场景欠账（模型上下文投影 ProjectMessages
  未含，避免改变续跑模型语义——记远期）。②**轨迹面板子代理记录**（子代理
  线交付）：TrajectoryRecordKind 加 "subagent"，KindBadge/Bot 图标/折叠行
  （答复摘要+ref）/RecordInspector 全文展开/搜索命中，turns 与 betweenTurns
  双落点覆盖。③**sidebar_open 目录定位**（收 v4.25 欠账）：directory 分支
  → handleRevealInTree，FileTree 目录行补 data-path/flash（验证发现目录行
  原本不被 reveal 命中——父链能展开但无锚点无高亮）。**验证**：Go 110 包
  0 FAIL（TestCancelConcurrentStress 全量负载下偶发 flaky，单跑稳定，与本
  刀无关）；tsc -b/eslint 0；vitest 1090/1090（+5）；drift PASS（550）。
  **教训：FileTree reveal 只锚 data-path——新增行型（目录）必须同步锚点，
  否则定位静默失效。progress.md 第三次被并行会话覆写（backups/ 留档第 3
  份），再次从 git 恢复。**详见 releases/v4.27.2.md。


## 当前状态

- **最新发布：v4.27.1（2026-09-01）「seq 防线 omitempty 失配修复」热修**：
  git tag v4.27.1；基线 v4.27.0；绑定面 550 零变更。用户报告「运行中只显示
  一个思考读秒，没有交替出现过程卡/文本卡（只有轨迹面板有显示）」。根因=
  v4.26 seq 补拉防线前后端形状契约失配：Go GaeaResyncItem 全字段 omitempty，
  流式 assistant 条目空 reasoning、写类工具 readOnly:false 的键被序列化省略；
  前端 parseResyncItems 严格校验缺键即整快照判坏 → 补拉快照 100% 被拒、
  防线静默失效，Wails 吞件期间对话窗无物可渲染（WorkHeader 是 store tick
  驱动所以活着；轨迹面板读盘不受害）——正是用户看到的形态。修复：①Go 全
  字段去 omitempty（序列化恒全键，TestGaeaResyncItemWireAllKeys 锁契约）；
  ②前端 parseResyncItems 缺省键宽容（缺字符串/布尔键→零值，类型错仍拒、
  kind/id/status 枚举不变）。**真机验证（computer-use 驱动真实应用发只读
  任务）**：对话窗内 WorkHeader 完成态「已完成 · 用时 15s · 7 步」+ 阶段行
  （正在解析@引用/装配首轮上下文/检索记忆）+ 思考块 + ls 工具卡（参数+输出）
  + 两段正文交替出现（各卡 elapsed 3s→8s→14s 证明运行中逐个渲染）；v4.26.1
  的交付文件卡片同屏确认。vitest 1085/1085、Go 110 包 0 FAIL、tsc -b/eslint 0。
  **教训：跨语言 wire 契约（Go struct json tag ↔ 前端严格解析）必须有一条
  「真实序列化形态」往返测试；omitempty 是严格校验的天敌。注意：.gaea/
  progress.md 被并行会话再次覆写并随 v4.27.0 提交，已再次从 git 恢复。**
  详见 releases/v4.27.1.md。


## 当前状态

- **最新发布：v4.26.1（2026-09-01）「全角括号文件名 · 交付卡片失配修复」**：
  git tag v4.26.1；基线 v4.26.0；绑定面 550 零变更。用户报告「看不见完工交付
  卡片、无法点击查看文件」。定位过程：静态审计 v4.26 全部渲染/事件路径均
  无回归 → 主代理用 computer-use 观察运行中的真实会话，a11y 树实锤：正文有
  「交付文件：C:\AI\bangong\黄甲\开工筹备计划（修订）.docx」但卡片未渲染 →
  根因=lib/fileLinks.ts PATH_BODY 把全角括号（）当路径终止符，文件名含（）
  时两条匹配（绝对路径+关键词裸名）全落空。修复=PATH_BODY 排除集移除全角（）
  （扩展名锚定末尾不吞补语）；GaeaPreview 的 resolvePreviewPath 本就接受绝对
  路径，点击链路零改动。测试：fileLinks +5（真实括号路径四形态+deliverableMentions
  数据源）+ DeliverableCards.regress.test.tsx 组件守卫 3（真实事件流渲染/resync
  替换后仍可见）。vitest 1080/1080（170 文件）、tsc -b/eslint 0。**教训**：
  用户报告「与版本相关」的 bug 未必是版本回归——先用运行中的真实数据实证
  形态再定修法；中文办公文件名带（）是常态，路径类正则必须过全角括号用例。
  详见 releases/v4.26.1.md。**注意：并行会话正在做 v4.27 右栏加宽
  （App/WorkspacePanel/workspaceTabs 未提交改动在工作区），提交时严禁 git add -A。**

- **最新发布：v4.26.0（2026-09-01）「对话流式重造 · 对齐 Codex」（插刀）**：
  git tag v4.26.0；基线 v4.25.0；绑定面 549→550（+1 GaeaResyncEvents）。
  起点=用户报告「办公板块对话发送后窗口静默半天，轨迹面板却在工作」。主代理
  事件流逐环节探查+调研子代理（Codex/Claude Code/Cursor 流式工作态，落
  docs/research-2026-09-01/codex-streaming-ux.md）→ 根因六连（子代理 Text/
  Reasoning 有意不进主聊天、预处理窗零事件、Wails 吞件、Retrying 未映射、
  phase 空 seam、TTFT 静默）→ 三并行编码子代理线（Go 事件线/前端状态线/
  渲染线，文件所有权互斥）+ 主代理集成：
  ①**WorkHeader 工作态头部行**：turn 激活期常驻（spinner+阶段文本+已用时
  1s tick+步数，items 为空也渲染=发送那一帧起窗口不空），完成转「已完成 ·
  用时 · N 步」耗时行；StreamingIndicator 收敛兜底（连接中/仍在等待事件）。
  ②**后端 phase 事件接线**：预处理各阶段发射 phase（正在启动引擎/解析 @引用/
  装配首轮上下文/检索记忆/思考中）+ Retrying/compaction 转译 phase（磁盘日志
  格式不变，200ms 同文案节流）；phase 收编过程卡+头部防重复。
  ③**子代理活动回投主回合**（Codex 2026-08 同款）：新事件 subagent_message
  完成态回投子代理最终答复（ref/parentId），主区消息「子代理」徽标；task 卡
  running 实时 lastText/lastTool 预览（App 5s 轮询注入 taskActivity）+完成
  结果摘要；中途进度不回投防刷屏（实时进度走分工面板）。
  ④**事件序号防线**：gaea-event 全量带 seq（转发层原子递增，会话切换归零），
  跳号→新绑定 GaeaResyncEvents 从磁盘日志折叠对话项全量快照整体替换（5s 冷却/
  在途去重/坏快照保底/streaming 续接/running 不动）；golden 逐字节不变。
  ⑤重复工具折叠「已调用 X · N 次」（Claude Code 式）；顺带修
  weixin_reminder_test 时间炸弹（固定基准过期必炸→取真实时钟）。
  **集成**：绑定面四处（bindingNames +GaeaResyncEvents/bridge AppBindings.
  ResyncEvents+映射/spaceBindings work 分面锁 262/types GaeaResyncResult）+
  App.tsx（fetcher 挂载+task 卡轮询注入）。
  **验证**：Go build/vet/test 全量 0 FAIL；tsc -b/eslint 0；vitest 1072/1072
  （169 文件，净增 71：eventSync 26、store.resync 18、taskActivity 12、
  WorkHeader 8 等）；drift PASS（550）；版本四处 4.26.0。**教训**：根因探查
  先于动手（六个根因里三个半在后端，纯前端重造治不了）；「吞件」类问题用
  序号+读盘补拉根治而非重试；并行会话会覆写 .gaea/progress.md（本次被无关
  会话清掉 851 行，已从 git 恢复+对方内容备份 backups/）。
  **欠账**：子代理中途进度不回投；并行多子代理派发瞬间 task 卡预览可能短暂
  空 ref；历史轮无耗时数据源；TrajectoryView 未消费 kind="subagent" 记录。
  **下一刀 v4.27「浏览器与版本」**（原 v4.26 顺延）：A2 观察窗+B1 版本时间线
  +B2 pptx+C2/C3（调研弹药 docs/market-research-2026-09-01.md）。详见
  releases/v4.26.0.md。


## 当前状态

- **最新发布：v4.25.0（2026-09-01）「文件工作台 · 编辑器 tab 化/变更 diff/
  选区联动/模型主动打开」**：git tag v4.25.0；基线 v4.24.0；绑定面 549→549
  （零新增）。规划第三刀（docs/gaea-office-upgrade-plan-2026-09.md A3+B3）。
  本轮全程 3 并行编码子代理分线（文件所有权互斥）+ 3 调研子代理同期跑 +
  主代理集成收口：
  ①**A3 编辑器 tab 化（EditorTabs）**：文件树点开→右栏内多文件编辑器 tab
  （lib/editorTabs zustand 外部 store：上限 12 LRU/关闭激活相邻/localStorage
  坏值兜底/openEditorTab 命令式入口）；FilePreview embedded 模式（默认 false
  行为不变），docx 框选即改/xlsx 直编+Plan→Apply 原样随迁（换壳不换芯红线）；
  双入口保留（树行点击=右栏内 tab、右键「预览」=主区 pane）；产物行「树中
  定位」reveal→FileTree 展开父链+滚动+1.6s 闪烁（注册表 ctx 增
  revealRequest/onRevealInTree 两字段透传，面板本体零改动）。
  ②**A3 变更 tab diff 化**：文件行展开→行级红绿 diff（lib/planDiff 数据构造 +
  ChangesDiff 三态渲染；数据源诚实评估：edit_file/multi_edit 有 old/new→真
  diff，write_file/edit_lines 仅新内容→写入预览+原因，其余不伪造）+ 回滚接
  证据链 Journal 最近基线（GaeaJournalList+RollbackRecord，路径匹配排除
  rollback 记录）。
  ③**B3 选区联动**：xlsx 选中单元格→浮动「引用到对话」（双击直编时隐藏）；
  docx 框选工具栏补「引用到对话」；docx 渲染失败降级纯文本（lib/docxText
  提取 word/document.xml 正文段落+amber 提示条，能力边界如实）。
  ④**模型主动打开 sidebar_open**：Go 内置工具（work 空间/ReadOnly 直允许/
  防穿越 realPath+within/envelope data {kind,path_abs,path_rel}；+20 Go 用例）
  + lib/sidebarOpen.ts 解析器（坏 JSON/失败 code→null 不抛）+ App 按工具事件
  id 去重消费（file→openEditorTab 开右栏编辑器 tab，directory→亮文件 tab；
  命中自动亮右栏切「文件」tab，先收主区预览）。
  **验证**：Go build/vet/test 全量 0 FAIL；tsc -b/eslint 0；vitest 1001/1001
  （164 文件，净增 74：editorTabs 16、sidebarOpen 8、planDiff 12、ChangesDiff 4、
  DocxPreview 6、EditorTabs/WorkspacePanel/ChangesPanel 重写等）；drift PASS
  （549）；版本四处 4.25.0。**同期调研**：docs/market-research-2026-09-01.md
  合成版 + docs/research-2026-09-01/ 3 原始稿（v4.24.0 基线：浏览器观察窗/
  版本时间线/pptx 与工作台动向，喂 v4.26）。**教训**：并行子代理跨线只共享
  「接口契约（prop 名/签名）」并在派发时逐字写进两份 brief，中途再以消息补发
  约定（本轮 editorTabs 外部 store 补约定避免返工）；子代理自查 tsc 可能撞见
  并行线半成品错误，收口以主代理全量门禁为准。**欠账**：变更 diff 的
  write_file/edit_lines 旧内容缺失（待 B1 写前快照库）；回滚粒度=最近基线
  （逐版本回滚待 B1）；docx 降级仅正文段落；sidebar_open directory 不定位
  树根；EditorTabs 窄栏精细适配；AgentNetworkCard 旧卡不动（沿 v4.24 约定）。
  **下一刀 v4.26「浏览器与版本」**：A2 观察窗（截图步进流起版+操作时间线+
  权限卡内联）+ B1 版本时间线（写前内容寻址快照库与登记表同源+vN 徽标
  popover 双入口+恢复=新增版本）+ B2 pptx（结构化大纲卡先行+页级指令两通道）
  + C2/C3。详见 releases/v4.25.0.md。

- **最新发布：v4.24.0（2026-09-01）「子代理工作台 · 树拓扑/实时动态/
  产物登记表」**：git tag v4.24.0；基线 v4.23.0；绑定面 548→549（+1：
  GaeaDeliverableRegistry）。规划第二刀（docs/gaea-office-upgrade-plan-2026-09.md
  A1+C1）。上一轮会话完成主体编码，本轮接续完善收口：
  ①**A1 树形实时拓扑（AgentTree）**：GaeaAgentNetwork 嵌套 Children 全量渲染
  （此前只画两层）；root 折叠为「主 agent」行、一级恒可见、更深默认收起可
  展开/收起；新节点出现自动展开父链（首轮只记基线）；节点量化——状态色点/
  任务摘要/工具数/模型徽标/耗时（running 实时已用 1s tick）/token/错误数；
  下钻链：节点→详情卡→完整 transcript→**工具调用行点击定位结果消息**（收
  v4.21 欠账，data-located 高亮）。
  ②**合并活动流（Devin 式单列 feed）**：running 子代理 lastText/lastTool 按
  updatedAt 倒序合并、上限 20、空态收起；与树内行预览并存。
  ③**新子代理自动展开（可关，默认开）**：新 ref 出现→onSubagentStarted 回调
  →App 亮出右栏切「分工」tab（tab 停用时尊重停用态）；偏好键
  gaea.subagentAutoOpen（localStorage，损坏值回落默认开——交付前修 bug：
  原实现把垃圾值当关闭）。
  ④**C1 权威产物登记表**：trajectory.FoldDeliverables 纯函数从事件日志折叠
  写类 8+生成导出类 3 工具的落盘登记（路径/最近工具/来源轮次/时间/累计次数，
  按 path 去重、updatedAt 倒序、上限 200，Total 完整去重数）；登记口径
  evidence.IsDeliverableTool/ExtractDeliverablePaths（与证据链 extractPaths/
  前端 changes.ts 同源对齐，不收 source；bash/screen_capture 无结构化路径
  参数诚实不猜）；新绑定 GaeaDeliverableRegistry(sessionPath)（防穿越；
  无事件日志 Available=false 不报错）；DeliverablesPanel「权威产物登记」只读
  区（tool 徽标+路径+轮次+次数+时间，点击预览；total>200 提示最近 N 条），
  补启发式（正文扩展名白名单）漏登。
  **验证**：tsc/tsc -b/eslint 0；vitest 927/927（157 文件，净增 16：
  SubagentsPanel 重写 8、AgentTree 7、DeliverablesPanel 登记表 3、subagentPrefs
  3 等；旧扁平卡用例随新结构重写）；Go build/vet/test 全量 0 FAIL；drift PASS
  （549）；版本六处统一 4.24.0。**教训**：交付前必须跑 `tsc -b`（build.bat
  同配置）且检查新测试文件路径参数（vitest run 无参数时 tsconfig 的 include
  范围与手测不同）；vi.mock 全模块 mock 时注意副作用导入（onEvent 订阅器）。
  **欠账**：AgentNetworkCard（主区上下文 tab 旧卡）仍两层 SVG 本轮按约定不动；
  登记表为独立只读区未与启发式合并去重（v4.25 A3 变更 tab 统一快照时处理）；
  下一刀 v4.25「文件工作台」（A3 编辑器 tab 化+变更 diff+模型主动打开+reveal
  +B3 选区联动）；v4.26 浏览器观察窗+版本时间线+pptx（A2/B1/B2/C2/C3）。
  详见 releases/v4.24.0.md。

- **最新发布：v4.23.0（2026-08-31）「工作台框架 · 右栏工作台化第一刀」**：
  git tag v4.23.0；基线 v4.22.0；零新增绑定（548）。用户拍板：右面板重造为
  DSH-better-sidebar/Codex 式「运行工作台」（子代理/浏览器/文件编辑器等实时
  操作面），状态显示类迁主区轨迹/上下文旁边；规划稿
  docs/gaea-office-upgrade-plan-2026-09.md（v2，分期号顺延）。
  ①**Tab 注册表 lib/sidebarRegistry.ts**：元数据复用 workspaceTabs 清单 +
  render 接线单一数据源，右栏渲染/命令面板全派生；新增面板 = 清单 + RENDERERS
  各一条、面板组件本体零改动（框架/内容解耦，为 v4.25/4.26 浏览器观察窗与
  编辑器 tab 留平等挂载点）。
  ②**工作台外壳三件套（学 better-sidebar v0.18 交互形状，不抄代码）**：全局
  宽度键（左缘拖拽 280–720，最后一次拖拽胜出跨会话跟随）；声明式设置（齿轮
  →侧边卡片，每 tab 独立开关，停用即隐藏/整组停用隐藏主 Tab/至少保留一个/
  停用不进命令面板，启用集全局键 gaea.rightPanel.v1:tabsEnabled）；会话记录
  v2（{v,tab,enabled,width}，v1 裸 id 兼容可读，坏值逐项兜底，失效激活指针
  修正）。
  ③**主区「概览」tab（A4 统计迁移）**：ChatTabs 第 4 tab（对话/轨迹/上下文/
  概览）+ OverviewPanel 承载原 StatsPanel（本体零改动）；右栏统计下线
  （WorkspaceTabId union 全量移除，v4.22 旧 tab:"stats" 宽容收敛回「文件」
  并钉回归用例），右栏收敛 3 主 Tab×7 面板；命令面板新增「概览面板」项；
  chatTab 恢复白名单加 overview。
  **实现方式**：两个并行子代理分线（框架线/概览线，文件所有权互斥）+ 主代理
  集成收口。**教训**：tsc --noEmit 与 build.bat 的 tsc -b 配置不同——NodeList
  for...of 迭代错只在 tsc -b 暴露（已改 forEach），新测试代码过门前必须跑
  `npx tsc -b`。
  **验证**：tsc/tsc -b/eslint 0；vitest 911/911（净增 38）；Go build/vet/test
  0 FAIL；drift PASS（548）；版本四处 4.23.0；build.bat 构建成功 + 冒烟
  /api/health 200。**欠账**：Tab 拆分分栏/底部面板/自由窗口、设置二级齿轮
  弹窗、注册表懒加载 chunk 化；下一刀 v4.24「子代理工作台」（树形实时拓扑 +
  live 批量预览 + 节点耗时/进度 + transcript 工具级下钻 + 合并活动流 + 产物
  登记表）。详见 releases/v4.23.0.md。

- **v4.22.0（2026-08-31）「一次性收官 · 真虚拟化/transcript 定位/
  晨报预载 UI」**：用户要求「一次性做完」——办公板块剩余本地可做欠账一次
  清完并整理提交收尾，三件事一并落地：
  ①**轨迹真虚拟化（react-window v2 动态行高）**：扁平行流按视口窗口渲染
  （±overscan 12），超长会话 DOM 恒定，v4.21「首批 250 + 加载更多」分批机制
  退役；useDynamicRowHeight + ResizeObserver 实测展开行高自动重排（jsdom
  回落 defaultRowHeight 29）；概览跳转走 listRef.scrollToRow、搜索词变化
  回顶、收起全部/展开全部在虚拟流上照常生效；test/setup 补 ResizeObserver
  stub（react-window 内部无守卫使用）。
  ②**transcript 消息定位**：每条消息按原位置带序号 #N；搜索命中自动滚动到
  第一条命中（scrollIntoView），计数「命中/总数」。
  ③**晨报预载 UI 开关（+2 绑定 GaeaMorningPreload/GaeaSetMorningPreload）**：
  internal/config.Save 持久化 ~/.gaea_config.json + 内存更新 + 重建引擎即时
  生效；记忆面板头部「晨报预载 开/关」胶囊按钮（与记忆开关同款交互）；
  gen_bindings 重生成 548，bindingNames/mock/bridge/spaceBindings 同步。
  **验证**：Go 全量 0 FAIL（绑定面完整性 548）；tsc/eslint 0；vitest 873/873
  （+3：虚拟化 DOM 有界与滚动到末尾、transcript 序号、晨报预载开关）；
  drift PASS（548）；版本四处 4.22.0。**收尾**：v4.17.0-v4.22.0 六轮改动
  交织在同一工作区，作为一次合并发布提交并打 tag v4.22.0（历史 release
  notes 保留演进记录）。剩余欠账仅外部资源/官方数据项（Realtime 真机、
  自动路由、浏览器下载上传/headless UI/Windows UIA、iLink 真机窗口）——本地
  不可完成，不在「做完」范围。详见 releases/v4.22.0.md。

- **最新发布：v4.21.0（2026-08-31）「长会话与 transcript · 增量渲染/消息搜索」**：
  续 v4.20.0 剩余两条欠账（轨迹超长会话渲染量 + transcript 只读无搜索），
  纯前端零新增绑定：
  ①**轨迹增量渲染（DOM 有界）**：渲染从「逐轮整体」改为扁平行流（轮次头 +
  展开记录行 + Between-turns），按批渲染——首批 250 行，滚动到底自动续载
  或点「加载更多（剩余 N 条）」，搜索词变化回首批；概览跳转同步把目标轮
  之后的可见区扩到视口内（不再「跳过去了但没渲染」）；收起全部/展开全部在
  平行流上照常生效（折叠 = 记录行不进流）。
  ②**子代理 transcript 消息搜索**：查看器头部搜索框，按正文/推理/工具名/
  参数/结果过滤，计数「命中/总数」，无匹配空态。
  ③**注释清理**：ChatTabs「[轨迹]（暂占位）」更新为 v4.17-v4.21 实际能力。
  **验证**：tsc/eslint 0；vitest 872/872（+2：超长会话增量渲染与加载更多、
  transcript 搜索）；Go cached 全绿、drift PASS（546）；版本四处 4.21.0。
  欠账：增量渲染为分批 DOM 而非 react-window 真虚拟化（渲染量有界但已渲染
  部分仍为真实 DOM）；transcript 只读无跳转/引用定位。详见 releases/v4.21.0.md。

- **最新发布：v4.20.0（2026-08-31）「剩余收官 · 子代理 transcript/轨迹概览/
  旧会话趋势补齐」**：清掉 v4.17-v4.19 三刀之后的剩余欠账，三件事一并落地：
  ①**子代理完整 transcript 查看器（+1 绑定 GaeaSubagentTranscript）**：读取
  `<sessionDir>/subagents/<ref>.jsonl` 全量消息（role/content/reasoning/
  toolCalls/toolCallId），ref 校验 sa_ 前缀+安全字符（防穿越），读取失败返回
  错误（区分「没有」与「读不了」）；gen_bindings 重生成（546），bindingNames
  同步；前端 Agent 网络详情面板「查看完整 transcript」→ 消息流可滚动可收起。
  ②**轨迹 Overview 投影 + 轮次跳转 + 折叠控制**：轨迹标签顶部概览条（每轮
  一根柱，柱高∝记录密度，含工具调用高亮、报错标红，hover 明细，点击平滑
  跳转并展开目标轮）+「收起全部/展开全部」（长会话折叠成轮次索引，新回合
  默认展开不被旧折叠态吞掉）。
  ③**迁移/兜底会话趋势补齐（诚实估算）**：ToLogEntries 每回合合成
  request_header（system=真实 system 消息拼接，tools=该轮 assistant 实际
  工具名集合，schema 未知的最小诚实形状；顺序与运行期一致——user 先落、
  header 随后）；contextview 新增回合末估算关闭（turn_done 未见 usage 时用
  当前估算构成落 estimated 记录并刷新 brief），前端步骤详情显示「估算构成
  （无用量记录）」，不伪造 promptTokens 等用量数字。
  **验证**：Go 全量 0 FAIL（+2 用例）；tsc/eslint 0；vitest 870/870（+3）；
  drift PASS（546）；版本四处 4.20.0。欠账：轨迹虚拟滚动未做（以收起全部+
  概览跳转缓解渲染量）；子代理 transcript 只读无搜索。详见
  releases/v4.20.0.md。

- **最新发布：v4.19.0（2026-08-31）「看板收官 · 上下文浏览器//context 命令/
  子代理节点详情」**：续 v4.17.0+v4.18.0 的「继续完善」第三刀，上下文标签
  最后一个页脚占位收掉，三件事互不相交一并落地：
  ①**上下文浏览器**：contextview 折叠补全系统/工具节点（request_header 的
  system prompt 与工具集合只在构成变化时入 nodes——初版+变化版，每步重复
  不刷屏；文本=300 字预览，全文在日志）；前端 ContextBrowserCard（活跃/归档
  双页签 + 六分类过滤 chips + 节点行可展开，归档=被压缩移出带「已压缩」），
  页脚占位整行移除。
  ②**/context 命令**：GaeaCommands 内置 + i18n（zh/en CmdContext），斜杠
  菜单可发现；classifyComposerCommand 增 context 分类，App.handleSend 拦截
  → setChatTab("context")（不发给模型）；CLI 未拦截路径走控制器未知斜杠
  Notice。
  ③**Agent 网络节点点击 → 子代理详情**：AgentNetworkCard 增 sessionPath
  （App 从 currentSessionPath 注入），点击子代理节点 → SubagentRuns(sessionPath)
  按任务前缀匹配（与后端 enrichAgentNetwork 同口径）→ 固定详情面板（状态/
  模型/工具调用数/更新时间 + lastText/lastTool + 最后回答摘要），无匹配回退
  节点统计；悬停文案更新。
  **验证**：Go 全量 0 FAIL（+1 用例）；tsc/eslint 0；vitest 867/867（+4）；
  drift PASS（545）；版本四处 4.19.0。欠账：子代理完整 transcript 查看器；
  轨迹 Overview 投影与虚拟滚动；迁移会话系统/工具分类与趋势柱（诚实不造
  数）。详见 releases/v4.19.0.md。

- **最新发布：v4.18.0（2026-08-31）「看板补全 · 文件活动/增量模式/实时刷新」**：
  续 v4.17.0（事件日志默认开启，轨迹/上下文数据源接通）后的「继续完善」，
  收掉两个看板剩余的占位尾巴，三件事互不相交一并落地：
  ①**文件活动时间线**（上下文标签新卡）：contextview 折叠新增 FileActivity——
  工具参数确定性提取路径（path/rel/source/destination/image_path/output 键）
  + 工具→动作白名单（read/grep/vision/format_convert=读；write/edit/multi_edit/
  edit_lines/chart_gen/diagram_gen/screen_capture=写；move=移；ls=目录），
  screen_capture 从结果输出补记，bash 等无法确定性取路径者诚实不造数；同轮
  同步骤同路径合并、上限 200、空切片非 nil。前端文件活动卡（动作徽标+工具+
  路径+时间，倒序最近 40 条），页脚改为「上下文浏览器将在后续阶段接入」。
  ②**增量（Delta）模式启用**：趋势图「增量」按钮去灰置（Phase B 占位收口），
  切换展示每步相对上一步净变化（绿=净增·红=净减图例），柱色改全站语义色。
  ③**运行中实时刷新**：新 hook useLiveReload 订阅 gaea 事件流——运行中节流
  刷新（1200ms）+ turn_done 立即刷新 + 整轮完成刷新；轨迹/上下文/Agent 网络
  三处统一接入。**验证**：Go 全量 0 FAIL（+2 用例）；tsc/eslint 0；看板+
  mock-contract vitest 22/22（+2）；drift PASS（545）；版本四处 4.18.0。欠账：
  上下文浏览器（surface 节点浏览/归档）仍占位；Agent 节点点击跳子代理会话；
  轨迹 Overview 投影与虚拟滚动；/context 命令；迁移会话系统/工具分类与趋势
  柱（旧消息无 request_header/usage，诚实不造数）。详见 releases/v4.18.0.md。

- **最新发布：v4.17.0（2026-08-31）「轨迹上下文接通 · 事件日志默认开启」**：
  用户反馈办公板块「轨迹」「上下文」标签是空壳。排查结论：前端/绑定/折叠器
  均完整，根因在数据源——两看板依赖追加式事件日志，而 `session.log_format`
  缺省 legacy = sink 不接线 → 日志从未落盘 → 看板恒读空日志。交付四块：
  ①**事件日志缺省开启**：config.EffectiveLogFormat 缺省 "event"（显式 legacy
  可退回），gaea_handler 注入生效值、boot 同源创建 EventLogSink；②**旧会话读端
  兜底**：session.ReadEntriesFor 优先事件日志、缺失时从 legacy 会话投影折叠
  条目（纯读不落盘），轨迹/上下文/Agent 网络三看板共用；③**迁移产物带回合
  边界**：ToLogEntries 每条 user 消息前写 turn_started、流尾写 turn_done
  （ProjectMessages 忽略边界，恢复投影逐字节不变）+ 轨迹折叠兼容
  assistant_message（内嵌工具调用展开为 tool 记录并与结果合并）；④**资源
  释放**：EventLogSink.Close 挂进 Controller.Cleanup——缺省 event 后 Windows
  上会话目录可删除/迁移（文件句柄泄漏面一并修掉）。**验证**：Go 全量 0 FAIL
  （+6 用例）；tsc -b 0；看板组件 vitest 12/12；drift PASS（545）；版本四处
  4.17.0。欠账：迁移/兜底会话无 request_header/usage（系统/工具分类 0、趋势
  无柱，新会话完整）；Agent 网络对 legacy 会话仅 root；上下文增量模式/浏览器/
  File activity/SSE 增量刷新 = v3.5 既定欠账。详见 releases/v4.17.0.md。

- **最新发布：v4.16.0（2026-08-31）「四刀并行 · 离线收口/浏览器键盘与 iframe/复核
  可视化/晨报预装配」**：用户拍板「全部并行处理」——v4.15.0 欠账四个可离线方向由
  四个并行子代理同步落地（足迹隔离：刀①/②/④零绑定零前端，刀③独占绑定面相关
  文件），主控全绿门禁。**零新增绑定（545 不变）**。①**persona 侧离线裂缝收口**
  （真 bug）：gaea_whisper_causal/retell/whisper_handler 三处 featureModel("chat")
  → routeModel("chat")——全局离线过滤对轻语链路生效（此前绑云端照样发云端），
  用户功能绑定语义不变（同源）+2 离线回归。②**浏览器键盘级 Input + iframe**
  （v4.13/14 欠账）：新工具 browser_press（第 11 工具，Input.dispatchKeyEvent 键盘
  级输入：key 别名表/组合键/text 真实输入，Enter 补 \r 触发 keypress 真机踩坑
  修复）+ browser_read/click/type 加 frame 参数（getFrameTree→createIsolatedWorld
  →contextId，**iframe 内交互完整实现**，真 headless Edge 真机验证 Read/Click/Type
  全通）；snapshot 不下钻 iframe 诚实拒。③**Verifier 通道 B 结果进前端**（v4.14
  欠账）：Verdict 增 channelBRatio/channelBPages/channelBArtifacts（omitempty 旧卡
  兼容）+ 证据卡「视觉复核：像素差异率 x.x% · N 页」行 +「查看复核产物」按钮
  （打开产物目录 before/after PDF + 逐页 PNG）。④**晨报深度预装配**（v4.14 欠账）：
  memory.BuildMorningPreloadBlock 纯函数（复用 BuildMorningBrief 排序口径，≤600
  rune 确定性零 LLM）→ sysprompt 装配点注入「【工作记忆晨报】」块（门控
  Memory.Enabled && morning_preload && space==work，play/mode=off 不注入=双空间
  红线）；config 键 morning_preload（默认 true，仅配置文件可控）。**验证**：Go
  全量 0 FAIL（+20）；vitest **861/861**（+2）；tsc/eslint 0/0；drift PASS（545）；
  build.bat 冒烟 200；版本四处 4.16.0。欠账：Realtime 真机（需用户真 key+麦克风）；
  自动路由本体（待官方逐模型缓存/峰谷数字）；浏览器 snapshot 不下钻 iframe/
  下载上传/headless UI/Windows UIA；通道 B 逐页缩略图；晨报预载无 UI 开关。详见
  releases/v4.16.0.md。

- **最新发布：v4.15.0（2026-08-31）「聊天路由归位 · 由谁回答」**：v4.14.0 欠账
  「自动路由 v1」经**用户拍板收缩**为最小价值刀——砍成本档位机制/auto_route 开关/
  UI（缓存价/峰谷价无官方逐模型数字，按「未核实不入表」纪律诚实不做），只留两块
  真实价值。①**聊天路由归位（真 bug 修复）**：chat_service.go:68/:105 +
  chat_handler.go:9 三处 `featureModel("chat")` → `routeModel("chat")`——用户功能
  绑定语义逐字节不变（同源），新增收益=全局离线模式对 plain 聊天生效（修复「总闸
  不总」裂缝）+ 无绑定时全局/兜底与 persona 一致 + model.route 事件补齐。②**「由谁
  回答/为何/花了多少」回显**：modelengine 导出 EstimateCostCNY（本地/未知恒 0、
  USD 折算 CNY、非法汇率回退 7.2）；chat done 帧/ChatSend 返回加
  answered_by{engine,model,source,cost_cny}（流式按 chunk.Usage 实算，usage 不可达
  诚实记 0）；前端 AnsweredByLine 消息底部小字（费用 ≤0 隐藏段）+ useChatStream
  解析（旧事件静默跳过向后兼容）。**验证**：Go 全量 0 FAIL（+7）；vitest **859/859**
  （+7）；tsc/eslint 0/0；drift PASS（545 不变）；build.bat 冒烟 200；版本四处 4.15.0。
  欠账：自动路由本体未做（待官方逐模型缓存/峰谷数字后另刀）；persona 侧
  gaea_whisper_causal/retell 同类离线裂缝=观察项；按 source 拆分统计未做；plain
  费用口径 usage 不可达恒 0（诚实降级）。详见 releases/v4.15.0.md。

- **最新发布：v4.14.0（2026-08-31）「三箭并行 · 晨报预取 + 浏览器续刀 + 复核产品化」**：
  用户拍板「多刀并行」，三刀足迹隔离并行落地（探索子代理 ×3 代码地图 → 实现
  子代理 ×3 → 主控全绿门禁），绑定面 544→**545**（+1：GaeaMemoryMorningBrief）。
  ①**浏览器续刀**（v4.13.0 欠账）：空闲 TTL 自动关停（Options.IdleTTL 默认 10min
  + GAEA_BROWSER_IDLE_TTL env，Ensure 成功路径刷 lastActive，once 守护 watcher
  到期 teardownLocked 自动回收，browser_* 自动重拉闭环）+ 多标签页（Manager
  重构 tabs map + activePageID，/json/list 全量 target 真源；ListTabs/NewTab/
  SwitchTab/CloseTab，切 tab 置 epoch=0 旧 refs 诚实失效，关 active 切剩余、
  最后整体回收）+ 新工具 ×3（browser_tabs/browser_new_tab/browser_switch_tab）
  + browser_close 可选 tab_id（缺省保持现语义）；零新增绑定、前端零改动。②**做梦
  2.0 主动预取 MVP**（路线图 T0 欠账）：memory.BuildMorningBrief 纯函数（零 LLM/
  零 IO/确定性，max(UpdatedAt,LastUsedAt) 降序 top5 user/project 优先 +
  procedural/rule ≤3 + rune 边界截断 120 + 空输入非 nil 空数组）+ 新绑定
  GaeaMemoryMorningBrief() (string, error)（JSON 串对齐 GaeaCostGraph 先例，
  ListInSpace("work") 只读 + 近 24h dream 审计计数，零写库零落审计，play 红线
  安全）+ 首页 MorningBriefCard（仅 work 空间渲染，失败/空静默隐藏，全 token）
  + i18n home.morningBrief.* 三语 + gen_bindings 重生成（bindingNames 545）。
  ③**Verifier 产品化**（调研 ★★☆，纯前端零新增绑定）：证据卡三步展开——卡面
  （无 baselinePath 回滚禁用 + 「可复核明细」徽标）→ 声明↔实况 diff（opsJson ×
  GaeaPreview 现取，口径同后端数值容差 1e-9/去空白/公式归一，✓/✗/跳过 + 近似
  比对脚注）→ 操作回放时间线（applyOne 风格中文描述 + 批量 op 折叠，旧卡回退
  beforeSummary）；lib/verifyDiff.ts 纯函数 + types 补 baselinePath/opsJson/
  XlsxOpView/VerifyDiffRow + mock/office.ts 补证据域三绑定。**验证**：Go 全量 0
  FAIL（+25）；vitest **852/852**（150 文件，+27）；tsc/eslint 0；drift PASS
  （545）；版本四处统一 4.14.0；build.bat 冒烟 200。欠账：晨报深度预装配（进
  agent 上下文）列第二刀；浏览器 iframe/键盘级 Input/下载上传/headless UI/
  Windows UIA；Verifier 通道 B 结果未进前端、复核明细绑定留待真实需求；
  本地-云端自动路由 v1 顺延下一刀。详见 releases/v4.14.0.md。

- **最新发布：v4.13.0（2026-08-31）「自动操作·浏览器」**：四柱「自动操作」
  唯一空柱的第一块砖（刀序④）。internal/gaea/browser 新包——msedge 三段式
  定位 + 隔离临时 profile（绝不碰用户主 profile）+ Job Object 绑定 + 页面
  级 CDP WebSocket 会话（gorilla/websocket 零新增依赖，写串行/幂等关/事件
  旁路）+ Ensure 幂等与失联自愈 + URL 白名单 http/https；7 个 browser_*
  内置工具（navigate/read/snapshot/click/type/scroll/close，work 空间，ref
  机制 data-gaea-ref+代数守门、React 兼容 type、envelope 结构化返回）；权
  限门（read/snapshot 只读档恒放行、其余写档弹卡可记忆 + permission
  subjectKeys 追加 url 键可固化窄规则）；事件留痕全链对工具名零特判（会话
  JSONL→trajectory→前端过程卡自动展示）。**真机实测 PASS**（真 headless
  Edge 导航/读/snapshot/双路点击/type/file: 拒绝/旧 ref 失效，1.16s）；零
  新增绑定（544）、前端零改动；Go +25 测试全量 0 FAIL、tsc/eslint 0、
  vitest 825/825（首跑 2 例负载 flaky 复跑 0 failed=既有先例）、drift PASS、
  build.bat 冒烟 200。欠账：多标签页、空闲 TTL 关停、文件下载上传/iframe/
  键盘级 Input 事件、headless 开关 UI、Windows UIA（下一块砖）。详见
  releases/v4.13.0.md。

- **v4.12.0（2026-08-31）「成本透亮」**：调研后第一刀（成本层，
  审计 T0 缺口②③的计价前置）——①GLM 价格表补全（原仅 glm-4.7 一条，GLM
  用量实际未被计价；官方 docs.z.ai USD 价 + 既有 usd_cny_rate 折 CNY，免费
  档计 0，未核实者诚实不入表，glm-5-turbo 显式挡板防前缀误匹配）②编码套餐
  积分口径（/api/coding/ 端点调用 billing_mode=coding_points，EstimatedCost
  恒 0 不进 TotalCost，聚合 glm@coding 单列 Tokens 计入费用 0；summary 新
  增 engines 按引擎聚合，旧 stats.json 兼容）③模型别名注记（官方 coding-plan
  概览核实 4 条自动切换：glm-5.2/5.1→glm-5.3、glm-5-turbo/4.7→glm-5.3-flash；
  ModelInfo 加 alias_of 仅 coding 家族下发，std 不注记；前端模型卡「自动切
  换」标记；RecordCall 记账归一让 glm-5.2 用量落 glm-5.3 价格桶；请求名不改
  写，服务端自行切换）④GLM 目录数据驱动（22 模型迁 glm_catalog.json
  //go:embed 逐字锁定；config 新键 glm_catalog_path 覆盖文件 mtime 热重载 +
  坏 JSON 回退内嵌，照 usd_cny_rate 先例启动注入、非密钥无反射测试）。
  **零新增绑定（544→544，bindings_*.go/bindingNames/bridge/spaceBindings
  零改动）**；Go +5 组测试全量绿、vitest 825/825（+4）、tsc/eslint 0、drift
  PASS（544）、build.bat 冒烟 200。执行方式：探索子代理代码地图 → 后端/前
  端实现子代理串行 → 主控全绿门禁复核。欠账：本地-云端路由 v1 本体（下一
  刀，目标函数=本地优先→缓存命中→峰谷）、Context Compiler 前缀策略化、国
  内 CNY 原价表（bigmodel.cn JS 渲染未取得，现 z.ai USD+汇率）、覆盖文件
  UI 入口。详见 releases/v4.12.0.md。

- **模块制市场调研复扫（2026-08-31，调研非刀，v4.11.0 基线，绑定面 544 不变）**：
  8 子代理并行复扫（办公/造价/记忆/模型中心/编程/创作/轻语/触点），合成
  `docs/market-research-2026-08-31.md`（分模块原始稿 `docs/research-2026-08-31/`；已归档 docs/archive/，结论被 2026-09-01 复扫取代）。
  五个确定性：①「可审计」是最深护城河且行业正在逼近（竞品只有事前审批，
  gaea 事后复核链先发半步，Verifier 应产品化为 UI）②本地优先升级为合规红利
  （《AI 拟人化互动服务管理暂行办法》2026-07-15 施行，个人本地使用不在适用
  范围）③计费快变——GLM Coding Plan 已改积分制+旧模型名自动切换，coding
  端点静态适配有失真风险，静态模型目录需热更新；路由 v1 目标函数=本地优先→
  缓存命中→峰谷，不做语义缓存 ④实时语音换挡窗口已开（GLM-Realtime 0.18
  元/分、Qwen3.5-Omni-Realtime 语义打断与 TurnControl 同构，换引擎边际成本低）
  ⑤OpenClaw（38.8 万星）成开源个人助理事实标准，gaea 以「中文办公纵深+可审计
  +双空间隔离」差异化。编程板块 DSH 独立窗口拍板经调研验证仍成立（壳窗已官方
  协议化，独立壳窗商业脆弱）。**候选刀序（供拍板）**：★Realtime 真机收口
  （provider 白名单可顺手扩 "zhipu"）→★指令内核 v1+Ctrl+K 命令面板先行→★
  模型中心计费三件套（目录热更新/GLM 积分口径/成本仪表 v0）→★Verifier 产品化
  （diff 可视化/操作回放/一键回滚）→★做梦 2.0 主动预取 MVP。不做清单：语义
  缓存、算量赛道、人格包公开分享、原生编程工作台。

- **最新发布：v4.11.0（2026-08-30）「GLM 全模态纵深」**：基线 v4.10.0 + 1
  提交（29c23ee），绑定面 543→544；vitest 821/821、drift PASS（544）。
  详见 releases/v4.11.0.md 与下方刀明细。欠账：做梦 2.0 主动预取、
  Realtime 真机、本地-云端自动路由 v1、iLink 语音/视频、更深跳因果。

- **最新发布：v4.11.0（2026-08-30）「GLM 全模态纵深」**：基线 v4.10.0 + 1
  提交（29c23ee），绑定面 543→544；vitest 821/821、drift PASS（544）。
  详见 releases/v4.11.0.md 与下方刀明细。欠账：做梦 2.0 主动预取、
  Realtime 真机、本地-云端自动路由 v1、iLink 语音/视频、更深跳因果。

- **GLM 生图 + 官方双端点（2026-08-30，v4.10.0 后第一刀）**：①生图后端
  `ai.GLMImageBackend`（kind=glm）——官方 images/generations 端点只发
  model/prompt/size（response_format/n 等扩展字段官方 schema 不收，故不复用
  通用 OpenAI 后端），URL 统一下载转 data URL 复用前端落盘链路，官方错误体
  `{"error":{code,message}}` 原样透出，200 无图提示内容审核，img2img 诚实
  拒绝；app 三处接线（initImageBackend / SetImageBackend / 剧照
  buildPortraitClient），GLM Key 经 `Manager.GLMKey()` 与 chat 同源取用，
  size 参数保留（官方接受）。②官方双端点切换 `SetGlmEndpoint`（绑定面
  543→544）——std=/api/paas/v4（按量付费）coding=/api/coding/paas/v4（编码
  套餐额度，官方 coding-plan/quick-start 核实），后端只收两个官方常量
  （GLMBaseURLStd/GLMBaseURLCoding），GLM 卡片 Segmented 切换+落盘持久化；
  云端引擎不露地址框防线延伸，防 Key 粘错框类事故。③静态目录补生图四模型
  （glm-image/cogview-4-250304/cogview-4/cogview-3-flash，锚定官方图像生成
  API 枚举，18→22）+ 修 glm-5-turbo 误分类（通用 turbo 关键词把它判成生图
  ——GLM 引擎先按官方目录判型再落通用关键词表，回归测试锁死）。前端：
  ImageSection 加 GLM 选项、ImageGenPanel 引擎标签诚实化（此前云端引擎也标
  「本地引擎」）、classifyModel 补 cogview、glmEndpointFamily 判定工具。
  Go +15 测试、vitest 821/821、tsc/eslint 0、drift PASS（544）。

- **最新发布：v4.10.0（2026-08-30）「GLM 引擎 · 办公秘书人设」**：v4.9.0
  后 9 提交（GLM 引擎三轮真机打通 + 工作人设收口 + 审计欠账三刀 + Herdsman
  CLI 透明化），绑定面 540→543；vitest 818/818、drift PASS（543）、build.bat
  冒烟 200。用户已确认 GLM 可用。欠账清单见 releases/v4.10.0.md。
- **GLM 按官方文档重写（2026-08-30，两轮不可用后核对 docs.bigmodel.cn）**：
  根本误判=智谱无 /models 端点（文档仅 chat/completions 等），此前测试连接
  /刷新模型永远失败。重写：glmStaticModels 静态目录（锚定官方模型概览：
  glm-5.3 旗舰/4.7-flash 免费/tts·asr·embedding·rerank 全家桶）+
  TestConnection 走最小 chat ping 真实验证 Bearer Key（错误体官方形态原样
  透出）+ 默认模型 glm-5.3。Go +2 测试、绑定面 543 不变。教训入账：**接新
  云端引擎先读官方文档验证端点清单，禁止拿 OpenAI 习惯外推**。
- **GLM 地址防呆（2026-08-30，真机实测收口）**：用户把 Key 粘进 GLM 地址框
  （云端引擎误露地址框=UI 疏漏）→ base_url=Key 本体 → 请求报 unsupported
  protocol scheme "" 且原生错误回显 Key。修复：地址框仅本地引擎显示；
  SaveEngine 拒绝无 scheme 地址（不回显原值）；LoadState 忽略脏地址自愈
  （重启即恢复预置）；fetchModels 友好错误。+1 回归测试，绑定面 543 不变。
  用户侧：重启应用自愈；Key 已泄漏建议重新生成。
- **模型中心新增 GLM 引擎（2026-08-30）**：智谱 GLM 云端（OpenAI 兼容
  open.bigmodel.cn/api/paas/v4，端点已实测 401=存在）照 DeepSeek 模式全链
  路接入——EngineGLM 常量+预置卡（默认 glm-4.6，排序在 DeepSeek 后）+
  glm_api_key DPAPI 加密落盘/旧明文迁移 + SetGlmKey/GetGlmKeyStatus 绑定
  （541→543）+ GaeaSetProviderKey 映射 + 前端引擎卡 Key 输入。云端属性
  IsLocal=false，离线模式自动跳过、用量统计自动归类。Go +2 测试（预置数
  7→8 断言同步、GLM key/URL/云端属性）、vitest 818/818、tsc/eslint 0、
  drift PASS（543）。
- **Herdsman CLI 错误透明化（2026-08-30，真机诊断收口）**：模型中心「模型
  库」报「exit status 3」三路实证根因=Herdsman 桌面端以管理员运行，skill
  管道（Herdsman-skill-v1）DACL 拒绝普通权限 gaea（桌面端在跑但连不上）。
  runHerdsmanCLI 失败路径改捕获 stdout 透出 CLI 结构化错误（error 字符串/
  对象两态兼容）+ Access denied 定向提示「普通方式重启 Herdsman」；不再
  显示误导性的「请确认桌面端已启动」。Go +3 测试、前端零改动、绑定面 541
  不变。用户侧解法=普通方式重启 Herdsman（取消快捷方式的「以管理员身份
  运行」勾选）。
- **工作人设收口（2026-08-30，用户拍板：gaea=专业严谨的办公秘书，不是文艺
  女青年）**：微信/语音实测「[SPLIT] 裸漏+答非所问」三根因一并收口——
  ①节奏引擎 professional tag 豁免（PAD 标尺下 chatter 阈值形同虚设，gaea/
  secretary 永不拆分，乐园陪伴人格保持原设计）②[SPLIT] 出口净化（内部
  格式协议全仓库零消费方，WhisperChat 三出口共同上游归一为换行）③搜索
  触发收窄（删口语疑问词，保显式动词+硬时效词，宁漏勿误）。新增「办公
  秘书」人格（30→31，结论先行/要点分明/禁撒娇禁文艺腔）。Go +8 测试、
  前端零改动、绑定面 541 不变。人设方向：工作通道（语音/微信/任务对话）
  锁 professional；乐园 29 陪伴人格不动——双空间各归其位。
- **做梦 2.0 蒸馏真实合并（2026-08-30，路线图 T0 第一刀）**：自动做梦只增
  不减的重复记忆有了非破坏合并通道——memory.DistillMergeCandidates 纯函数
  检测（同空间内同名异写 / 异名同 type+kind 同描述；跨空间不成候选=双空间
  红线；封顶 8 条同输入同输出）+ control.DistillMerge 锁内重算校验执行
  （Store.Archive 归档较旧条可逆 + Touch 保留条 + dream 审计
  source=distill_merge，越权配对拒绝）+ 记忆面板「建议」合并卡区 +
  GaeaAcceptMergeSuggestion（绑定面 540→541）。Go +7 测试、vitest 818/818、
  tsc/eslint 0、drift PASS（541）。欠账延续：做梦 2.0 主动预取留后续刀。
- **T0 内核层盘点（2026-08-30，审计「待补充」项收口）**：grep 到实现实证——
  MCP host client（GaeaAddMCPServer/Remove/Retry 等绑定，tools 面）已实装；
  做梦管线（auto_dream + 审计）在库；agent 层 compaction（窗口/阈值/digest
  稳定前缀）+ 工具目录 cache 指纹 + budget 钱闸 + contextview 装配视图均
  已有。路线图 T0 四项真实缺口仅剩：做梦 2.0 主动预取、本地-云端自动路由
  v1+成本仪表增量、Context Compiler 的预算调度/前缀排序策略化（装配明细
  category 条已在 ContextView 呈现）。
- **Verifier 通道 A 引用级深化（2026-08-30，审计欠账收口）**：xlsx_apply 复核
  从「重算零错误」升级为 +「声明↔实况」引用级比对——ChangeRecord 增可选
  opsJson（落卡随卡携带，超限不落），复核逐条回读工作簿（set_value 浮点等值
  比值 / set_formula 剥 = 归一比公式 / replace 比落盘），批量/样式类诚实跳过
  计数，不符即 fail 并给预期/实际示例；旧卡无 opsJson 按不适用降级（宁漏勿
  误）。Go +9 测试、前端零改动（vitest 818/818 沿用，ProgrammingPage 1 例负载
  型超时=既有 flaky，单跑绿）、绑定面 540 不变。勘误：v4.9.0 欠账清单「锚点
  策略刻度对齐」已在 90ab160 交付，一并移除。
- **多跳因果链（2026-08-30，因果推断纵深）**：GaeaWhisperCausalExplain 证据
  从单跳升级 ≤2 跳因果链——buildCausalChains 在 KG「导致」边上有界 DFS（溯源
  +顺藤双向），链按因果序渲染「A → 导致 → B → 导致 → X」，防环双保险 + 链
  封顶 4 条 + 单跳去重；提示词补链语义。Go +4 测试、vitest 818/818 沿用
  （前端零改动）、tsc/eslint 0、绑定面 540 不变。说明：跳数=2 为诚实边界
  （substring 匹配下更深噪声放大），语义锚定多跳推理留后续；文档纠偏——
  成本知识图谱 v4.8.0 已交付（BuildGraph + CostGraphView），从欠账清单移除。
- **最新发布：v4.9.0（2026-08-30）「星枢首页·轻语记忆纵深」**：基线 v4.8.3
  + 15 提交（轻语记忆回放系列 + 图谱三维度 + 跨事实因果推断 + 首页重构
  「星枢指挥所」+ 两段式启动动画 + 工程化收尾），绑定面 535→540；vitest
  818/818、drift PASS（540）、build.bat 冒烟 200（顺带修 pwsh→powershell
  回退）。欠账清单见 releases/v4.9.0.md；下一执行 = Realtime 真机验证轮。
- **首页重构「星枢指挥所」+ 启动动画（2026-08-30，v4.9.0）**：启动默认从首页
  落地（MainLayout 不再恢复上次页面，跨空间恢复保留）；两段式启动动画
  （index.html 静态启动屏 → BootSplash 组件：光环 + 徽记 + 分步状态 + 进度条，
  rAF 节流 / reduced-motion 全降级）；首页 Hero 中轴 + 命令条（orb/打字/语音/
  ⌘K）+ 真实遥测细条 + 能力矩阵 Bento（manifest 驱动，旗舰卡双类提权）+
  门廊 + 信息条；i18n 三语 home.*/boot.* 共 17 键。vitest 818/818、tsc/eslint 0、
  wails build 冒烟正常。说明：语音晶核收进命令条 orb；规格同步
  design-system/gaea/pages/home.md（v3）。
- **跨事实因果推断「为什么」（2026-08-30，审计 §C 深度补口）**：
  GaeaWhisperCausalExplain（绑定面 540，play）——问「为什么<entity>」时确定性
  收集证据（KG「导致」三元组 + event_chain 关联，上限 8 条），当前人格口吻 LLM
  解释因果链（只用证据 / 不编造 / 证据不足诚实说明 / ≤200 字）；无证据零 LLM
  调用回退文案。图谱面板「解释因果」按钮 + 结果区。Go +5 测试、vitest +1
  （818/818）、tsc/eslint 0、drift PASS（540）。说明：证据 = 确定性规则，LLM
  只做人话化；多跳因果图推理留后续。
- **关联入图（2026-08-30，审计 §C「推理仅邻接遍历」补口）**：
  GaeaWhisperGraphSubgraph 并入 AssocIndex 关联边——事实 Subject → 实体节点，
  类型映射中文（event_chain→因果、temporal→时间、thematic→主题…），权重 =
  strength，只并入与子图连通者；前端因果边琥珀色虚线 + 图例。Go +2 测试、
  vitest +1（817/817）、tsc/eslint 0、绑定面 539 不变。说明：event_chain 数据源
  = LLM 整合 + 冷启动启发式（同子类近似因果）；LLM 深度跨事实因果推断留后续。
- **图谱因果维度（2026-08-30，审计 §C 欠账收口）**：extractCausalTriples 从事实
  摘要确定性提取 {因, 导致, 果}（因为/由于…所以…、X导致/引发/造成Y、X让我/使我Y，
  正则 + 测试锁定，直接式剥离连接词），情绪随事实落图；ingest 与文档导入双路径
  接线，图谱面板「导致」谓词天然渲染。Go +6 测试、vitest 816/816 沿用（前端零
  改动）、tsc/eslint 0、绑定面 539 不变。观察项：关联表 event_chain 未在图谱
  展示；LLM 跨事实因果推断留后续设计。
- **图谱情绪维度（2026-08-30，审计 §C 欠账收口）**：Triple 增情绪三字段
  （EmotionLabel/Intensity/Valence），事实提取 attachEmotion 落图（效价派生
  正面/负面/中性），新增 AddTriple 保留情绪（Add 兼容旧调用）；BASIC_PROFILE
  主语实体化（档案键替代硬编码「用户」）；hermes.db 迁移 V13→V14
  （knowledge_triples +3 列，存量安全）；前端图谱边按情绪着色 + 图例。
  Go +5 测试、vitest +1（816/816）、tsc/eslint 0、绑定面 539 不变。欠账延续：
  因果维度未做（需 LLM/事件链）、时空索引未建（暂以 CreatedAt 承担）。
- **记忆重述 + 锚点刻度对齐（2026-08-30，记忆回放收尾两刀）**：
  GaeaWhisperMemoryRetell（绑定面 539，play）——LLM 以当前人格口吻把情节/锚点
  记忆重述成故事（输入复用确定性回放：摘要+情绪+原文对话；第一人称/称「你」/
  ≤300 字），episode/anchor 双入口 + 前端「让 gaea 重述这段记忆」按钮（MemoryRetell
  组件三态）；锚点策略阈值刻度对齐（weight≥2/selfRelevance≥4 在 0-1 抽取标尺上
  不可达 → 0.9/0.8/0.9，偏离 ackem 已注释），补策略测试 2 组。Go 全量绿、
  vitest 815/815、tsc/eslint 0、drift PASS（539）。
- **时间锚点「重访那一天」（2026-08-30，记忆回放续刀）**：写路径接线——
  ShouldWriteTemporalAnchor/BuildTemporalAnchor 此前有定义无生产调用（同类骨架
  欠账），现经 MemoryWritePayload/IngestTurnArgs 的 TemporalAnchorSink 逐事实
  评估（IsNew=计数差）→ Orchestrator.AddTemporalAnchor（回合锁内）落
  State.TemporalAnchors 随 companion_state 持久化；读路径 GaeaWhisperAnchors +
  GaeaWhisperAnchorReplay（锚点→事实轮次→情节→原文回放，绑定面 538）；前端记忆库
  「纪念日」tab + 回放弹窗（ReplayDialogue 与情节回放共用）。Go 8 新测试、vitest
  +2（813/813）、tsc/eslint 0、drift PASS。观察项：锚点策略阈值（weight≥2/
  selfRelevance≥4）与 LLM 抽取标尺（0-1）刻度不一致，常命中周期纪念日分支，
  刻度对齐留后续决策；LLM 重述未做（当前为确定性原文回放）。
- **轻语记忆回放（2026-08-30，审计 §C 欠账收口）**：新绑定
  GaeaWhisperEpisodeReplay（绑定面 535→536，MemoryB/play）——按情节 ID 从
  hermes.db 读情节 + SourceSessionID/[StartTurn,EndTurn] 从 chat_history 确定性
  重建原始对话（不调 LLM），过旧情节 Replayable=false 回退仅摘要；前端情节详情
  弹窗新增「回放原始对话」气泡视图（用户/gaea + 轮次，加载/失败/不可回放三态）。
  Go 3 测试 + vitest 2 测试；验证：Go 全量绿（whisper 偶发挂起为环境 flake，
  单跑绿）、vitest 811/811、tsc/eslint 0、drift PASS（536）。欠账延续：时间锚点
  「重访雨夜」入口、图谱情感/因果维度。
- **构建冒烟自动化（2026-08-30，v4.8.3 教训收口）**：build.bat 真实退出码 +
  产物新鲜度守卫（构建前删旧 exe、被常驻实例锁定时显式报错）+ 默认自动冒烟
  （.tmp 临时副本 → scripts/smoke.ps1，18999 /api/health 200 + status=ok 响应
  体校验，失败即停并提示勿发布）；`build.bat skip-smoke` 跳过（快速迭代）；
  smoke.ps1 增 Start-Process 失败显式报错、响应体校验、finally 判空回收。
  验证：默认路径实跑绿（构建 44.5s + 冒烟通过 + 进程回收）；失败路径假
  wails 桩实测 [FAIL] + exit 1。
- **最新小步（2026-08-30，欠账收尾）**：①VoiceStart realtime 门小修——
  端到端回复走服务端 response 事件（事件泵不经 whisperChatFn），realtime
  在位时不再要求 whisper 对话回调，whisperChatFn=nil 也可启动；拼接管线
  双门（ASRReady + WhisperReady）逐字节保留，新增两回归测试 ②持久化套件
  统一——desktop_session SaveModes 走 fileutil.AtomicWrite（临时文件+
  rename，不留半截 JSON）、archive JSONL 单次 Write 落整行（消除双写撕裂
  窗），新增 7 回归测试 ③XlsxPreview 大表格行虚拟滚动（观察项收账）——
  300 行以上只渲染可见窗口 ±10 overscan + spacer 保滚动条总高，冻结行常
  驻；2000×100 预览不再整表 20 万 td，小表全量渲染逐字节不变；2 新
  vitest。验证：Go 全量绿、vitest **809/809**（148 文件）、tsc/eslint 0、
  绑定面 535 不变、drift 不受影响。
- **最新发布：v4.8.3（2026-08-30）**——微信图片双向真协议（v4.8.2 发布
  当日真机实测复盘五刀）：①出图回推 getuploadurl→AES-128-ECB→CDN 密文
  上传→image_item 卡片+caption 补发，真机 delivered（此前 SendFileCard
  是孤儿=真凶）②发图识别 type=2+aeskey 解密下载→魔数终审落盘，真机两
  连发通过 ③识图模型升级多模态 Qwen3.6-35B 优先（手写体强、零额外显存），
  PaddleOCR→MinerU→OvisOCR2 降兜底 ④身份类问题跳过联网搜索（乱字母根
  因）⑤关键坑锁死（type=2/aes_key=base64(hex)/上传域与扫码 baseurl 无
  关）。协议三方印证（本机抓包解密+hermes-agent+openilink SDK）。验证：
  Go 全量绿、绑定 535 不变、前端零改动。详见 releases/v4.8.3.md。
- **下一执行**：Realtime 真机验证轮（真 key 下端到端对话/打断体感/AEC，
  S2 骨架已就绪）；手写识别质量复测；iLink 语音/视频 item 未探明（静默
  跳过）=观察项；生命库可写化=观察项。
- 构建注意：wails build 走 `build.bat` 的 TMP/TEMP 重定向到 `.tmp`（规避 SAC
  策略拦截）。

## 长期规划（权威文档）

- **`docs/gaea-nextgen-roadmap-2026.md`** —— gaea 长期规划（2026+）：
  8 板块竞品调研 + WorkBuddy×灵犀 对标 + **版本重定义（双空间：工位/乐园）** +
  四层落地（后端/前端/UX/UI）+ 执行计划（阶段 0 地基 → 阶段 1 双空间内核 →
  阶段 2 双空间壳 → 阶段 3+ 领域包）。
- **用户拍板（重要）**：**工作与娱乐分开、互不干扰**——工位（办公/造价/编程/资料记忆）与
  乐园（轻语/小说/绘梦/阅读）双空间硬隔离；记忆分区、模型策略各配、上下文永不跨界；
  跨空间仅用户显式发起。~~"陪伴×办公融合"~~ 已删除。
- **用户拍板（2026 追加）**：**编程板块与办公板块不得混合**——保持现状 DSH 独立窗口
  （iframe），不并入工位、不共享工具面（防工具膨胀）；不做原生编程工作台/MCP 板块总线
  喂办公工具给编码 agent（长期规划 §4/§10.3/§13.1 已修订）。
- 本轮调研另一项关键纠正：**灵犀 = 金山 WPS 独立 AI 办公 Agent**（非阿里/通义）；
  **WorkBuddy = 腾讯云 CodeBuddy 全场景 AI 办公工作台**（非 Kimi 系，Kimi Work 是月之暗面的）。

## 下一步执行（按执行计划 §14）

### 阶段 0 · 地基修补 —— ✅ 全部完成（12 提交）
- [x] **S0.1** AgentRunner 回合级 map 并发加固（turnMu）+ 回归测试 —— `96644b9`（临时 worktree 实证修复前必崩）
- [x] **S0.2** tool.Registry RWMutex + suspended 幽灵名修复 —— `a77ce5e`（全包 -race 绿）
- [x] **S0.3** gate 改 atomic.Pointer[gateWrapper]（撕裂换闸）—— `8b661d2`
- [x] **S0.4** retry_until 走统 gated 派发（堵绕过审批 shell）—— `87bbf20`
- [x] **S0.5** CI 后端 job 加 `go test -race`（独立 ubuntu job）—— `afefa11`
- [x] **S0.6 edit_file 工具层**（grep/edit_file/multi_edit/edit_lines/move_file 五工具 + 名单全对齐 + 双路径失效特判）—— `7d560e6`
- [x] **S0.7/隔离岛** knowledge 索引缓存 `aadb7aa`；office 原子写 `5a82209`；secure 非 Win AES-GCM `fa1778f`；tasks LRU `2a3ca50`
- [x] **前端** 聊天 memo+尾部窗口 `9a41090`；keepAlive 轮询门控 `d373fba`
- [x] 遗留收尾：gate_test.go stubGate 计数器加锁（v4.8.2 已清账）；持久化
  套件统一（desktop_session SaveModes → fileutil.AtomicWrite；archive
  JSONL 单次 Write 落整行）——本轮收口

### 阶段 1 · 双空间内核（后端 space 维度）—— ✅ 全部完成（S1.1-S1.5）
- [x] **S1.1 空间维度落地**（设计文档 `docs/gaea-space-dimension-design.md`）：
  - [x] S1 列落库（SchemaV14）`5c24d16`｜S2 会话空间（目录分区+日志/checkpoint space+开关）`0722aeb`｜S3 子代理继承 `76f565e`｜S4 产物分区+绑定面（499→502）`5c9fc4e`
- [x] **S1.2 记忆空间隔离器**（设计 `docs/gaea-memory-isolation-design.md`）：后端 A+B `819d7ff`+`f0187a2`（写侧盖章/读端隔离/UnifiedSearch scope）；前端 C `53d621d`
- [x] **S1.3 模型 profile + 工具标签**（装配族 `f8612d0`）：`[space_profiles]` 段 + 工具装配期过滤（work 33/play 1/shared 13）+ MCP spec 层滤
- [x] **S1.4 任务分账**（`5ccaa7a`）：per-space 并发/优先级 pickNext + HasActiveInSpace + cron 显式 work + GaeaTaskList 变参
- [x] **S1.5 空间策略**：S1.5-A 权限按空间+hardAsk 参数化+persist_allow 分段（装配族 `f8612d0`）；S1.5-B play 护栏 5 处钳制（`21f8978`）
- 设计文档：`docs/gaea-space-dimension-design.md` / `gaea-memory-isolation-design.md` / `gaea-space-assembly-design.md`

### 阶段 2 · 双空间壳（前端两视图，S2.1-S2.3）—— 全部完成
- [x] **S2.1 壳层重构**（设计 `docs/gaea-space-shell-design.md`）：
  - [x] manifest 空间维度（Go + TS 同构）：work/play/shared/**independent**（编程 DSH 独立窗口，
    用户拍板不并入工位/乐园）——导航/启动器/快捷键/导航事件白名单全部由 manifest.space 派生
  - [x] 两视图壳层：CommandRail 空间切换（appStore.space 持久化 `gaea.shell.space`）+ 按空间菜单
    （shared + 当前空间）；独立窗口板块单独 rail 入口；每空间最后页面持久化 `gaea.shell.page.<space>`
  - [x] 双首页：ModuleLauncher 按空间装配（工位=任务工作台门面 / 乐园=会客厅创作间门面）
  - [x] 事件订阅空间过滤：events.ts `subscribeForSpace`（payload.spaceId/space 过滤）；
    TaskCenter/useRunningBadge 只收工位任务（TaskView.spaceId）
  - [x] Ctrl+K 搜索 scope：工位/乐园/全部三档，默认当前空间（工位=UnifiedSearch；乐园=项目搜索）
- [x] **S2.2 增量**：
  - [x] 工作台 localStorage 空间分键 + 迁移（`workbenchStorage`：rightTab/布局/chatTab/
    compact/focus → `gaea.work.*`，旧 key 只读回退）
  - [x] 性能门控：空间切换剪枝 keepAlive 保活页（跨空间页面卸载，后台轮询归零）
  - [x] i18n 全铺第一刀：LocaleProvider 提升根级 + S2.1 新壳 chrome 文案三语字典化
  - [x] **i18n 存量切片（壳层 chrome）**：MainLayout（strip/rail/telemetry 超载警告等）
    + ModuleLauncher（统计卡/语音/信息条/相对时间）+ SearchModal（分类标签/计数）
    全部三语字典化（~90 新 key）；fmtWords/fmtRel 接 translator
  - [x] **i18n 存量切片（SettingsPage 外壳）**：控制室/搜索/分类导航/帮助面板
    三语化（~40 新 key）；分类 label/desc 接 labelKey/descKey（keywords 为搜索数据保留 zh）；
    SettingsPage.test 包 LocaleProvider + 固定 zh
  - [x] **i18n 决策定稿（2026 追加）**：采用审计 §405「诚实 zh-only」选项——
    **壳层 chrome + 设置外壳三语（已完成，消灭壳层混合语言根因）；页面内容层
    保持 zh 单语**，不再逐页铺 en/zh-TW 字典（~5000 字符、边际价值≈0、个人
    中文工具无国际化受众）。若未来需要国际化，按 S2.3b WireShape 模式整页迁移。
  - [x] **页面迁入收口**（`docs/gaea-page-migration-design.md`）：处置矩阵按版本锚点
    落账——办公升格/造价领域包/编程独立/记忆侧栏形态/微信触点 v4.0 已达成；
    **P1 对话流**（chat shared→play：工位不再有独立聊天板块，乐园=会客厅）本轮落地；
    创作间合并=v4.3（§10.4 明示）、模型中心并入设置=v4.1+、微信任务入口=v4.4
- [x] **S2.3 bridge 分面 + types 生成化**：
  - [x] `spaceBindings.ts` 分类表：AppBindings 214 方法显式分类（work/play/shared/
    independent），satisfies + 双向断言编译期全覆盖；UnifiedSearch=shared（scope 隔离）
  - [x] bridge 三门面 workApp/playApp/sharedApp（类型级 + 运行时双保险）；
    TaskCenter/useRunningBadge 消费 workApp
  - [x] types 生成化第一刀：typesGenerationCheck.ts 编译期漂移校验 + 修 SessionMeta.spaceId
  - [x] **S2.3b types 全量迁移**：WireShape 剥生成类实例方法，55 个重叠类型改别名
    （1375→1065 行）；增强类型（TaskStatus/TaskView/SearchScope 等）保留手写；
    顺带修 FileSearchHit.modTime / UpdateInfo.version / FilePreview 契约漂移
  - [x] **S0.7 遗留：151 hex token 化**（审计点名的 VoiceSettingsPanel 浅色主题崩坏
    真 bug 已修——dark-zinc 硬编码 → 主题 token）：语义色（成功/警告/危险/文本/表面/
    边框/主色）全部 token 化；图表调色板/品牌识别色/图片覆盖层/主题预览样张/标注数据色
    显式 `// hex-exempt` 豁免（审计口径「图表豁免」）；新增 eslint 规则
    `local/no-raw-hex`（图表/数据文件白名单 + 行内豁免注释）防回归

### 阶段 3 · 领域包纵深（v4.1 → v4.4）—— v4.1 设计定稿
- [x] **v4.1 办公信任链设计**（`docs/gaea-v41-evidence-chain-design.md`）：
  evidence.Record（原文摘要/来源/模型/时间戳/回滚信息）+ Apply→Verify→Journal
  三段式 + Verifier 双通道（结构/引用完整性 + PDF 视觉 diff）+ 基线快照回滚
  （用户手工编辑冲突保护）+ GB/T 9704 红头 lint 第一刀；Step 拆 v4.1a/b/c
- [x] **v4.1a 证据链核心**：ChangeRecord（原文摘要 8KB）+ ChangeLedger（ctx 盖章）
  + JournalStore（JSONL 追加 + turn markdown 投影）；AgentRunner 回合收尾 flush
  （play 不落盘红线）；edit_file/write_file/move_file 接入上报
- [x] **v4.1a2 证据链补齐**：multi_edit/edit_lines 逐条摘要；xlsx_apply 接入
  （App 层写 Journal，SessionID 取自控制器，play 红线过滤）；新绑定
  GaeaJournalList（gen_bindings 重生成 bindingNames 503）+ 前端「证据」入口
  （DeliverablesPanel 证据链折叠区，展示最近证据卡）
- [x] **v4.1b Verifier + 回滚**：基线快照（写盘工具 + xlsx 应用前）；GaeaVerifyRecord
  双通道复核（A 结构/引用完整性 + B 基线 PDF 视觉健全性）+ verdict 落库；
  GaeaRollbackRecord 基线回滚 + 手工编辑冲突保护；前端证据卡复核/回滚操作
- [x] **v4.1c 规范包**：internal/office/standard GB/T 9704 红头 7 要素 lint +
  GaeaDocumentLint 绑定 + OfficePanel「规范体检」入口

### v4.2 造价 AI 化 —— ✅ 全部完成（v4.2.0 发布）
- [x] **v4.2 设计定稿**（`docs/gaea-v42-cost-ai-design.md`）：三支柱契约 +
  SchemaV15 数据模型（cost_inquiry_records / cost_stage_values）+ 绑定面 + Step 拆分
- [x] **v4.2a 组价底座**：`cost.PriceBand` 价格带推荐纯函数（P25/P50/P75/离散度/
  离群/置信度/证据链 BandSource，R-7 分位数与 costref 同口径）+ `RecommendPrice`
  五档；22 测试
- [x] **v4.2b 询价飞轮核心包**：`costinquiry` 四源归一数据点（信息价/OCR报价/供应商
  比价/手动询价）+ 到期预警（valid_until ≤ today+days）+ 调差建议（标题归一化匹配
  + |差幅|>2%）；7 测试
- [x] **v4.2b 五算对比核心包**：`coststage` 估/概/预/结/决阶段值（UPSERT）+ 对比
  计算（环比/累计差/除零保护）+ 偏差特征（正常<5/关注 5-15/异常>15 + 规则文案）；
  17 测试
- [x] **v4.2c AI 组价绑定**：`GaeaCostCompose`（关键词+语义召回+rerank 精排 →
  PriceBand → LLM 人材机拆解 `routeSensitiveLocal("office")` 失败规则降级 →
  建议视图）+ `GaeaCostComposeApply` 回写
- [x] **v4.2d 前端面板**：ComposeModal（测算明细行「AI 组价」：价格带卡/证据链 8 列
  表/人材机行编辑 → 应用为明细行）；询价视图（CostLibraryView 第三视图：数据点
  CRUD/四源徽标/预警横幅/调差一键更新）；FiveCalcPanel（项目详情五算区：输入保存/
  对比表着色/偏差卡）
- [x] **后端集成**：SchemaV15 正式迁移收编 + CostB 门面 11 新绑定（gen_bindings
  重生成，绑定面 506→517）+ bindingNames/spaceBindings(229)/bridge/types 接线

**v4.2 造价 AI 化已收官**（bindingNames 517 / spaceBindings 229 / vitest 759
+ go 全量绿）。剩余领域包：v4.3 乐园 / v4.4 触点（§10.4）。

### v4.3 乐园做深 —— ✅ 全部完成（v4.3.0 发布）
- [x] **v4.3 设计定稿**（`docs/gaea-v43-play-deepen-design.md`）：4 份只读调研
  （轻语关系记忆/情感语音 TTS/创作间世界模型/角色资产库）结论入账——后端骨架约
  70% 已存在，本版以「接线 + 参数扩展 + 持久化闭环」为主
- [x] **v4.3a 轻语记忆持久化闭环**：memory_associations/user_habits/temporal_anchors
  三表补 repo（此前有 schema 无 repos）+ 装配进持久化链 + ReseedAssociationGraph
  打通 + hermes.db 外键延迟检查实证修复
- [x] **v4.3b 关系图谱子图召回**：KnowledgeGraph.QuerySubgraph 多跳邻接（BFS+去重+
  权重，10 测试）+ GaeaWhisperGraphSubgraph 绑定（play）
- [x] **v4.3c 主动关心**：GaeaWhisperProactiveNow 评估绑定（门控+合成器复用）；
  前端「轻语先开口」；定时推送留后续小步
- [x] **v4.3d 情感语音**：TTSProvider.SynthesizeWithParams 参数扩展（cosyvoice 工厂
  修复不丢 voiceDescription、edge SSML 参数化）+ GetEmotionVoiceParams 情绪映射 +
  EmotionState.Mood 长期心境维（EWMA α=0.01 持久化）+ TTSSpeakBase64WithParams
- [x] **v4.3g 创作间图文联动**：章节配图复活死绑定（ChapterPage 按钮 + 弹窗）；
  GaeaGenerateBookCover 3:4 书封落 play exports（修 Windows 盘符卷 bug）
- [x] **绑定集成**：gen_bindings 522（+5，显式覆盖归位 voice/novel）+ bindingNames/
  spaceBindings(233)/bridge/types 接线

### v4.3 后续小步 —— ✅ 全部完成（v4.3.1 发布）
- [x] **主动关心定时推送频控（v4.3c 补完）**：app 层 ticker 四信号评估（AttentionManager
  频控 ≤3 条/小时 → MatchHabits dnd 作息尊重 → DetectSpecialDatesV2 生日祝福（每天首条、
  人格感知提示词）→ 门控+合成器）→ `gaea-whisper-proactive` 事件推前端（space=play）；
  新绑定 GaeaWhisperProactiveConfig/SetProactiveConfig（开关/上限/间隔/免打扰时窗）；
  前端 WhisperGraphPanel 订阅显示推送气泡（birthday 徽标）；16 Go 测试
- [x] **设定页维度化编辑器 + 伏笔登记表 + 一致性面板（v4.3e/f 落地）**：NovelSettingPage
  「维度化」模式（6 维度卡片就地编辑整存，复用已有绑定）+ ForeshadowPanel（状态流转/
  回收率）+ ConsistencyPanel（三类告警/重新检查）；7 vitest
- [x] **角色参考图 + 生图参考槽（v4.3g 补完）**：characterlib SchemaV2 迁移（reference/
  gallery_images 两列幂等）+ CharacterGeneratePortraitWithRef（img2img 参考槽 denoise
  0.55 + 模型门禁）+ 前端参考图管理（以参考图生成剧照）；8 vitest + 5 Go 测试
- [x] **文本朗读情绪 UI（v4.3d 收尾）**：EmotionSpeakSelector（9 标签对齐 EmotionVoiceMap）+
  会话情绪自动跟随 + TTSSpeakBase64WithParams 携带情绪（无情绪回退原路径）；3 vitest
- [x] **绑定收口**：gen_bindings 525（+3）+ bindingNames/spaceBindings(235)/bridge/types

**v4.3.1 后续小步已收官**（bindingNames 525 / spaceBindings 235 / vitest 789
+ go 118/118 包）。剩余：v4.4.1 触发已有能力（生图/办公任务路由 + 图片/文件卡片协议）+ 语音双通路（work 指令/play 闲聊分叉）+ 全局离线模式总开关（§10.4）；观察项（主动关心配置面板、角色 gallery 管理、IP-Adapter 节点级参考槽）。

### v4.3.2 首页重构（双翼·中庭 + 空间导航收敛）—— ✅ 已完成（v4.3.2 发布）
- [x] **首页「双翼·中庭」**：中庭 = 语音 + 打字一体对话条（输入框打字走
  `VoiceChatText` 复用语音对话管道，回复经 voice:reply 回传；orb 放大 148px
  呼吸环磁吸锚点；hero 让位顶部细眉——遵循 design-taste-frontend：不对称组织、
  避免等宽栏与居中 hero 俗套）；左翼「书房」2×2 紧凑格（办公/造价/记忆/模型）；
  右翼「庭院」纵向列表（聊天/小说/绘梦/角色）；门廊 = 编程（独立窗口徽标）+
  设置。命名 工位→**书房**、乐园→**庭院**（三语字典同步）。
- [x] **空间导航收敛**：移除一级导航（rail）顶部空间切换按钮（此前位置隐蔽）；
  `navigateBoard` 统一导航按板块 manifest.space 自动切空间（书房板块→work /
  庭院板块→play / 编程→independent / 设置→shared）；rail 展示全部板块；
  搜索 scope 文案同步 书房/庭院（useSpaceScope）。
- [x] **验证**：Go 全量绿；vitest 789/789（scope 断言同步）；tsc/eslint 0；
  版本五处统一 4.3.2；桌面端 gaea-v4.3.2.exe（33MB，SHA256 6a0486db）+
  冒烟 /api/health 200。提交：9789d7e / 71b0f2b / 766a9f6 / 0f21650。
- 遗留：中庭对话条桌面端语音+打字双通道实际体验待验证；双翼板块卡数量由
  manifest 派生（新板块自动入对应栏）。

### v4.4.0 触点一期（微信遥控器·离线代办）—— ✅ 已完成（v4.4.0 发布）
- [x] **主动推送通路**：weixin.Server 最近活跃会话记忆（handle 时记录
  fromUser/contextToken）+ Push 主动回推文本（无会话报错）；httptest
  校验 sendmessage 目标与文本 item（3 测试）
- [x] **离线代办提醒域**（weixin_reminder.go）：中文时间解析（相对时长/
  日期前缀+段词/裸时刻 20 用例表驱动，中文数字「十」进位，明早/明晚
  预处理拆词，无段词字面解释）→ wxReminder JSON 持久化（重启恢复，
  done 不重推）→ tryWxReminder 微信消息任务路由（提醒类接管/解析失败
  回格式提示/其余走聊天）→ 20s ticker 到点回推（失败重试 ≤5 标 failed）
  → remindersEnabled 开关持久化
- [x] **WeixinPage 落地（书房板块）**：扫码绑定流（QR 轮询/need_verifycode
  配对码/confirmed 落 WhisperAssistantSave 自动重拉通道）+ 通道状态徽标
  （运行/过期/未绑定）+ 提醒列表（手动新建/删除/回推开关）+ 指令说明；
  weixin 板块 Page=""→WeixinPage、inMenu=true（rail + 首页左翼书房格
  manifest 派生自动生效）
- [x] **绑定面 525→530**：WhisperWeixin* 4 + WhisperAssistant* 3 自
  LegacySurfaceNames 转正；WeixinReminder* 5 新增（voice 门面）；
  spaceBindings 235→247 全归 work；bindingNames.ts 同步
- [x] **验证**：Go 107/107 包；vitest 789/789（manifests/launcher/
  spaceBindings/board_manifest 锁数量断言 +12 同步）；tsc/eslint 0；
  drift 530 PASS；版本五处统一 4.4.0；gaea-v4.4.0.exe（35MB，
  SHA256 ee9b45c2）+ 冒烟 200。提交：v4.4a 后端 / v4.4b 前端 / release
- 遗留：回推目标=最近活跃会话（多联系人场景由多助手隔离）；iLink 图片/
  文件卡片协议未探明（v4.4.1 触发生图/办公任务回推时处理）；LLM 意图
  路由（通用任务化）留后续刀

### v4.5.0 指令中枢（统一意图路由 + 语音指令）—— ✅ 已完成（v4.5.0 发布）
- [x] **规划修订**（docs/gaea-nextgen-roadmap-2026.md §10.4a + 阶段 4）：审查
  结论=§8 革命性跃升未实质落地，插入 v4.5 指令中枢主轴（同内核多入口），
  v4.6 端到端实时语音接替排期
- [x] **S4.1 intent 解析包**：导航/生图/状态/提醒四类意图 + 板块别名表；
  宁漏勿误纪律（21 命中 + 8 误判防线表驱动）
- [x] **S4.2 能力执行层**：App.routeIntent——navigate(manifest 校验+事件)/
  generate_image/status/reminder(复用离线代办 source=voice)；零新增绑定
- [x] **S4.3 语音通路**：setWhisperChatFn 闭包分流——命中即能力执行经 TTS
  播报（含打断），未命中透传聊天；voice 包零改动
- [x] **S4.4 前端**：events.ts INTENT_NAVIGATE（22→23）+ MainLayout 订阅 →
  navigateBoard 自动切空间
- [x] **验证**：Go 108/108；vitest 789/789（events 断言同步）；tsc/eslint 0；
  版本五处 4.5.0；gaea-v4.5.0.exe（35MB，SHA256 027c726d）+ 冒烟 200
- 遗留：能力面仅四类（导航/生图/状态/提醒）；生图结果无语音播报进度；
  LLM 兜底分类器未接（规则引擎对未覆盖意图一律走聊天）

### v4.6.0 双空间收尾·纵深补课（审计后第一轮收账）—— ✅ 已完成（v4.6.0）
- [x] **红线 ①记忆注入按空间收窄**：`boot/sysprompt.go` 系统提示词索引 +
  `controller_memory.go` refreshMemoryLocked 两个生产调用点传 `Options.Space`
  → InSpace 读端视图（work 只注入 work / play 只注入 play / mode=off 旧行为）；
  回归 TestRefreshMemorySpaceIsolation + TestBuildSystemPromptMemorySpaceScoped
- [x] **红线 ②任务分账生产启用**：`[tasks]` 配置段（max_concurrent/per_space/
  priority）→ startTaskScheduler 默认 {work=1, play=1} + 价格抓取优先
  （price_fetch=20/file_index=10）；显式 `per_space = {}` 关分账回退全局 sem；
  回归 TestTasksConfigTOML + TestTaskSchedulerOptionsDefaults
- [x] **红线 ③事件过滤推广**：onTaskEvent(cb, space?) 订阅层过滤 + TaskCenter/
  useRunningBadge/PriceSourcesPanel/WorkspaceSearchPanel 按 work + MainLayout
  subscribeForSpace；回归 onTaskEvent 空间过滤测试
- [x] **治理收尾**：keepAlive 裸轮询 8 处（TaskCenter/SubagentsPanel/
  FeatureModelBar/ProgrammingPage/BenchmarkSection/useStatsState/
  useImageGenQueue/useBridgeWatch）全接 usePollingGate；CSS 真硬编码 token 化
  （novel 阅读高亮/批注色板 --novel-read-*/--ann-*、chat-board 混白）
- [x] **纵深 Mood→TTS**：MoodToVoiceDescription 连续韵律 + WhisperChatFn 透传
  mood + 中性轮次心境主导；回归 TestMoodToVoiceDescription +
  TestManager_MoodDrivesNeutralTurnProsody
- [x] **纵深 Verifier 通道 B**：soffice→pdftoppm→纯 Go 像素差异率（页数联合
  判定 pass/warn/fail，渲染降级 warn），审计产物落 journal/verify/<id>；覆盖
  全部有基线的写盘工具；失败回 Plan（证据卡内联结论 + xlsx 重新规划按钮）；
  回归 TestPixelDiffRatio + TestRunVisualDiffVerdicts
- [x] **纵深 询价飞轮**：调差异常分级（正常/关注/异常）+ PredictNext 线性回归
  预测 + GaeaCostImportApply 变参 inquirySource → OCR 报价单幂等入询价库；
  回归 4 个新测试（含飞轮接线）
- [x] **验证**：Go 全量绿（无 FAIL）；vitest 791/791（144 文件）；tsc/eslint 0；
  绑定面不变（变参向后兼容）；版本统一 4.6.0
- 欠账（如实列示于 releases/v4.6.0.md）：规范包机制化 / 成本知识图谱+归因 /
  生命库可写化（评估=不盲写 Herdsman 库）/ Verifier 通道 A 引用级深化 /
  Mood 不进前端手动朗读（设计如此）

### v4.6.1 微信统一路由·规范包机制·归因对标（审计补课续刀）—— ✅ 已完成（v4.6.1）
- [x] **S4.5 微信接统一路由**：routeIntentWithResult（产物感知，routeIntent
  包装不变）+ 微信回调提醒之后先过统一路由（navigate/生图/状态/提醒全命中，
  未命中才走聊天）；iLink image_item/file_item 防御解析 + 非文本消息转模型
  提示行（发图即识别入口），未知空项宁漏勿误；回归 3 测试
- [x] **规范包机制化**：standard.Checker 注册表 + LintDocument 聚合；红头要素
  （既有）+ 造价工程表式（工程名称/编制依据/单位造价/人材机/合计/说明）双检查
  器；GaeaDocumentLint 切 LintDocument；OfficePanel 按规范包分组；回归 2 测试
- [x] **成本归因对标**：costref.ComputeAttribution 纯函数（P25/P75 带宽 + 中位
  基准，差幅等级/贡献金额/主因 TopDrivers/带宽退化 ±10% 兜底/无参考另计）；
  新绑定 GaeaCostAttribution（531，参考池排除本项目防自对标）+ FiveCalcPanel
  归因区；回归 3 测试
- [x] **验证**：Go 全量绿；vitest 791/791（144 文件）；tsc/eslint 0；绑定面 531、
  spaceBindings 248、drift PASS；版本统一 4.6.1
- 欠账（如实列示于 releases/v4.6.1.md）：iLink 文件卡片/字节级图片识别待真机
  收敛；成本知识图谱可视化形态；生命库可写化维持评估结论；微信通用能力触发
  依赖卡片协议

## v4.x 执行审计（2026-08-30）

- 全量「承诺 vs 代码」对照（三路探查，逐项到文件行号）已记录
  `docs/audit-2026-08-30-v4-execution-review.md`：阶段 0 地基五项与双空间内核
  骨架为真；红线缺口三条（记忆注入主链路跨空间未接线 / 任务空间分账未启用 /
  事件订阅过滤仅 1 处）+ 领域包纵深欠账表（Verifier 通道 B=页数对比、规范包
  =单 lint、询价无异常检测/预测、OCR→询价飞轮反向未接、成本图谱零实现、
  Mood 只存不用、生命库只读）+ 补课刀序（§E）。纪律修正：每刀验收加
  「纵深检查」，发布说明列欠账清单。

## 纪律（沿用）

- 每 Step 独立提交可回退；旧数据只读兼容；回退演练纳入验收；不做新板块、不堆功能；
  docs/ 过时文档一律归档到 `docs/archive/`（权威 = 长期规划 + AGENTS.md + 本文件）。


## 最新发布：v4.171.0（2026-09-09）「瘦身 P3 结构版2：office 抽核 + 次批巨文件拆分（>50KB 首拆池 9→0）」

- **接手会话收口**：工作树由前一会话（02:04–02:20）完成遗留未提交（office 抽核 + 次批拆分），本会话全量门禁核验+修 1 处 lint（ExportDialog react-refresh）+补齐发布流程。
- **线A office 抽核**：internal/office 顶层 8 文件（executor/job_manager/job_routing/session_mode/desktop_session/audit_log/types+测试）下沉新包 internal/core（fs/jobs/journal/modes/routing/sessionmode/types）；新 aliases.go 类型别名 ExecResult/AgentJobState 保绑定面生成签名（gen_bindings 产物受 TestBindingsCompleteness 保护，别名=同一类型）；app 层 office_handler/embed_check_test import 收口；archive.go 保留（whisper 事实归档不在范围）；**绑定面 602 零变更 drift PASS**。
- **线B 次批 5+1 拆**：KnowledgePanel 62.2→40.8（knowledge/ 8）/DeliverablesPanel 57.4→23.2（deliverables/ 4）/XlsxPreview 56.4→35.5（xlsxpreview/ 4）/ChapterPage 55.9→35.6（chapter/ 5）/herdsmanTemplates 55.7→1.6（data/templates/ 13）/SchedulePage 超额（schedule/ 3：CalendarEditor/ExportDialog/ProjectsManagePanel）；classNames/data-testid 逐字节照搬。
- **收口修复**：ExportDialog scoped warning×2（EXPORT_KIND_* 拆分前即局部 const 仅内用→去 export），eslint 0 error 0 warning 恢复。
- **坑=vitest 首跑 4 文件 31 例失败**（与 Go test-all 同机并发负载假红，复跑两次全绿 2737/2737=在册「并发负载 flaky 复跑清同族」先例）——发布门禁以复跑全绿为准，勿把首跑红当回归。
- **门禁**：Go 128/128 包 0 FAIL、vitest 2737（313 文件）、tsc/eslint 0、drift PASS@602（零绑定）、locale 0 死、build 34.7s+13.8s、冒烟 200、SHA256=834DCDEF35DDFCD049C7E9CB7E54FB3DB55EA04793B8055384770C42C2BCEB38。
- **欠账**：P3 版3 候选=bridge 双轨退役启动（wailsjsCompat 单 shim 仍被 57 文件引用渐进迁移）+ Go 侧 config.go 58.7/engine.go 55.2 + frontend store.ts 54.3 二次拆分 + entry/页面级懒加载；壳内真机池/审计刀D 不变。

