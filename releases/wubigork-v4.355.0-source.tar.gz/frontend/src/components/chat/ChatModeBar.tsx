// ChatPage 拆分产物：顶部模式切换条（行为零变化，T6-10.1）。
// variant='strip'：渲染进全局顶栏（v3-strip）时剥离横条外壳（背景/边框/内撑），
// 由宿主轨道条统一承担玻璃与分割线（T6-10.2 顶栏迁移）。
import React from 'react'
import { Button, Space, Tooltip, Popconfirm } from 'antd'
import {
  MessageOutlined, HeartOutlined, GlobalOutlined, SettingOutlined,
  SwapOutlined, SoundOutlined, DownloadOutlined, ClearOutlined,
} from '@ant-design/icons'
import { C } from '../../utils/theme'
import PersonaPicker from '../PersonaPicker'
import { EmotionSpeakSelector } from './EmotionSpeakSelector'

export interface ChatModeBarProps {
  /** 'panel'：聊天窗口上方的独立横条（默认）；'strip'：顶栏轨道条内嵌变体。 */
  variant?: 'panel' | 'strip'
  mode: string
  personaLabel: string
  currentPersonalityLabel?: string
  personaPickerActiveId: string
  searchEnabled: boolean
  onToggleSearch: () => void
  onNavigateLib: () => void
  onSwitchPlain: () => void
  onSwitchPersona: () => void
  onSwitchPersonality: (id: string) => void
  onOpenVoiceSettings: () => void
  /** v4.3d 朗读情绪：手动选择（'' = 跟随会话）；缺省不渲染选择器 */
  speakEmotion?: string
  sessionEmotion?: string
  onChangeSpeakEmotion?: (emotion: string) => void
  hasMessages: boolean
  onExport: () => void
  onClear: () => void
}

export const ChatModeBar: React.FC<ChatModeBarProps> = ({
  variant = 'panel', mode, personaLabel, currentPersonalityLabel, personaPickerActiveId, searchEnabled,
  onToggleSearch, onNavigateLib, onSwitchPlain, onSwitchPersona, onSwitchPersonality,
  onOpenVoiceSettings, speakEmotion, sessionEmotion, onChangeSpeakEmotion, hasMessages, onExport, onClear,
}) => (
  <div className={`chat-mode-bar${variant === 'strip' ? ' chat-mode-bar--strip' : ''}`}>
    <div className="chat-mode-seg" role="tablist" aria-label="对话模式">
      <button role="tab" aria-selected={mode === 'plain'} className={mode === 'plain' ? 'active' : ''}
        onClick={onSwitchPlain}>
        <MessageOutlined style={{ fontSize: 12 }} /> 普通对话
      </button>
      <button role="tab" aria-selected={mode !== 'plain'} className={mode !== 'plain' ? 'active' : ''}
        onClick={onSwitchPersona}>
        <HeartOutlined style={{ fontSize: 12 }} /> 角色 · {mode !== 'plain' ? personaLabel : (currentPersonalityLabel || '人格')}
      </button>
    </div>
    {variant !== 'strip' && <div className="chat-mode-bar-spacer" style={{ flex: 1 }} />}
    <Space size={2}>
      <Tooltip title={searchEnabled ? '联网搜索已开启（自动检测搜索意图）' : '联网搜索已关闭'}>
        <Button type="text" size="small" aria-label={searchEnabled ? '联网搜索已开启' : '联网搜索已关闭'} icon={<GlobalOutlined style={{ color: searchEnabled ? 'var(--md-sys-color-success)' : C('color-text-secondary') }} />}
          onClick={onToggleSearch} style={{ padding: '0 4px', height: 24, opacity: searchEnabled ? 1 : 0.5 }} />
      </Tooltip>
      {mode !== 'plain' && (
        <>
          <Tooltip title="角色库管理">
            <Button type="text" size="small" aria-label="角色库管理" icon={<SettingOutlined />} onClick={onNavigateLib}
              style={{ color: C('color-text-secondary'), height: 24 }} />
          </Tooltip>
          <PersonaPicker activeId={personaPickerActiveId}
            onSelect={onSwitchPersonality} onManage={onNavigateLib}>
            <Tooltip title="切换角色">
              <Button type="text" size="small" aria-label="切换角色" icon={<SwapOutlined />}
                style={{ color: C('color-text-secondary'), height: 24 }} />
            </Tooltip>
          </PersonaPicker>
          <Tooltip title="语音设置">
            <Button type="text" size="small" aria-label="语音设置" icon={<SoundOutlined />} onClick={onOpenVoiceSettings}
              style={{ color: C('color-text-secondary'), height: 24 }} />
          </Tooltip>
        </>
      )}
      {onChangeSpeakEmotion && (
        <EmotionSpeakSelector
          value={speakEmotion || ''}
          sessionEmotion={sessionEmotion || ''}
          onChange={onChangeSpeakEmotion}
        />
      )}
      {hasMessages && (
        <Tooltip title="导出为 Markdown">
          <Button type="text" size="small" icon={<DownloadOutlined />} onClick={onExport}
            style={{ color: C('color-text-secondary'), height: 24 }} />
        </Tooltip>
      )}
      <Tooltip title="清空当前对话">
        <Popconfirm title="确定清空当前对话？此操作不可恢复" onConfirm={onClear} okText="清空" cancelText="取消">
          <Button type="text" size="small" icon={<ClearOutlined />} disabled={!hasMessages}
            style={{ color: C('color-text-secondary'), height: 24, opacity: hasMessages ? 1 : 0.35 }} />
        </Popconfirm>
      </Tooltip>
    </Space>
  </div>
)
