import React, { memo } from 'react'
import ReactMarkdown from 'react-markdown'
import type { Components } from 'react-markdown'
import remarkGfm from 'remark-gfm'
import remarkMath from 'remark-math'
import rehypeKatex from 'rehype-katex'
import { C } from '../utils/theme'
import { ensureKatexCss, hasMathContent, normalizeMath } from '../gaea/lib/mathText'
import { genuiFenceStateKey, isGenuiFenceLang, GenuiMarkdownFence, extractFence } from '../genui/markdownFence'
import { useGenuiScope } from '../genui/scope'
import remarkDisableCodeIndented from './chat/remarkDisableCodeIndented'
import { ChatCodeBlock } from './ChatCodeBlock'
import { CopyableTable } from './CopyableTable'
import { markdownTextAlign } from '../gaea/lib/copyMarkdown'

/** ChatMarkdown — 聊天消息 Markdown 渲染（老栈 M3 令牌样式，供 ChatPage 使用）
 *  C 批蒸馏（docs/gaea-deepseek-chatdemo-distill-2026-11.md §2.4）：
 *  remarkDisableCodeIndented —— 前导空格列表不再被误判为代码块（LLM 输出防御）。 */
const ChatMarkdown: React.FC<{ text: string; genuiKey?: string }> = memo(function ChatMarkdown({ text, genuiKey }) {
  const genuiScope = useGenuiScope()
  const fenceKeyFor =
    genuiScope !== null && genuiKey !== undefined
      ? (body: string): string | undefined => genuiFenceStateKey(genuiScope, genuiKey, body)
      : undefined
  // v4.239 数学公式对齐：remark-math + rehype-katex（KaTeX CSS 由 mathText
  // ensureKatexCss 懒注入）；\(...\)/\[...\] 先归一成 $ 定界符。
  if (hasMathContent(text)) ensureKatexCss()
  return (
    <div style={{ fontSize: 14, lineHeight: 1.75, wordBreak: 'break-word' }}>
      <ReactMarkdown
        remarkPlugins={[remarkDisableCodeIndented, remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={chatMarkdownComponents(fenceKeyFor)}
      >
        {normalizeMath(text)}
      </ReactMarkdown>
    </div>
  )
})

function chatMarkdownComponents(fenceKeyFor: ((body: string) => string | undefined) | undefined): Components {
return {
  pre: ({ children }) => <>{children}</>,
  code: ({ className, children }) => {
    // FE6-05：language- 提取/去尾换行/块级判定走 extractFence 单源；本组件的
    // 分支语义与 genuiAdapter 并不同构（行内 code 显式令牌样式、块级无
    // data-genui-host 包裹、pre 恒解包），故只共用样板、保留自有分支。
    const { text, lang, isBlock } = extractFence(className, children)
    if (lang !== undefined && isGenuiFenceLang(lang) && isBlock) {
      return <GenuiMarkdownFence code={text} stateKey={fenceKeyFor?.(text)} />
    }
    if (isBlock) {
      // C3：mermaid 围栏走图表/源码双态（ChatMermaid 渐进容错）
      return <ChatCodeBlock language={lang} text={text} mermaid={lang === 'mermaid'} />
    }
    return (
      <code style={{
        padding: '1px 5px', borderRadius: 5,
        background: 'var(--md-sys-color-surface-variant)', color: C('color-text'),
        fontFamily: "'Cascadia Code', Consolas, monospace", fontSize: '0.9em',
        border: '1px solid var(--md-sys-color-outline-variant)',
      }}>{children}</code>
    )
  },
  a: ({ href, children }) => (
    <a href={href} target="_blank" rel="noreferrer" style={{ color: 'var(--gaea-glow, var(--md-sys-color-primary))', textDecoration: 'none' }}>
      {children}
    </a>
  ),
  table: ({ children }) => (
    <CopyableTable
      containerStyle={{
        margin: '10px 0',
        overflowX: 'auto',
        borderRadius: 10,
        border: '1px solid var(--md-sys-color-outline-variant)',
      }}
      tableStyle={{ minWidth: '100%', borderCollapse: 'collapse', fontSize: 13 }}
    >
      {children}
    </CopyableTable>
  ),
  th: ({ children, align }) => (
    <th align={align} style={{
      padding: '7px 12px', textAlign: markdownTextAlign(align) ?? 'left', fontSize: 11.5, fontWeight: 600,
      color: C('color-text-secondary'), background: 'var(--md-sys-color-surface-variant)',
      borderBottom: '1px solid var(--md-sys-color-outline-variant)',
    }}>{children}</th>
  ),
  td: ({ children, align }) => (
    <td align={align} style={{ padding: '7px 12px', textAlign: markdownTextAlign(align), borderBottom: '1px solid var(--md-sys-color-outline-variant)', color: C('color-text') }}>{children}</td>
  ),
  blockquote: ({ children }) => (
    <blockquote style={{
      margin: '8px 0', paddingLeft: 12, borderLeft: '3px solid var(--gaea-glow, var(--md-sys-color-primary))',
      color: C('color-text-secondary'), fontStyle: 'italic',
    }}>{children}</blockquote>
  ),
  hr: () => <hr style={{ margin: '14px 0', border: 'none', borderTop: '1px solid var(--md-sys-color-outline-variant)' }} />,
  ol: ({ children }) => <ol style={{ margin: '8px 0', paddingLeft: 22, listStyle: 'decimal' }}>{children}</ol>,
  ul: ({ children }) => <ul style={{ margin: '8px 0', paddingLeft: 22, listStyle: 'disc' }}>{children}</ul>,
  li: ({ children }) => <li style={{ margin: '3px 0' }}>{children}</li>,
  h1: ({ children }) => <h1 style={{ margin: '14px 0 8px', fontSize: 19, fontWeight: 700, color: C('color-text') }}>{children}</h1>,
  h2: ({ children }) => <h2 style={{ margin: '12px 0 7px', fontSize: 17, fontWeight: 700, color: C('color-text') }}>{children}</h2>,
  h3: ({ children }) => <h3 style={{ margin: '10px 0 6px', fontSize: 15, fontWeight: 600, color: C('color-text') }}>{children}</h3>,
  h4: ({ children }) => <h4 style={{ margin: '9px 0 5px', fontSize: 14, fontWeight: 600, color: C('color-text') }}>{children}</h4>,
  p: ({ children }) => <p style={{ margin: '6px 0' }}>{children}</p>,
  strong: ({ children }) => <strong style={{ fontWeight: 700 }}>{children}</strong>,
}
}

export default ChatMarkdown
