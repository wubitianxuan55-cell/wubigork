import React, { useState, useRef, useEffect } from 'react'
import { Input, Button, Space, Typography, Avatar, Tooltip, message } from 'antd'
import {
  SendOutlined,
  RobotOutlined,
  UserOutlined,
  RightOutlined,
  UpOutlined,
  CopyOutlined,
  CheckOutlined,
  ImportOutlined,
} from '@ant-design/icons'
import { C } from '../utils/theme'
import { copyToClipboard } from '../gaea/lib/clipboard'

export interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  streaming?: boolean
}

interface ChatPanelProps {
  title: string
  messages: Message[]
  onSend: (userMsg: string) => Promise<string | void>
  onMessagesChange?: (msgs: Message[]) => void
  streaming?: boolean
  placeholder?: string
  extra?: React.ReactNode
  defaultCollapsed?: boolean
  /** 外部触发的自动发送——设置后自动展开面板并发起对话 */
  autoSend?: string
  /** autoSend 完成后回调 */
  onAutoSendDone?: () => void
  /** 撑满父容器高度（忽略默认 280px） */
  fillHeight?: boolean
  /** 提供后将 AI 消息内容应用到外部（如设定编辑器），AI 气泡上会显示「应用到设定」按钮 */
  onApply?: (msg: Message) => void | Promise<void>
  /** 应用按钮文案，默认「应用到设定」 */
  applyLabel?: string
}

let msgId = 0
function nextId() {
  msgId++
  return `msg_${msgId}_${Date.now()}`
}

const ChatPanel: React.FC<ChatPanelProps> = ({
  title,
  messages,
  onSend,
  onMessagesChange,
  streaming = false,
  placeholder = '输入消息，Enter 发送 / Shift+Enter 换行',
  extra,
  defaultCollapsed = false,
  autoSend,
  onAutoSendDone,
  fillHeight = false,
  onApply,
  applyLabel = '应用到设定',
}) => {
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [streamText, setStreamText] = useState('')
  const [collapsed, setCollapsed] = useState(defaultCollapsed)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const listRef = useRef<HTMLDivElement>(null)
  const sendRef = useRef<(() => void) | undefined>(undefined)
  const inputRef = useRef<React.ComponentRef<typeof Input.TextArea>>(null)
  // T6-3.3 同口径（hooks/useChatStream.ts:49-50）：模拟打字循环取消标志——
  // 切话题/卸载即置 true 中止循环，新回合开始复位；不打字时恒 false。
  const typingCancelRef = useRef(false)
  // 本会话写入过的消息 id：父层把消息列表整体换成不含这些 id 的新列表 = 换了话题
  // （宿主 NovelSettingPage 在切书时 setMessages([])，组件不重挂载）。
  const ownedIdsRef = useRef<Set<string>>(new Set())

  // 卸载中止在途打字循环（旧循环不再 setStreamText / 不再覆盖外部消息）
  useEffect(() => () => { typingCancelRef.current = true }, [])

  // 切话题（父层整体替换消息列表）中止在途打字循环：口径同 useChatStream T6-3.3
  // 「切话题即中止模拟打字流」。判据用 id 归属而非数组引用，父层重建同内容数组不误判。
  useEffect(() => {
    const owned = ownedIdsRef.current
    if (owned.size === 0) return
    if (messages.some((m) => owned.has(m.id))) return
    typingCancelRef.current = true
  }, [messages])

  // 当监听到外部 autoSend → 展开面板 → 设输入 → 自动发送
  useEffect(() => {
    if (!autoSend) return
    setCollapsed(false)
    setInput(autoSend)
    const timer = setTimeout(() => {
      sendRef.current?.()
      onAutoSendDone?.()
    }, 100)
    return () => clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps -- onAutoSendDone 为可选 props 回调，父组件（NovelSettingPage）未以 useCallback 包裹传入，补依赖会在回调身份变化时重置发送定时器
  }, [autoSend])

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight
    }
  }, [messages, streamText])

  async function handleSendImpl() {
    const msg = input.trim()
    if (!msg || loading) return
    // 新回合：复位取消标志（旧循环已在切话题/卸载时中止；不复位则后续回合不打字）
    typingCancelRef.current = false
    setInput('')
    setLoading(true)

    const userMsg: Message = { id: nextId(), role: 'user', content: msg }
    const newMessages = [...messages, userMsg]
    ownedIdsRef.current.add(userMsg.id)
    onMessagesChange?.(newMessages)

    const aiMsg: Message = { id: nextId(), role: 'assistant', content: '', streaming: true }
    const withAi = [...newMessages, aiMsg]
    ownedIdsRef.current.add(aiMsg.id)

    try {
      onMessagesChange?.(withAi)

      const result = await onSend(msg)
      // 回合已被取消（卸载/切话题）：不进入打字流，也不再写任何状态
      if (typingCancelRef.current) return
      if (typeof result === 'string') {
        const text = result
        setStreamText('')
        // v4.365：12ms/字符≈83 次/秒 setState 且每步 O(n) slice——改 rAF 驱动，
        // 每帧推进 3 字符（视觉节奏几乎不变，setState 频率降 ~4 倍）。
        await new Promise<void>((resolve) => {
          let i = 0
          const tick = () => {
            // T6-3.3：切话题/卸载即中止模拟打字流（避免过期 setStreamText 持续写入）
            if (typingCancelRef.current) { resolve(); return }
            i = Math.min(text.length, i + 3)
            setStreamText(text.slice(0, i))
            if (i >= text.length) { resolve(); return }
            requestAnimationFrame(tick)
          }
          requestAnimationFrame(tick)
        })
        // 循环被取消（切话题/卸载）→ 不再更新消息与最终态，否则旧回合快照会
        // 覆盖切话题后父层刚重置的消息列表。
        if (typingCancelRef.current) return
        aiMsg.content = text
        aiMsg.streaming = false
        setStreamText('')
        onMessagesChange?.([...withAi])
      }
    } catch (err: unknown) {
      // 回合已取消：错误文案同样不得写进新会话
      if (typingCancelRef.current) return
      const last = withAi[withAi.length - 1]
      if (last && last.role === 'assistant') {
        last.content = `错误: ${err instanceof Error ? err.message : String(err)}`
        last.streaming = false
      }
      onMessagesChange?.([...withAi])
    } finally {
      setLoading(false)
    }
  }

  sendRef.current = handleSendImpl

  const handleSend = () => handleSendImpl()

  const handleCopy = async (content: string, id: string) => {
    // v4.513 收敛进剪贴板单源：成功才翻转复制态，双路失败可见提示。
    if (await copyToClipboard(content)) {
      setCopiedId(id)
      setTimeout(() => setCopiedId(null), 2000)
    } else {
      message.warning('复制失败：剪贴板不可用')
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const panelHeight = collapsed ? 'auto' : fillHeight ? '100%' : 280

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        height: panelHeight,
        minHeight: 0,
        flex: fillHeight ? 1 : undefined,
        borderRadius: collapsed ? 8 : 12,
        background: C('color-bg-container'),
        border: `1px solid ${C('color-border')}`,
        overflow: 'hidden',
        transition: 'border-radius 0.2s',
      }}
    >
      {/* 标题栏 */}
      <div
        onClick={() => { if (collapsed) setCollapsed(false) }}
        style={{
          padding: collapsed ? '8px 14px' : '10px 16px',
          borderBottom: collapsed ? 'none' : `1px solid ${C('color-border')}`,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          cursor: collapsed ? 'pointer' : 'default',
          background: collapsed ? C('color-bg-container') : C('color-bg-elevated'),
          transition: 'background 0.2s, padding 0.2s',
          userSelect: 'none',
        }}
      >
        <Space size={8}>
          {collapsed ? (
            <RightOutlined style={{ color: C('color-text-secondary'), fontSize: 10 }} />
          ) : null}
          <RobotOutlined style={{ color: C('color-primary'), fontSize: collapsed ? 16 : 18 }} />
          <Typography.Text
            strong
            style={{
              color: C('color-text'),
              fontSize: collapsed ? 13 : 14,
            }}
          >
            {title}
          </Typography.Text>
          {messages.length > 0 && !collapsed && (
            <Typography.Text
              style={{
                color: C('color-text-secondary'),
                fontSize: 11,
                marginLeft: 4,
              }}
            >
              {messages.length} 条消息
            </Typography.Text>
          )}
        </Space>
        <Space size={4}>
          {!collapsed && extra}
          {!collapsed && (
            <Tooltip title="收起面板" placement="left">
              <Button
                type="text"
                size="small"
                icon={<UpOutlined />}
                onClick={(e) => { e.stopPropagation(); setCollapsed(true) }}
                style={{ color: C('color-text-secondary'), fontSize: 10 }}
              />
            </Tooltip>
          )}
        </Space>
      </div>

      {!collapsed && (
        <>
          {/* 消息列表 */}
          <div
            ref={listRef}
            style={{
              flex: 1,
              overflow: 'auto',
              padding: '16px',
              background: C('color-bg-container'),
            }}
          >
            {messages.length === 0 && !streaming && (
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  height: '100%',
                  minHeight: 180,
                  textAlign: 'center',
                  padding: '24px 20px',
                }}
              >
                <div
                  style={{
                    width: 64,
                    height: 64,
                    borderRadius: 20,
                    background: `${C('color-primary')}12`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: 20,
                  }}
                >
                  <RobotOutlined style={{ fontSize: 32, color: C('color-primary') }} />
                </div>
                <Typography.Text
                  strong
                  style={{ color: C('color-text'), fontSize: 15, marginBottom: 8 }}
                >
                  开始对话
                </Typography.Text>
                <Typography.Text
                  style={{ color: C('color-text-secondary'), fontSize: 13, maxWidth: 280, lineHeight: 1.6 }}
                >
                  在下方输入消息，AI 将为你提供帮助。
                  <br />
                  支持写作辅助、角色设计、创意讨论等任务。
                </Typography.Text>
              </div>
            )}

            {messages.map((msg) => {
              const isUser = msg.role === 'user'
              return (
                <div
                  key={msg.id}
                  className="chat-message-item"
                  style={{
                    marginBottom: 20,
                    display: 'flex',
                    gap: 10,
                    flexDirection: isUser ? 'row-reverse' : 'row',
                    alignItems: 'flex-start',
                  }}
                >
                  <Avatar
                    size={34}
                    icon={isUser ? <UserOutlined /> : <RobotOutlined />}
                    style={{
                      background: isUser
                        ? `linear-gradient(135deg, ${C('color-primary')}, ${C('color-primary')}dd)`
                        : `linear-gradient(135deg, ${C('color-border')}, ${C('color-bg-elevated')})`,
                      flexShrink: 0,
                      boxShadow: isUser
                        ? `0 2px 8px ${C('color-primary')}33`
                        : '0 1px 4px rgba(0,0,0,0.06)',
                    }}
                  />
                  <div
                    style={{
                      flex: isUser ? undefined : 1,
                      maxWidth: '82%',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: isUser ? 'flex-end' : 'flex-start',
                    }}
                  >
                    {/* 发送者标签 */}
                    <Typography.Text
                      style={{
                        color: isUser ? C('color-primary') : C('color-text-secondary'),
                        fontSize: 11,
                        fontWeight: 500,
                        marginBottom: 4,
                        marginLeft: isUser ? 0 : 2,
                        marginRight: isUser ? 2 : 0,
                      }}
                    >
                      {isUser ? '你' : 'AI'}
                    </Typography.Text>

                    {/* 消息气泡 */}
                    <div
                      className="chat-bubble"
                      style={{
                        position: 'relative',
                        padding: '10px 14px',
                        borderRadius: isUser ? '16px 4px 16px 16px' : '4px 16px 16px 16px',
                        background: isUser
                          ? 'var(--md-sys-color-primary-container)'
                          : C('color-bg-elevated'),
                        color: isUser ? 'var(--md-sys-color-on-primary-container)' : C('color-text'),
                        whiteSpace: 'pre-wrap',
                        lineHeight: 1.65,
                        fontSize: 13.5,
                        wordBreak: 'break-word',
                        boxShadow: isUser
                          ? `0 2px 12px ${C('color-primary')}22`
                          : '0 1px 3px rgba(0,0,0,0.04)',
                        border: isUser ? 'none' : `1px solid ${C('color-border')}`,
                      }}
                    >
                      {msg.content}
                      {msg.streaming && <span className="cursor-blink" />}

                      {/* 复制按钮 — hover 显示 */}
                      {msg.content && !msg.streaming && (
                        <Tooltip title={copiedId === msg.id ? '已复制' : '复制'} placement="top">
                          <Button
                            type="text"
                            size="small"
                            className="chat-copy-btn"
                            icon={
                              copiedId === msg.id ? (
                                <CheckOutlined style={{ color: 'var(--md-sys-color-success)' }} />
                              ) : (
                                <CopyOutlined />
                              )
                            }
                            onClick={(e) => {
                              e.stopPropagation()
                              handleCopy(msg.content, msg.id)
                            }}
                            style={{
                              position: 'absolute',
                              top: 4,
                              right: onApply && !isUser ? 34 : 4,
                              opacity: 0,
                              color: isUser ? 'var(--md-sys-color-on-primary-container)' : C('color-text-secondary'),
                              transition: `opacity var(--md-sys-transition-fast)`,
                              background: isUser ? 'color-mix(in srgb, var(--md-sys-color-on-primary-container) 12%, transparent)' : 'rgba(0,0,0,0.04)',
                              borderRadius: 6,
                              width: 28,
                              height: 28,
                              padding: 0,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          />
                        </Tooltip>
                      )}

                      {/* 应用到设定按钮 — hover 显示（仅 AI 消息） */}
                      {!isUser && msg.content && !msg.streaming && onApply && (
                        <Tooltip title={applyLabel} placement="top">
                          <Button
                            type="text"
                            size="small"
                            className="chat-apply-btn"
                            icon={<ImportOutlined />}
                            aria-label={applyLabel}
                            onClick={(e) => {
                              e.stopPropagation()
                              void onApply(msg)
                            }}
                            style={{
                              position: 'absolute',
                              top: 4,
                              right: 4,
                              opacity: 0,
                              color: C('color-text-secondary'),
                              transition: `opacity var(--md-sys-transition-fast)`,
                              background: 'rgba(0,0,0,0.04)',
                              borderRadius: 6,
                              width: 28,
                              height: 28,
                              padding: 0,
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          />
                        </Tooltip>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}

            {/* 流式输出中的临时消息 */}
            {streaming && streamText && (
              <div
                style={{
                  marginBottom: 20,
                  display: 'flex',
                  gap: 10,
                  alignItems: 'flex-start',
                }}
              >
                <Avatar
                  size={34}
                  icon={<RobotOutlined />}
                  style={{
                    background: `linear-gradient(135deg, ${C('color-border')}, ${C('color-bg-elevated')})`,
                    flexShrink: 0,
                    boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
                  }}
                />
                <div style={{ flex: 1, maxWidth: '82%' }}>
                  <Typography.Text
                    style={{ color: C('color-text-secondary'), fontSize: 11, fontWeight: 500, marginBottom: 4, display: 'block', marginLeft: 2 }}
                  >
                    AI
                  </Typography.Text>
                  <div
                    style={{
                      padding: '10px 14px',
                      borderRadius: '4px 16px 16px 16px',
                      background: C('color-bg-elevated'),
                      border: `1px solid ${C('color-border')}`,
                      color: C('color-text'),
                      whiteSpace: 'pre-wrap',
                      lineHeight: 1.65,
                      fontSize: 13.5,
                      wordBreak: 'break-word',
                      boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
                    }}
                  >
                    {streamText}
                    <span className="cursor-blink" />
                  </div>
                </div>
              </div>
            )}

            {/* 加载中状态（发送中但还没开始流式输出） */}
            {loading && !streamText && messages.length > 0 && messages[messages.length - 1].role === 'user' && (
              <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: 20 }}>
                <Avatar
                  size={34}
                  icon={<RobotOutlined />}
                  style={{
                    background: `linear-gradient(135deg, ${C('color-border')}, ${C('color-bg-elevated')})`,
                    flexShrink: 0,
                  }}
                />
                <div
                  style={{
                    padding: '12px 18px',
                    borderRadius: '4px 16px 16px 16px',
                    background: C('color-bg-elevated'),
                    border: `1px solid ${C('color-border')}`,
                  }}
                >
                  <span className="typing-dots">
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                    <span className="typing-dot" />
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* 输入框 — 悬浮居中 */}
          <div
            style={{
              padding: '16px 0 20px',
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <div
              style={{
                width: '100%',
                maxWidth: 720,
                display: 'flex',
                alignItems: 'flex-end',
                gap: 8,
                padding: '8px 10px',
                background: C('color-bg-container'),
                border: `1px solid ${C('color-border')}`,
                borderRadius: 16,
                boxShadow: `0 4px 24px rgba(0,0,0,0.06), 0 1px 4px rgba(0,0,0,0.04)`,
                transition: 'box-shadow 0.2s',
              }}
            >
              <Input.TextArea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={placeholder}
                disabled={loading}
                autoSize={{ minRows: 1, maxRows: 5 }}
                className="chat-input-textarea"
                style={{
                  flex: 1,
                  background: 'transparent',
                  border: 'none',
                  color: C('color-text'),
                  borderRadius: 0,
                  resize: 'none',
                  fontSize: 14,
                  lineHeight: 1.6,
                  padding: '6px 4px',
                  boxShadow: 'none',
                }}
              />
              <Button
                type="primary"
                icon={<SendOutlined />}
                onClick={handleSend}
                loading={loading}
                disabled={!input.trim() && !loading}
                style={{
                  background: input.trim() ? C('color-primary') : C('color-border'),
                  borderColor: 'transparent',
                  borderRadius: 12,
                  width: 38,
                  height: 38,
                  minWidth: 38,
                  padding: 0,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: input.trim()
                    ? `0 2px 8px ${C('color-primary')}44`
                    : 'none',
                  transition: 'all 0.2s',
                  flexShrink: 0,
                }}
              />
            </div>
          </div>
        </>
      )}
    </div>
  )
}

export default ChatPanel
