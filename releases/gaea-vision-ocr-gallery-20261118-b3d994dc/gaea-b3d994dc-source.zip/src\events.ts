/**
 * events.ts — 事件名常量表 + subscribe() 统一封装（3.0 01 报告 §4）
 *
 * 后端事件 28 个（window.runtime.EventsOn 全量订阅点，§4.1）+ 前端自定义事件 4 个（§4.2）。
 * subscribe() 收敛"规范路径（wailsjs runtime 返回卸载函数）"与"手动路径（window.runtime 裸调）"
 * 两套并存（§4.3），统一返回 () => void 卸载函数。
 */

// ─── 后端事件（§4.1，27 个）────────────────────────────────────────────
export const BACKEND_EVENTS = {
  /** 顶栏模型标签刷新（MainLayout） */
  MODEL_CHANGED: 'model-changed',
  /** 功能模型变更（useFeatureModel，按 d.feature 过滤） */
  FEATURE_MODEL_CHANGED: 'feature-model-changed',
  /** 聊天流动态频道前缀：实际事件名为 `chat-stream:${runID}`（useChatStream） */
  CHAT_STREAM: 'chat-stream',
  // 章节生成流/书源导入进度/幽灵补写/AI 控制台四通道随小说板块退役拆除（2026-11-15）
  /** TTS 语音流（TTSPlayer） */
  TTS_STREAM: 'tts-stream',
  /** 新角色发现（NewCharactersModal） */
  NEW_CHARACTERS_DISCOVERED: 'new-characters-discovered',
  /** 角色批量填充进度（CharacterLibraryPage） */
  CHARACTER_FILL_PROGRESS: 'character-fill-progress',
  /** 知识库导入逐页 OCR 进度（KnowledgeImportModal；uocr2 后扫描件导入分钟级/页） */
  KNOWLEDGE_IMPORT_PROGRESS: 'knowledge-import-progress',
  /** 语音状态（useVoiceChat） */
  VOICE_STATE: 'voice:state',
  /** 语音识别文本 */
  VOICE_TRANSCRIPT: 'voice:transcript',
  /** 语音回复文本 */
  VOICE_REPLY: 'voice:reply',
  /** 语音回复流式增量（首句生成中即更新界面） */
  VOICE_REPLY_DELTA: 'voice:reply-delta',
  /** 语音 TTS 音频 */
  VOICE_TTS_AUDIO: 'voice:tts-audio',
  /** 语音 TTS 朗读文本 */
  VOICE_TTS_SPEAK_TEXT: 'voice:tts-speak-text',
  /** 语音 TTS 朗读取消 */
  VOICE_TTS_SPEAK_CANCEL: 'voice:tts-speak-cancel',
  /** 语音聆听状态 */
  VOICE_LISTENING: 'voice:listening',
  /** 语音思考状态 */
  VOICE_THINKING: 'voice:thinking',
  /** gaea 桥接主事件（bridge.ts onEvent） */
  GAEA_EVENT: 'gaea-event',
  /** 更新进度（bridge.ts onUpdaterProgress） */
  UPDATER_PROGRESS: 'updater:progress',
  /** 任务事件（bridge.ts onTaskEvent） */
  GAEA_TASK: 'gaea-task',
  /** 轻语主动关心定时推送（v4.3c 后续小步：payload 含 personalityID/messageType/promptHint/space） */
  WHISPER_PROACTIVE: 'gaea-whisper-proactive',
  /** 指令中枢导航（v4.5：语音等入口的意图命中 → navigateBoard 自动切空间） */
  INTENT_NAVIGATE: 'gaea-intent-navigate',
  /** M5 刀二：模型工具 T1 预览凭据下发（语音台出确认卡；payload=previewId/intentHash/action/reply） */
  VOICE_TOOL_PREVIEW: 'gaea-voice-tool-preview',
  /** 桥接就绪（bridge.ts onReady） */
  GAEA_READY: 'gaea-ready',
} as const

// ─── 前端自定义事件（§4.2，dispatchEvent 非 runtime）───────────────
export const FRONTEND_EVENTS = {
  /** 跨页面导航（chat/utils.ts / CharacterPage / ModelPanel → MainLayout 白名单校验） */
  NAVIGATE: 'navigate',
  /** 轻语人格变更（CharacterLibraryPage 内） */
  GAEA_PERSONA_CHANGED: 'gaea-persona-changed',
  /** 项目角色变更（CharacterLibraryPage / NewCharactersModal） */
  GAEA_PROJECT_CHARS_CHANGED: 'gaea-project-chars-changed',
  /** AI 辅助发送（ChapterEditor 内部） */
  AI_ASSIST_SEND: 'ai-assist-send',
  /** 打开模型中心「详细统计」抽屉（运行监测「按模型明细」跨板跳转联动，
      已挂载场景；未挂载首次跳转走 OPEN_STATS_FLAG 补开） */
  OPEN_STATS_DRAWER: 'gaea-open-stats-drawer',
  /** 打开办公右栏工具 Tab（CAD 图纸/进度计划；payload { tool: 'cad' | 'schedule' }；
      发射方=交付卡/工具卡等深处组件，消费方=办公 App 根 openToolTab） */
  OPEN_TOOL: 'gaea-open-tool',
  /** 打开任务收件箱面板（命令面板空态入口；消费方=MainLayout 的常驻
      TaskInboxHost，首页删除后仍无条件可开） */
  OPEN_TASK_INBOX: 'gaea-open-task-inbox',
} as const

/** 「按模型明细」跳转的抽屉补开标记（sessionStorage；模型中心挂载效应消费即清） */
export const OPEN_STATS_FLAG = 'gaea.stats-drawer-open'

/** 首页工具 tile 打开右栏工具 Tab 的冷启补开标记（sessionStorage；值为工具名
 *  'cad' | 'schedule'。办公 App 常驻挂载前事件无人听 → 首次懒加载挂载效应
 *  消费即清；已挂载场景由 OPEN_TOOL 监听顺带清除，杜绝标记残留） */
export const OPEN_TOOL_FLAG = 'gaea.tool-open'

export type FrontendEventName = (typeof FRONTEND_EVENTS)[keyof typeof FRONTEND_EVENTS]

/** 聊天流动态频道：chat-stream:<runID> */
export function chatStreamChannel(runID: string): string {
  return `${BACKEND_EVENTS.CHAT_STREAM}:${runID}`
}

/**
 * 统一事件订阅：优先 wailsjs runtime（返回卸载函数），退化为 window.runtime 裸调
 * （EventsOn 返回 void，用 EventsOff 卸载）。事件通道缺失时返回 noop，不抛错。
 */
export function subscribe(event: string, handler: (data: unknown) => void): () => void {
  const rt = window.runtime
  if (!rt?.EventsOn) return () => {}
  try {
    const unsub = rt.EventsOn(event, handler) as (() => void) | void
    if (typeof unsub === 'function') return unsub
    return () => {
      try { rt.EventsOff?.(event, handler) } catch { /* 清理失败无害 */ }
    }
  } catch {
    return () => {}
  }
}

/**
 * S2.1 双空间壳：按空间过滤的事件订阅（docs/gaea-space-shell-design.md §4.7）。
 * 事件 payload 带 `spaceId`（任务事件，后端 Task.Space `json:"spaceId"`）或
 * `space` 字段时，与当前壳层空间不匹配的事件直接丢弃；payload 无空间字段
 * = 全局事件（模型切换/桥接就绪等），一律放行。
 */
export function subscribeForSpace(
  event: string,
  handler: (data: unknown) => void,
  space?: string,
): () => void {
  if (!space) return subscribe(event, handler)
  return subscribe(event, (data) => {
    const payload = data as { spaceId?: unknown; space?: unknown } | null
    const evSpace = payload?.spaceId ?? payload?.space
    if (typeof evSpace === 'string' && evSpace !== space) return
    handler(data)
  })
}

/** 分发前端自定义事件（§4.2 的 dispatchEvent 统一封装） */
export function emitFrontendEvent(name: FrontendEventName, detail?: unknown): void {
  window.dispatchEvent(new CustomEvent(name, { detail }))
}
