import React, { useMemo, useState, useRef, useEffect, useCallback } from 'react'
import {
  forceSimulation, forceLink, forceManyBody, forceCenter, forceCollide,
} from 'd3-force'
import { ROLE_LABELS, RELATION_LABELS, resolveThemeColor } from '../utils/theme'
import { useAppStore } from '../stores/appStore'
import {
  buildGraphData, EDGE_CATEGORY_LABEL,
  type GraphNode, type GraphEdge, type EdgeCategory,
  type GraphCharacter, type GraphOrganization,
} from './RelationGraph/graphData'

interface RelationGraphProps {
  characters: GraphCharacter[]
  organizations: GraphOrganization[]
  relationships: { from_id: string; to_id: string; relation_type: string }[]
}

// 分类可见性默认全开（§7.5 分类筛选）
const ALL_CATEGORIES: EdgeCategory[] = ['organization', 'career_group', 'career_main', 'career_sub', 'interpersonal']

// ── 颜色令牌表（canvas 不解析 var()，经 resolveThemeColor 探针解析为具体色；
//    解析在组件内随 darkMode memo——v4.390 前此处是模块级求值，模块加载后
//    主题切换永不重解析，角色色/关系色/画布底停留在旧主题） ──
const roleColorTokens: Record<string, string> = {
  protagonist: 'var(--color-warning)', antagonist: 'var(--color-destructive)',
  supporting: 'var(--color-primary)', minor: 'var(--color-text-secondary)',
}
const orgColorToken = 'var(--gaea-glow)'
const relColorTokens: Record<string, string> = {
  friend: 'var(--color-success)', enemy: 'var(--color-destructive)',
  family: 'var(--color-primary)', mentor: 'color-mix(in srgb, var(--color-primary) 55%, var(--color-text))',
  rival: 'var(--color-warning)', lover: 'color-mix(in srgb, var(--color-destructive) 45%, var(--color-primary))',
  member: 'var(--color-text-secondary)', leader: 'var(--gaea-glow)',
}
const roleCN = ROLE_LABELS
const relCN = RELATION_LABELS
const BG_SPEC = 'color-mix(in srgb, var(--color-surface, #0f0f0f) 92%, #000)'

// ── d3-force 二维仿真 ──
function runSimulation(
  graphNodes: GraphNode[], edges: GraphEdge[],
): Map<string, { x: number; y: number }> {
  const N = graphNodes.length
  if (N === 0) return new Map()
  const linkDist = Math.min(200, 80 + 30 * Math.log10(N + 1))
  const repel = -Math.min(3000, 500 + 200 * Math.log10(N + 1))
  const jitter = () => (Math.random() - 0.5) * 2
  interface SimNode { id: string; x: number; y: number }
  interface SimLink { source: string; target: string; strength?: number }
  const nodes: SimNode[] = graphNodes.map((n) => ({ id: n.id, x: jitter(), y: jitter() }))
  const links: SimLink[] = edges.map((e) => ({ source: e.from, target: e.to, strength: e.strength }))

  const sim = forceSimulation<SimNode>(nodes)
    .force('link', forceLink<SimNode, SimLink>(links).id((d) => d.id).distance(linkDist)
      // §7.5 布局权重：每边自带 strength（组织 0.5 > 分组 0.35 > 主职 0.3 >
      // 副职 0.2 > 人际 0.02）——高权边先稳定层级，人际边只渲染基本不布局。
      .strength((l) => l.strength ?? 0.3))
    .force('charge', forceManyBody().strength(repel).distanceMax(linkDist * 3))
    .force('center', forceCenter(0, 0))
    .force('collide', forceCollide(30))
    .stop()

  sim.tick(300)
  const result = new Map<string, { x: number; y: number }>()
  for (const n of nodes) result.set(n.id, { x: n.x, y: n.y })
  return result
}

// ── 主组件 ──
const RelationGraph: React.FC<RelationGraphProps> = ({
  characters, organizations, relationships,
}) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [size, setSize] = useState({ w: 700, h: 500 })
  const [hovered, setHovered] = useState<string | null>(null)
  const [selected, setSelected] = useState<string | null>(null)
  const [visible, setVisible] = useState<Record<EdgeCategory, boolean>>({
    organization: true, career_group: true, career_main: true, career_sub: true, interpersonal: true,
  })
  const [scale, setScale] = useState(1)
  const [offset, setOffset] = useState({ x: 0, y: 0 })
  // canvas 主题色（v4.350 首修标签/淡化层；v4.390 收口全量调色板进组件 memo——
  // 此前角色/组织/关系/背景色是模块级求值，主题切换后停留在旧主题）。
  const darkMode = useAppStore((s) => s.darkMode)
  const palette = useMemo(() => ({
    roleColors: Object.fromEntries(
      Object.entries(roleColorTokens).map(([k, v]) => [k, resolveThemeColor(v)]),
    ) as Record<string, string>,
    orgColor: resolveThemeColor(orgColorToken),
    relColors: Object.fromEntries(
      Object.entries(relColorTokens).map(([k, v]) => [k, resolveThemeColor(v)]),
    ) as Record<string, string>,
    bg: resolveThemeColor(BG_SPEC),
    careerMain: resolveThemeColor('var(--color-primary)'),
    careerSub: resolveThemeColor('var(--color-warning)'),
    group: resolveThemeColor('var(--color-text-tertiary)'),
    labelBright: resolveThemeColor('var(--color-text)'),
    labelDim: resolveThemeColor('var(--color-text-secondary)'),
    edgeDim: resolveThemeColor('var(--color-border)'),
    nodeDim: resolveThemeColor('var(--color-text-secondary)'),
    // darkMode 仅作变更触发器：令牌值随主题写入 :root，需按明暗重新解析
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [darkMode])
  const dragRef = useRef({ dragging: false, startX: 0, startY: 0, ox: 0, oy: 0, panning: false })

  // ResizeObserver
  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    const ro = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect
      if (width > 0 && height > 0) setSize({ w: width, h: height })
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  // 节点/边构建（graphData 纯函数：三类节点+四层边，§7.5；palette 入 deps 使主题切换重建）
  const { nodes: graphNodes, edges: allEdges } = useMemo(() => buildGraphData(
    characters, organizations, relationships,
    { careerMain: palette.careerMain, careerSub: palette.careerSub, group: palette.group },
  ), [characters, organizations, relationships, palette])

  // 角色节点着色沿用定位色；组织节点沿用组织色
  const decoratedNodes = useMemo(() => graphNodes.map((n) => {
    if (n.kind === 'character') return { ...n, color: palette.roleColors[n.role_type || ''] || '#6b7280' }
    if (n.kind === 'organization') return { ...n, color: palette.orgColor }
    return n
  }), [graphNodes, palette])

  const edges: (GraphEdge & { color: string })[] = useMemo(() => allEdges
    .map((e) => ({
      ...e,
      color: e.category === 'interpersonal'
        ? (palette.relColors[e.label] || '#6b7280')
        : e.category === 'organization' ? palette.orgColor
        : e.category === 'career_main' ? palette.careerMain
        : e.category === 'career_sub' ? palette.careerSub
        : palette.group,
      label: e.category === 'interpersonal' ? (relCN[e.label] || e.label) : e.label,
    }))
    .filter((e) => visible[e.category]),
  [allEdges, visible, palette])

  const visibleNodes = useMemo(() => {
    const live = new Set<string>()
    for (const e of edges) { live.add(e.from); live.add(e.to) }
    // 无任何可见边的节点仍展示（孤立角色/组织），人际类节点全保留
    return decoratedNodes.filter((n) =>
      n.kind === 'character' || n.kind === 'organization' || live.has(n.id) ||
      (n.kind === 'career' && decoratedNodes.some((m) => m.kind === 'career' && m.id === n.id)) || live.has(n.id))
  }, [decoratedNodes, edges])

  // 力导向布局（仅可见边参与）
  const positions = useMemo(() => runSimulation(visibleNodes, edges), [visibleNodes, edges])

  // 悬停关联节点集
  const relatedOf = (id: string | null, list: GraphEdge[]) => {
    const related = new Set<string>()
    if (!id) return related
    related.add(id)
    for (const e of list) {
      if (e.from === id) related.add(e.to)
      if (e.to === id) related.add(e.from)
    }
    return related
  }
  const hoverRelated = useMemo(() => relatedOf(hovered, edges), [hovered, edges])
  const selectRelated = useMemo(() => relatedOf(selected, edges), [selected, edges])

  const allNodes = visibleNodes
  const nodeById = useMemo(() => new Map(allNodes.map((n) => [n.id, n])), [allNodes])
  const nodeRadiusScale = 8 + 2 * Math.log10(allNodes.length + 1)

  // 检测鼠标下的节点（基于前一帧的变换）
  // 节点半径按种类：组织 > 角色/职业分组 > 职业
  const nodeRadiusFor = useCallback((n: GraphNode) => {
    if (n.kind === 'organization') return nodeRadiusScale * 1.6
    if (n.kind === 'career') return nodeRadiusScale * 0.85
    if (n.kind === 'career_group') return nodeRadiusScale * 0.7
    return nodeRadiusScale
  }, [nodeRadiusScale])
  const hitTest = useCallback((mx: number, my: number): string | null => {
    const px = (mx - size.w / 2 - offset.x) / scale
    const py = (my - size.h / 2 - offset.y) / scale
    let closest: string | null = null
    let closestDist = 40
    for (const n of allNodes) {
      const p = positions.get(n.id)
      if (!p) continue
      const dx = p.x - px, dy = p.y - py
      const d = Math.sqrt(dx * dx + dy * dy)
      const r = nodeRadiusFor(n)
      if (d < r + 6 && d < closestDist) {
        closest = n.id
        closestDist = d
      }
    }
    return closest
  }, [allNodes, positions, size, offset, scale, nodeRadiusFor])



  // Canvas 渲染循环
  const rafRef = useRef<number>(0)
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const render = () => {
      // v4.365 后台空转治理：隐藏(keepAlive display:none/最小化)时挂起绘制
      if (document.hidden || !canvas || canvas.offsetParent === null) {
        rafRef.current = requestAnimationFrame(render)
        return
      }
      const { w, h } = size
      canvas!.width = w
      canvas!.height = h
      ctx!.clearRect(0, 0, w, h)

      // 背景
      ctx!.fillStyle = palette.bg
      ctx!.fillRect(0, 0, w, h)

      ctx!.save()
      ctx!.translate(w / 2 + offset.x, h / 2 + offset.y)
      ctx!.scale(scale, scale)

      // ── 连线（虚线种类：组织成员/职业分组/副职，§7.5 边样式）──
      for (const e of edges) {
        const from = positions.get(e.from), to = positions.get(e.to)
        if (!from || !to) continue
        const dim = hovered !== null && !(e.from === hovered || e.to === hovered)
        ctx!.beginPath()
        const mx = (from.x + to.x) / 2
        const my = (from.y + to.y) / 2 - 10
        ctx!.moveTo(from.x, from.y)
        ctx!.quadraticCurveTo(mx, my, to.x, to.y)
        ctx!.setLineDash(e.dashed ? [6, 3] : [])
        const structural = e.category !== 'interpersonal'
        ctx!.strokeStyle = dim ? palette.edgeDim : e.color
        ctx!.lineWidth = dim ? 0.5 : structural ? 1.2 : 1.5
        ctx!.globalAlpha = dim ? 0.15 : structural ? 0.55 : 0.7
        ctx!.stroke()
        ctx!.setLineDash([])

        // 中点标签
        if (!dim) {
          ctx!.fillStyle = e.color
          ctx!.font = '10px sans-serif'
          ctx!.textAlign = 'center'
          ctx!.textBaseline = 'bottom'
          ctx!.fillText(e.label, mx, my - 4)
        }
        ctx!.globalAlpha = 1
      }

      // ── 节点（角色/组织圆形；职业方形；分组小圆虚描边）──
      for (const n of allNodes) {
        const p = positions.get(n.id)
        if (!p) continue
        const r = nodeRadiusFor(n)
        const dim = hovered !== null && !hoverRelated.has(n.id)
        const color = dim ? palette.nodeDim : n.color || '#6b7280'
        const alpha = dim ? 0.3 : 1

        const isCareer = n.kind === 'career'
        const isGroup = n.kind === 'career_group'
        const selectedGlow = selected === n.id || (selected !== null && (selectRelated.has(n.id)))

        // 发光效果（结构类弱化；选中节点用描边强调）
        if (!dim && !isGroup) {
          const glow = ctx!.createRadialGradient(p.x, p.y, 0, p.x, p.y, r * 3)
          glow.addColorStop(0, hexOrColor(n.color) + '44')
          glow.addColorStop(1, 'transparent')
          ctx!.fillStyle = glow
          ctx!.beginPath()
          ctx!.arc(p.x, p.y, r * 3, 0, Math.PI * 2)
          ctx!.fill()
        }

        ctx!.globalAlpha = alpha
        if (isCareer) {
          // 职业：圆角方形（区别于角色/组织圆形）
          const grad = ctx!.createLinearGradient(p.x - r, p.y - r, p.x + r, p.y + r)
          grad.addColorStop(0, lighten(color, 30))
          grad.addColorStop(1, color)
          ctx!.fillStyle = grad
          ctx!.beginPath()
          ctx!.roundRect(p.x - r, p.y - r, r * 2, r * 2, r * 0.35)
          ctx!.fill()
          ctx!.strokeStyle = color
          ctx!.lineWidth = selectedGlow ? 3 : 1.2
          ctx!.stroke()
        } else if (isGroup) {
          // 分组：小空心圆
          ctx!.strokeStyle = color
          ctx!.setLineDash([3, 2])
          ctx!.lineWidth = 1.2
          ctx!.beginPath()
          ctx!.arc(p.x, p.y, r, 0, Math.PI * 2)
          ctx!.stroke()
          ctx!.setLineDash([])
        } else {
          const grad = ctx!.createRadialGradient(p.x - r * 0.3, p.y - r * 0.3, 0, p.x, p.y, r)
          grad.addColorStop(0, lighten(color, 30))
          grad.addColorStop(1, color)
          ctx!.fillStyle = grad
          ctx!.beginPath()
          ctx!.arc(p.x, p.y, r, 0, Math.PI * 2)
          ctx!.fill()
          ctx!.strokeStyle = color
          ctx!.lineWidth = selectedGlow ? 3 : 1.5
          ctx!.beginPath()
          ctx!.arc(p.x, p.y, r, 0, Math.PI * 2)
          ctx!.stroke()
        }
        ctx!.globalAlpha = 1

        // 名称标签
        ctx!.fillStyle = dim ? palette.labelDim : palette.labelBright
        ctx!.font = `${10 + Math.min(2, Math.log10(allNodes.length + 1))}px sans-serif`
        ctx!.textAlign = 'center'
        ctx!.textBaseline = 'top'
        const label = n.name.length > 6 ? n.name.slice(0, 5) + '…' : n.name
        ctx!.fillText(label, p.x, p.y + r + 3)
      }

      ctx!.restore()
      rafRef.current = requestAnimationFrame(render)
    }

    rafRef.current = requestAnimationFrame(render)
    return () => cancelAnimationFrame(rafRef.current)
  }, [size, positions, edges, allNodes, hovered, hoverRelated, selected, selectRelated, scale, offset, nodeRadiusFor, palette])

  // ── 交互事件 ──
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? 0.9 : 1.1
    setScale((s) => Math.max(0.1, Math.min(5, s * delta)))
  }, [])

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect()
    if (!rect) return
    const mx = e.clientX - rect.left, my = e.clientY - rect.top
    const hit = hitTest(mx, my)
    if (hit) {
      // 点击节点：选中（详情浮层），不拖拽；再点同节点取消
      dragRef.current.dragging = false
      setSelected((s) => (s === hit ? null : hit))
      return
    }
    if (selected !== null) setSelected(null)
    dragRef.current = {
      dragging: true, startX: e.clientX, startY: e.clientY,
      ox: offset.x, oy: offset.y, panning: false,
    }
  }, [offset, hitTest, selected])

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const rect = canvasRef.current?.getBoundingClientRect()
    if (!rect) return
    const mx = e.clientX - rect.left, my = e.clientY - rect.top

    if (dragRef.current.dragging) {
      const dx = e.clientX - dragRef.current.startX
      const dy = e.clientY - dragRef.current.startY
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
        dragRef.current.panning = true
      }
      if (dragRef.current.panning) {
        setOffset({ x: dragRef.current.ox + dx, y: dragRef.current.oy + dy })
      }
      return
    }

    // 悬停检测
    const hit = hitTest(mx, my)
    setHovered(hit)
  }, [hitTest])

  const handleMouseUp = useCallback(() => {
    dragRef.current.dragging = false
  }, [])

  const handleMouseLeave = useCallback(() => {
    setHovered(null)
    dragRef.current.dragging = false
  }, [])

  const handleReset = useCallback(() => {
    setScale(1)
    setOffset({ x: 0, y: 0 })
  }, [])

  const selectedNode = selected ? nodeById.get(selected) : undefined

  if (characters.length === 0 && organizations.length === 0) {
    return (
      <div style={{ width: '100%', height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--color-text-secondary)', fontSize: 13 }}>
        无数据
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      style={{ width: '100%', height: '100%', position: 'relative', borderRadius: 8, overflow: 'hidden', background: palette.bg }}
    >
      <canvas
        ref={canvasRef}
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        style={{ display: 'block', cursor: hovered ? 'pointer' : 'grab' }}
      />
      {/* 分类筛选（§7.5 分类筛选） */}
      <div style={{
        position: 'absolute', top: 30, left: 12,
        display: 'flex', flexDirection: 'column', gap: 2,
        background: 'var(--color-surface-container)', border: '1px solid var(--color-border)',
        borderRadius: 6, padding: '6px 10px', fontSize: 10.5,
      }}>
        {ALL_CATEGORIES.map((cat) => (
          <label key={cat} style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', color: 'var(--color-text-secondary)', userSelect: 'none' }}>
            <input
              type="checkbox"
              checked={visible[cat]}
              onChange={() => setVisible((v) => ({ ...v, [cat]: !v[cat] }))}
              style={{ accentColor: 'var(--color-primary)', width: 12, height: 12 }}
            />
            {EDGE_CATEGORY_LABEL[cat]}
          </label>
        ))}
      </div>

      {/* 节点详情浮层（点击选中，再点空白或同节点关闭） */}
      {selectedNode && (
        <div style={{
          position: 'absolute', bottom: 12, left: 12,
          background: 'var(--color-surface-container-high)', border: '1px solid var(--color-border)',
          borderRadius: 8, padding: '10px 12px', fontSize: 11.5, maxWidth: 260,
          color: 'var(--color-text)', boxShadow: '0 4px 16px rgba(0,0,0,0.35)',
        }}>
          <div style={{ fontWeight: 600, marginBottom: 4, display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 8, height: 8, borderRadius: selectedNode.kind === 'career' ? 1 : '50%', background: selectedNode.color || '#6b7280', display: 'inline-block' }} />
            {selectedNode.name}
          </div>
          {selectedNode.kind === 'character' && (
            <div style={{ color: 'var(--color-text-secondary)', lineHeight: '18px' }}>
              <div>定位：{roleCN[selectedNode.role_type || ''] || selectedNode.role_type || '未设'}</div>
              {selectedNode.main_career_id
                ? <div>主职业：{selectedNode.main_career_id}·{selectedNode.main_career_stage || 1}阶</div>
                : <div>主职业：未设</div>}
              {(selectedNode.sub_careers || []).length > 0 && (
                <div>副职业：{selectedNode.sub_careers!.map((s) => `${s.career_name || s.career_id}·${s.stage}阶`).join('、')}</div>
              )}
            </div>
          )}
          {selectedNode.kind === 'career' && (
            <div style={{ color: 'var(--color-text-secondary)' }}>
              {selectedNode.holders && selectedNode.holders.length > 0
                ? <div>持有：{selectedNode.holders.join('、')}{selectedNode.stage ? `（最高 ${selectedNode.stage} 阶）` : ''}</div>
                : <div>暂无持有者</div>}
            </div>
          )}
          {selectedNode.kind === 'career_group' && (
            <div style={{ color: 'var(--color-text-secondary)' }}>职业分组视图节点</div>
          )}
        </div>
      )}

      {/* 缩放控制 */}
      <div style={{
        position: 'absolute', top: 8, left: 12,
        display: 'flex', gap: 6, alignItems: 'center',
      }}>
        <span style={{ fontSize: 10, color: 'var(--color-text-secondary)', pointerEvents: 'none' }}>
          {Math.round(scale * 100)}%
        </span>
        {scale !== 1 && (
          <button
            onClick={handleReset}
            style={{
              background: 'var(--color-surface-container)', border: '1px solid var(--color-border)',
              borderRadius: 4, color: 'var(--color-text)', fontSize: 10, cursor: 'pointer',
              padding: '2px 6px',
            }}
          >
            重置
          </button>
        )}
      </div>
      <div style={{ position: 'absolute', top: 8, right: 12, fontSize: 10, color: 'var(--color-text-secondary)', pointerEvents: 'none' }}>
        拖拽平移 · 滚轮缩放 · 悬停高亮 · 点击看详情
      </div>
      {/* 图例 */}
      <Legend />
    </div>
  )
}

// ── 颜色工具 ──
function hexOrColor(c: string): string {
  return c.startsWith('#') ? c : '#6b7280'
}

function lighten(hex: string, percent: number): string {
  if (!hex.startsWith('#')) return hex
  const num = parseInt(hex.replace('#', ''), 16)
  const r = Math.min(255, (num >> 16) + Math.round(255 * percent / 100))
  const g = Math.min(255, ((num >> 8) & 0x00FF) + Math.round(255 * percent / 100))
  const b = Math.min(255, (num & 0x0000FF) + Math.round(255 * percent / 100))
  return `rgb(${r},${g},${b})`
}

// ── 图例 ──
const Legend: React.FC = () => (
  <div style={{
    position: 'absolute', bottom: 12, right: 12,
    background: 'var(--color-surface-container-high)', borderRadius: 8,
    border: '1px solid var(--color-border)', padding: '10px 14px',
    fontSize: 11, color: 'var(--color-text-secondary)', fontFamily: 'sans-serif',
    pointerEvents: 'none', userSelect: 'none',
    display: 'flex', gap: 24,
  }}>
    <div>
      <div style={{ color: 'var(--color-text)', fontWeight: 600, marginBottom: 4, fontSize: 11 }}>角色</div>
      {Object.entries(roleCN).map(([k, v]) => (
        <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6, lineHeight: '18px' }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: roleColorTokens[k], flexShrink: 0 }} />
          <span>{v}</span>
        </div>
      ))}
    </div>
    <div>
      <div style={{ color: 'var(--color-text)', fontWeight: 600, marginBottom: 4, fontSize: 11 }}>组织</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, lineHeight: '18px' }}>
        <span style={{ width: 10, height: 10, borderRadius: '50%', background: orgColorToken, flexShrink: 0 }} />
        <span>势力/组织</span>
      </div>
      <div style={{ color: 'var(--color-text)', fontWeight: 600, marginBottom: 4 }}>结构边（§7.5）</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, lineHeight: '18px' }}>
        <span style={{ width: 14, height: 0, borderTop: '2px dashed ' + orgColorToken, flexShrink: 0 }} />
        <span>组织成员</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, lineHeight: '18px' }}>
        <span style={{ width: 8, height: 8, borderRadius: 1, background: 'var(--color-primary)', flexShrink: 0 }} />
        <span>主职业（方形节点）</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, lineHeight: '18px' }}>
        <span style={{ width: 8, height: 8, borderRadius: 1, background: 'var(--color-warning)', flexShrink: 0 }} />
        <span>副职业（虚线边）</span>
      </div>
      <div style={{ marginTop: 6, color: 'var(--color-text)', fontWeight: 600, marginBottom: 4 }}>关系</div>
      {Object.entries(relCN).map(([k, v]) => (
        <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6, lineHeight: '18px' }}>
          <span style={{ width: 12, height: 2, background: relColorTokens[k], flexShrink: 0, borderRadius: 1 }} />
          <span>{v}</span>
        </div>
      ))}
    </div>
  </div>
)

export default RelationGraph
