import { afterEach, describe, expect, it, vi } from "vitest";
import { render, screen, fireEvent, within } from "@testing-library/react";
import { XlsxPreview } from "./XlsxPreview";
import { SheetGrid } from "./xlsxpreview/SheetGrid";
import { useComposerInsertStore } from "../lib/store";

const body = JSON.stringify({
  sheets: [
    {
      name: "预算",
      rows: [
        [
          { ref: "A1", value: "项目", type: "string", style: { bold: true, fill: "4472C4" } },
          { ref: "B1", value: "金额", type: "string" },
        ],
        [{ ref: "A2", value: "设备", type: "string" }, { ref: "B2", value: "120.5", type: "number" }],
        [{ ref: "A3", value: "合计", type: "string" }, { ref: "B3", value: "120.5", formula: "SUM(B2)", type: "string" }],
      ],
      merged: [],
      colWidths: { A: 16, B: 14 },
    },
    { name: "明细", rows: [[{ ref: "A1", value: "日期", type: "string" }]], colWidths: {} },
  ],
});

describe("XlsxPreview", () => {
  it("大表格行虚拟滚动：只渲染可见窗口 ± overscan，滚动后窗口随动（400 行不整表渲染）", () => {
    const bigRows = Array.from({ length: 400 }, (_, i) => [
      { ref: `A${i + 1}`, value: `ROW-${i + 1}`, type: "string" },
    ]);
    const bigBody = JSON.stringify({
      sheets: [{ name: "大表", rows: bigRows, colWidths: {} }],
    });
    render(<XlsxPreview body={bigBody} fileName="大表.xlsx" relPath="big.xlsx" />);

    const container = document.querySelector(".docx-preview-body") as HTMLElement;
    expect(container).toBeTruthy();
    // 初始窗口：行 1..10 + 底部 spacer（视口高在 jsdom 为 0，取最小窗口）
    expect(container.querySelectorAll("tbody tr").length).toBeLessThan(100);
    expect(screen.getByText("ROW-1")).toBeTruthy();
    expect(screen.queryByText("ROW-30")).toBeNull();

    container.scrollTop = 1000;
    fireEvent.scroll(container);
    // 窗口随滚动下移：行 24..45 在位，行 1 已卸载（spacer 保持滚动条总高）
    expect(screen.queryByText("ROW-1")).toBeNull();
    expect(screen.getByText("ROW-30")).toBeTruthy();
    expect(container.querySelectorAll("tbody tr").length).toBeLessThan(100);
  });

  it("滚动归零只看表名：原地内容刷新（同名新 sheet 对象）保滚动位，真换表才归零", () => {
    const rows = Array.from({ length: 400 }, (_, i) => [
      { ref: `A${i + 1}`, value: `ROW-${i + 1}`, type: "string" },
    ]);
    // 静默重读/单元格直编/重算都会让 preview.sheets[active] 变成新对象身份，
    // 若按对象比较会在查看大表中途把用户拽回顶部（keepScroll 语义对 xlsx 同样适用）。
    const noop = () => {};
    const mkGrid = (name: string) => (
      <SheetGrid
        sheet={{ name, rows, merged: [], colWidths: {} }}
        selected={null}
        onSelect={noop}
        selectedCol={null}
        onSelectCol={noop}
        editingRef={null}
        draft=""
        onDraftChange={noop}
        onEditCell={noop}
        onCommit={noop}
        onCancelEdit={noop}
      />
    );
    const { rerender } = render(mkGrid("预算"));
    const container = document.querySelector(".docx-preview-body") as HTMLElement;
    container.scrollTop = 1000;
    fireEvent.scroll(container);
    expect(screen.getByText("ROW-30")).toBeTruthy();

    rerender(mkGrid("预算")); // 同名新对象：不归零
    expect(container.scrollTop).toBe(1000);
    expect(screen.getByText("ROW-30")).toBeTruthy();

    rerender(mkGrid("明细")); // 真换表：归零
    expect(container.scrollTop).toBe(0);
  });

  it("小表格保持全量渲染（虚拟化阈值以下行为不变）", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    const container = document.querySelector(".docx-preview-body") as HTMLElement;
    expect(container.querySelectorAll("tbody tr").length).toBe(3);
  });

  it("渲染 sheet 切换与单元格", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    expect(screen.getByText("预算")).toBeTruthy();
    expect(screen.getByText("明细")).toBeTruthy();
    expect(screen.getByText("项目")).toBeTruthy();
    expect(screen.getAllByText("120.5").length).toBeGreaterThanOrEqual(1);
  });

  it("点击公式单元格在公式栏显示公式", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByTitle("=SUM(B2)"));
    const fx = screen.getByPlaceholderText(/选中单元格后输入值/) as HTMLInputElement;
    expect(fx.value).toBe("=SUM(B2)");
  });

  it("双击单元格直接编辑并写回（mock）", async () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.doubleClick(screen.getByText("设备"));
    const grid = document.querySelector(".docx-preview-body") as HTMLElement;
    const editInput = within(grid).getByDisplayValue("设备") as HTMLInputElement;
    fireEvent.change(editInput, { target: { value: "设备-新" } });
    fireEvent.keyDown(editInput, { key: "Enter" });
    expect(await screen.findByText(/已更新 A2/)).toBeTruthy();
  });

  it("按 NumFmt 格式化数值显示", () => {
    const fmtBody = JSON.stringify({
      sheets: [
        {
          name: "S",
          rows: [
            [{ ref: "A1", value: "9992806.15", type: "number", style: { numFmt: "4" } }],
            [{ ref: "A2", value: "0.125", type: "number", style: { numFmt: "10" } }],
            [{ ref: "A3", value: "400", type: "number" }],
          ],
        },
      ],
    });
    render(<XlsxPreview body={fmtBody} fileName="t.xlsx" relPath="mock.xlsx" />);
    expect(screen.getByText("9,992,806.15")).toBeTruthy();
    expect(screen.getByText("12.50%")).toBeTruthy();
    expect(screen.getByText("400")).toBeTruthy();
  });

  it("选中单元格后插入行（mock）", async () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByText("设备"));
    fireEvent.click(screen.getByTitle("在选中行上方插入空行"));
    expect(await screen.findByText(/insert_before@A2/)).toBeTruthy();
  });

  it("选中列后插入列（mock）", async () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    const headers = document.querySelectorAll("thead th");
    fireEvent.click(headers[1]); // 列 A
    expect(screen.getByText("列 A")).toBeTruthy();
    fireEvent.click(screen.getByText("← 插列"));
    expect(await screen.findByText(/insert_before@A1/)).toBeTruthy();
  });


  it("切换 sheet", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByText("明细"));
    expect(screen.getByText("日期")).toBeTruthy();
  });

  it("选中单元格后执行指令：先出规划审阅卡，应用后才落盘（mock）", async () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByText("项目"));
    const input = screen.getByPlaceholderText(/输入指令/);
    fireEvent.change(input, { target: { value: "求和" } });
    fireEvent.click(screen.getByText("执行"));
    // 规划卡：待应用变更 + 逐格 diff（B2 100→120、B5 写公式）
    expect(await screen.findByText(/待应用变更/)).toBeTruthy();
    expect(screen.getByText(/预算!B5/)).toBeTruthy();
    expect(screen.getByText(/fx =SUM\(B2:B4\)/)).toBeTruthy();
    // 批准 → 执行 → 摘要
    fireEvent.click(screen.getByText("应用"));
    expect(await screen.findByText(/已应用/)).toBeTruthy();
  });

  it("规划后可放弃（不落盘，不显示摘要）", async () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByText("项目"));
    fireEvent.change(screen.getByPlaceholderText(/输入指令/), { target: { value: "求和" } });
    fireEvent.click(screen.getByText("执行"));
    await screen.findByText(/待应用变更/);
    fireEvent.click(screen.getByText("放弃"));
    expect(screen.queryByText(/待应用变更/)).toBeNull();
  });

  it("点击预设按钮回填指令到输入框（AI 编辑收敛为单行紧凑）", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByText("项目"));
    // 预设「清洗」→ 指令回填
    fireEvent.click(screen.getByText("清洗"));
    const input = screen.getByPlaceholderText(/输入指令/) as HTMLInputElement;
    expect(input.value).toContain("清洗");
  });

  it("选中单元格后经图表菜单嵌入原生图表并显示迷你预览", async () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByText("设备")); // 选中 A2
    // 图表动作收敛为下拉菜单：先展开「图表 ▾」，再选「柱状图」
    fireEvent.click(screen.getByRole("button", { name: /图表/ }));
    fireEvent.click(screen.getByRole("menuitem", { name: /柱状图/ }));
    // mock 返回 3 个数据点 → notice + SVG 迷你图
    expect(await screen.findByText(/已嵌入图表到/)).toBeTruthy();
    expect(document.querySelector('[data-testid="mini-chart"]')).toBeTruthy();
    expect(await screen.findByText(/3 个数据点/)).toBeTruthy();
  });

  it("图表菜单含折线/饼图/嵌入 Word/嵌入 PPT 入口（mock 不抛错）", async () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByRole("button", { name: /图表/ }));
    // 菜单内 5 个动作齐全
    expect(screen.getByRole("menuitem", { name: /折线图/ })).toBeTruthy();
    expect(screen.getByRole("menuitem", { name: /饼图/ })).toBeTruthy();
    expect(screen.getByRole("menuitem", { name: /图表→Word/ })).toBeTruthy();
    expect(screen.getByRole("menuitem", { name: /图表→PPT/ })).toBeTruthy();
    fireEvent.click(screen.getByRole("menuitem", { name: /折线图/ }));
    expect(await screen.findByText(/已嵌入图表/)).toBeTruthy();
  });
});

describe("XlsxPreview B3 选区引用到对话", () => {
  afterEach(() => {
    useComposerInsertStore.setState({ pendingText: null });
  });

  it("选中单元格 → 浮动「引用到对话」出现，点击经 onQuoteSelection 给出 sheet!ref 与值", () => {
    const onQuoteSelection = vi.fn();
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" onQuoteSelection={onQuoteSelection} />);
    // 初始无浮动入口
    expect(screen.queryByTestId("xlsx-quote-btn")).toBeNull();
    fireEvent.click(screen.getByText("设备")); // 选中 A2
    const btn = screen.getByTestId("xlsx-quote-btn");
    fireEvent.click(btn);
    expect(onQuoteSelection).toHaveBeenCalledTimes(1);
    const quote = onQuoteSelection.mock.calls[0][0] as string;
    expect(quote).toContain("《预算表.xlsx》");
    expect(quote).toContain("预算!A2");
    expect(quote).toContain("设备");
    // 默认通道未被使用（回调优先）
    expect(useComposerInsertStore.getState().pendingText).toBeNull();
  });

  it("无 onQuoteSelection 时走既有 composer 插入通道（requestText）", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByText("设备")); // 选中 A2
    fireEvent.click(screen.getByTestId("xlsx-quote-btn"));
    const text = useComposerInsertStore.getState().pendingText ?? "";
    expect(text).toContain("> 《预算表.xlsx》预算!A2：设备");
    expect(text).toContain("请基于以上选中单元格继续处理");
  });

  it("公式单元格引用带 fx 前缀与计算值", () => {
    const onQuoteSelection = vi.fn();
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" onQuoteSelection={onQuoteSelection} />);
    fireEvent.click(screen.getByTitle("=SUM(B2)")); // 选中 B3
    fireEvent.click(screen.getByTestId("xlsx-quote-btn"));
    const quote = onQuoteSelection.mock.calls[0][0] as string;
    expect(quote).toContain("fx =SUM(B2)");
    expect(quote).toContain("120.5");
  });

  it("双击进入直接编辑时浮动入口隐藏（不与直接编辑抢占），Esc 取消后恢复", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.doubleClick(screen.getByText("设备"));
    expect(screen.queryByTestId("xlsx-quote-btn")).toBeNull();
    const grid = document.querySelector(".docx-preview-body") as HTMLElement;
    const editInput = within(grid).getByDisplayValue("设备") as HTMLInputElement;
    fireEvent.keyDown(editInput, { key: "Escape" });
    expect(screen.getByTestId("xlsx-quote-btn")).toBeTruthy();
  });
});

// ── v4.515 图表菜单键盘可达（ARIA 菜单模式）──────────────────────────
// role=menu 此前只有鼠标路径（外点关闭）：Escape 关闭 + 方向键漫游聚焦补齐。
describe("图表菜单键盘可达（v4.515）", () => {
  it("Escape 关闭菜单（document 级守卫）", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByRole("button", { name: /图表/ }));
    expect(screen.getByRole("menuitem", { name: /柱状图/ })).toBeTruthy();

    fireEvent.keyDown(document, { key: "Escape" });
    expect(screen.queryByRole("menuitem", { name: /柱状图/ })).toBeNull();
  });

  it("方向键漫游聚焦：ArrowDown/End 在 5 个菜单项间移动", () => {
    render(<XlsxPreview body={body} fileName="预算表.xlsx" relPath="mock.xlsx" />);
    fireEvent.click(screen.getByRole("button", { name: /图表/ }));

    const menu = screen.getByRole("menu");
    const items = menu.querySelectorAll<HTMLButtonElement>("button[role=menuitem]");
    expect(items.length).toBe(5);

    items[0].focus();
    fireEvent.keyDown(menu, { key: "ArrowDown" });
    expect(document.activeElement).toBe(items[1]);

    fireEvent.keyDown(menu, { key: "End" });
    expect(document.activeElement).toBe(items[4]);

    fireEvent.keyDown(menu, { key: "ArrowDown" }); // 末项下绕回首项（循环）
    expect(document.activeElement).toBe(items[0]);
  });
});
