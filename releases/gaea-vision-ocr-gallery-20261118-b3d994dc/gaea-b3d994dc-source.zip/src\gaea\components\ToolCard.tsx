import { memo, useId, useMemo, useRef, useState } from "react";
import {
  Ban,
  Check,
  ChevronRight,
  LineChart,
  Loader2,
  Users,
  X,
} from "../icons";


import { mcpOr } from "./tool_icons";
import { lxToolIcon } from "./lingxiIcons";
import { useT } from "../lib/i18n";
import { useCompact } from "../hooks/useCompact";
import { useGSAPCollapse } from "../lib/useGSAPCollapse";
import { emitFrontendEvent, FRONTEND_EVENTS } from "../../events";
import {
  boundedOutput,
  commandOf,
  diffStatFor,
  diffsFor,
  READER_JSON_TOOLS,
  subjectOf,
  summarize,
  TOOL_CARD_OUTPUT_PREVIEW_LINES,
  unifiedRows,
} from "../lib/tools";
import type { DiffRow } from "../lib/diff";
import { fireTaskCardAmbiguity, getTaskCardActivity, getTaskCardAmbiguity, getTaskCardOpenTarget, hasTaskCardActivityProvider, hasTaskCardAmbiguityHandler, openTaskCardSession, resolveTaskRef, taskResultSummary } from "../lib/taskActivity";
import { formatElapsed } from "../lib/time";
import { useNow } from "../lib/useNow";
import { MemoryPeekModal } from "./MemoryPeekModal";
import { parseMemoryPeek } from "../lib/memoryPeek";
import type { Item } from "../lib/store";
import { FileLinkText } from "./FileLinkText";
import { ScheduleApplyRollback } from "./ScheduleApplyRollback";
import { ToolSources } from "../../components/evidence/ToolSources";

export type ToolItem = Extract<Item, { kind: "tool" }>;
export interface ToolCardProps {
  item: ToolItem;
  subcalls?: ToolItem[];
  isToolVisible?: (name: string) => boolean;
}

function pretty(json: string): string {
  try {
    return JSON.stringify(JSON.parse(json), null, 2);
  } catch {
    return json;
  }
}

function StatusGlyph({ status, recoverable }: { status: ToolItem["status"]; recoverable?: boolean }) {
  if (status === "running") return <Loader2 className="animate-spin" size={12} />;
  if (status === "error") return <X className={recoverable ? "text-fg-faint/60" : "text-err"} size={12} />;
  if (status === "stopped") return <Ban className="text-fg-faint" size={12} />;
  return <Check className="text-ok" size={12} />;
}

// v4.504 diff 完成刀：行级 ± 视图替代只显 original 的旧渲染（write_file 全增
// diff 的 original 是空串→展开态空盒；edit_file 只显旧文）。着色对齐 diffstat
// 芯片口径：add=text-ok、del=text-err、ctx=text-fg-dim。
function DiffRowsView({ rows, folded }: { rows: DiffRow[]; folded: number }) {
  return (
    <pre className="office-tool-card__diff px-3 py-2 overflow-auto max-h-72 whitespace-pre">
      <code>
        {rows.map((r, i) => (
          <span
            key={i}
            data-diff={r.type}
            className={`block ${r.type === "add" ? "text-ok bg-ok/5" : r.type === "del" ? "text-err bg-err/5" : "text-fg-dim"}`}
          >
            <span className="office-diff__label">{r.type === "add" ? "+ " : r.type === "del" ? "- " : ""}</span>
            {r.text}
          </span>
        ))}
        {folded > 0 && <span className="block text-fg-faint/60">{`… 已折叠 ${folded} 行`}</span>}
      </code>
    </pre>
  );
}

// ── TaskLiveRow：task 工具卡运行中的实时活动行（v4.26 对齐 Codex）──────
// Why：子代理跑起来后主窗此前只有一张静态「运行中」task 卡——子代理的
// lastText/lastTool 只在右栏分工面板可见。本行把 GaeaAgentNetwork/SubagentRuns
// 轮询数据经 setTaskCardActivityProvider 注入的动态渲染成 Codex 式活动预览
// （单行截断），并补已用时 + 「查看分工」入口提示。
// How：ref 解析（args.continue_from / output 引用行，派发初期为 ""）→
// getTaskCardActivity 取动态；未注入 provider（null=按现状渲染契约）→ 整行
// 不渲染；查不到动态 → 只显示已用时与提示，绝不报错。1s tick（useNow）内刷新。
function TaskLiveRow({ item }: { item: ToolItem }) {
  const t = useT();
  const now = useNow();
  // 起跑时刻：Item 契约无时间戳，以挂载时刻近似计时（运行中卡片常驻挂载；
  // 恢复历史会话时 running 一律还原为 stopped，不会进入本行）。
  const startRef = useRef(Date.now());
  const ref = useMemo(() => resolveTaskRef(item.args, item.output), [item.args, item.output]);
  // 1s tick 内取值：App 层轮询更新 provider 数据后最迟 1s 上屏。
  // args 原样透传：派发初期 ref 为空串时，App 侧 provider 可用 args 里的
  // 任务描述文本与并行各 run.task 做唯一命中匹配（taskActivity 契约）。
  const activity = getTaskCardActivity(ref, item.args);
  // v4.63：运行中活动行本身也是「打开会话」入口（与整卡点击同语义）。
  // v4.68：空 ref 多候选歧义时同样可点——点击改派歧义处理器（App 弹选择器
  // 人工挑一个），不自动跳转；0/1 候选走原 openRef 直跳链路，行为不变。
  const openRef = ref || getTaskCardOpenTarget("", item.args);
  const ambiguous = !openRef && getTaskCardAmbiguity("", item.args) && hasTaskCardAmbiguityHandler();
  const rowClickable = !!openRef || ambiguous;
  // 未注入活动数据源（null）：按现状渲染（v4.26 之前没有这一行）
  if (!hasTaskCardActivityProvider()) return null;
  const elapsed = formatElapsed(Math.max(0, now - Math.floor(startRef.current / 1000)));

  return (
    <div
      data-testid="task-live"
      className={`flex items-center gap-1.5 px-2 pb-1 pl-7 text-[11px] text-fg-faint select-none ${rowClickable ? "cursor-pointer hover:text-fg-dim" : ""}`}
      title={ambiguous ? t("taskpick.cardAria") : openRef ? t("tool.openSessionHint") : undefined}
      aria-label={ambiguous ? t("taskpick.cardAria") : undefined}
      onClick={rowClickable ? () => { if (openRef) openTaskCardSession(openRef); else fireTaskCardAmbiguity(item.args); } : undefined}
    >
      {activity?.lastText && (
        <span className="min-w-0 truncate text-fg-dim/80" title={activity.lastText}>
          {activity.lastText}
        </span>
      )}
      {activity?.lastTool && (
        <span className="min-w-0 shrink-0 max-w-[30%] truncate font-mono" title={activity.lastTool}>
          {activity.lastTool}
        </span>
      )}
      <span className="ml-auto shrink-0 tabular-nums">{elapsed}</span>
      <span className="inline-flex shrink-0 items-center gap-1">
        <Users size={11} className="shrink-0" />
        {t("tool.openSessionHint")}
      </span>
    </div>
  );
}

export const ToolCard = memo(function ToolCard({ item, subcalls, isToolVisible }: ToolCardProps) {
  const t = useT();
  const compact = useCompact();
  const diffs = useMemo(() => diffsFor(item.name, item.args), [item.name, item.args]);
  // 波3.5 实弹反馈：提炼记忆（remember/fact_add）行点击直接弹窗查看完整内容，
  // 行内主体显示记忆正文首行（不再要求展开翻 JSON args）。
  const memoryPeek = useMemo(
    () => (item.name === "remember" || item.name === "fact_add" ? parseMemoryPeek(item.name, item.args) : null),
    [item.name, item.args],
  );
  const [peekOpen, setPeekOpen] = useState(false);
  const rawSubject = useMemo(() => subjectOf(item.name, item.args), [item.name, item.args]);
  const subject = useMemo(() => {
    if (memoryPeek) {
      const first = memoryPeek.body.split("\n").find((l: string) => l.trim()) ?? "";
      return first.length > 60 ? first.slice(0, 60) + "…" : first || memoryPeek.title;
    }
    return rawSubject;
  }, [memoryPeek, rawSubject]);
  // Codex 式 diffstat 芯片：编辑类工具行内显示 +N−M（不再重复进斜体摘要）
  const stat = useMemo(() => diffStatFor(item.name, item.args), [item.name, item.args]);
  const Icon = lxToolIcon(item.name) ?? mcpOr(item.name);
  const nested = subcalls ?? [];
  const hasNested = nested.length > 0;

  // v4.350：summary/pretty/outputLines memo 化——write_file 等工具 args 内联
  // 整文件内容（数百 KB 常见），此前折叠态每次自身更新仍全付 JSON round-trip
  // 与全文 split（diffsFor/boundedOutput 已 memo，此处补齐漏网三处）。
  const summary = useMemo(() => {
    if (item.status === "running") return "";
    if (item.name === "task") {
      // v4.26：task 卡完成后显示子代理结果摘要（summarize 对 task 返回空，
      // 完成卡此前除嵌套步数外没有任何结果信息；error 走卡片错误区）。
      return taskResultSummary(item.output, item.error) ||
        (nested.length > 0 ? t(nested.length === 1 ? "tool.stepOne" : "tool.stepOther", { n: nested.length }) : "");
    }
    return nested.length > 0
      ? t(nested.length === 1 ? "tool.stepOne" : "tool.stepOther", { n: nested.length })
      : summarize(item.name, item.args, item.output, item.error);
  }, [item.status, item.name, item.args, item.output, item.error, nested.length, t]);

  // Codex 式对齐（2026-10）：展开态不再整包摊 JSON args——
  // ① bash 类把 args.command 直接渲染成终端命令块（多行命令在 JSON 里
  //    是 \n 转义长串，是「太长」的主源）；
  // ② 写文件类 diffs 已是 args 的呈现，args JSON 不再重复渲染（此前
  //    write_file 整文件内容 diff 一遍、JSON 再摊一遍）。
  const command = useMemo(() => commandOf(item.name, item.args), [item.name, item.args]);
  const showArgsJson = !command && diffs.length === 0 && !READER_JSON_TOOLS.has(item.name) && !!item.args;
  const hasOutput = !!item.output;
  const [open, setOpen] = useState(false);
  // 三层预算派生：披露按真实隐藏量，而不是“有 output 就一定有内容可展开”。
  const bounded = useMemo(() => boundedOutput(item.output, TOOL_CARD_OUTPUT_PREVIEW_LINES), [item.output]);
  const expandable = !!command || diffs.length > 0 || showArgsJson || bounded.collapsed || !!item.error;
  const [showFullOutput, setShowFullOutput] = useState(false);

  const bodyRef = useRef<HTMLDivElement>(null);
  useGSAPCollapse(bodyRef, open && expandable);

  const quiet =
    item.readOnly && !hasNested && item.status !== "error" && item.status !== "stopped";

  const prettyArgs = useMemo(() => (showArgsJson && item.args ? pretty(item.args) : ""), [showArgsJson, item.args]);

  // v4.63 子代理卡片整卡可点：task / run_skill 卡解析出可跳转的子代理 ref
  // 时，点击头部行直接打开对应会话 tab（与右栏任务树同款跳转），不再只是
  // 折叠展开。空目标 = 不可点（诚实维持现状）。
  // v4.68：空 ref 多候选歧义（≥2 文本匹配 running）时不再死路——整卡可点，
  // 点击派发歧义处理器由 App 弹轻量选择器人工挑一个（宁缺勿错：绝不自动
  // 跳转；0/1 候选行为与 v4.63 完全一致）。可达性：cursor-pointer +
  // aria-label 说明「多个运行中任务，点击选择」。
  const isSubagentCard = item.name === "task" || item.name === "run_skill";
  const resolvedRef = isSubagentCard ? resolveTaskRef(item.args, item.output) : "";
  const openTarget = isSubagentCard
    ? getTaskCardOpenTarget(resolvedRef, item.args)
    : "";
  const ambiguous = isSubagentCard && !openTarget
    && getTaskCardAmbiguity(resolvedRef, item.args)
    && hasTaskCardAmbiguityHandler();
  const clickable = isSubagentCard && (!!openTarget || ambiguous);
  const bodyId = useId();
  const statusLabel = item.status === "running"
    ? t("process.statusRunning")
    : item.status === "error"
      ? t("process.statusError")
      : item.status === "stopped"
        ? t("process.statusStopped")
        : t("process.statusDone");

  const chevronSize = compact ? 11 : 12;
  const innerPx = compact ? "px-1" : "px-2";
  const innerPb = compact ? "pb-1" : "pb-1.5";
  if (isToolVisible && !isToolVisible(item.name)) return null;

  // 工具行先回答“运行了什么、结果是什么”，再允许下钻输出。整行使用真实
  // button 语义，键盘与屏幕阅读器都能展开；子代理卡仍可直接打开会话。
  return (
    <div
      className={`office-tool-card ${item.status === "stopped" ? "opacity-70" : ""}`}
      data-tone={item.status === "error" && !item.recoverable ? "danger" : item.status === "running" ? "info" : item.status === "done" ? "success" : item.status === "stopped" ? "warning" : undefined}
      data-open={open && expandable ? "true" : "false"}
      data-quiet={quiet ? "true" : "false"}
      data-compact={compact ? "true" : "false"}
    >
      <button
        type="button"
        className={`office-tool-card__head select-none ${clickable ? "cursor-pointer" : ""}`}
        onClick={
          memoryPeek
            ? () => setPeekOpen(true)
            : clickable
              ? ambiguous
                ? () => { fireTaskCardAmbiguity(item.args); }
                : () => { openTaskCardSession(openTarget); }
              : expandable
                ? () => setOpen((v) => !v)
                : undefined
        }
        title={ambiguous ? t("taskpick.cardAria") : clickable ? t("tool.openSessionHint") : undefined}
        aria-label={ambiguous ? t("taskpick.cardAria") : undefined}
        aria-expanded={!memoryPeek && !clickable && expandable ? open : undefined}
        aria-controls={!clickable && expandable ? bodyId : undefined}
        disabled={!clickable && !expandable}
      >
        <span className="office-tool-card__status" data-status={item.status} title={statusLabel}>
          <StatusGlyph status={item.status} recoverable={item.recoverable} />
          <span className="sr-only">{statusLabel}</span>
        </span>
        <Icon
          className="office-tool-card__icon shrink-0"
          width={chevronSize + 2}
          height={chevronSize + 2}
          aria-hidden
        />
        <span className="office-tool-card__identity">
          <span className={`office-tool-card__name ${item.status === "error" && item.recoverable ? "line-through opacity-70" : ""}`}>
            {item.name}
          </span>
          {/* bash 的行内主体=命令本身；展开后由下方命令块独占。 */}
          {subject && !(open && command) && (
            <span className="office-tool-card__subject" data-command={command ? "true" : "false"}>
              {command ? `$ ${subject}` : subject}
            </span>
          )}
        </span>
        <span className="office-tool-card__trail">
          {stat && (stat.add > 0 || stat.del > 0) ? (
            <span
              className="office-tool-card__diffstat inline-flex items-center gap-1 border border-border-soft bg-bg-soft px-1 py-px font-mono text-fg-dim tabular-nums"
              title={t("tool.diffStatTitle")}
            >
              <span className="text-ok">+{stat.add}</span>
              <span className="text-err">−{stat.del}</span>
            </span>
          ) : (
            summary && <span className="office-tool-card__summary">{summary}</span>
          )}
        </span>
        <ChevronRight
          size={chevronSize}
          className={`office-tool-card__chevron shrink-0 ${!clickable && !expandable ? "invisible" : ""}`}
          data-open={open ? "true" : "false"}
          aria-hidden
        />
      </button>

      {/* v4.26 子代理 task 卡 live 化：运行中在头部行下方渲染实时活动行
          （活动预览 / 已用时 / 查看分工），不进折叠区、常驻可见。 */}
      {item.name === "task" && item.status === "running" && <TaskLiveRow item={item} />}
      <ToolSources sources={item.sources} />

      {/* schedule_apply 回执卡常驻动作行（v4.146 刀A + 工具化 2026-10）：
          「回滚本次」（Journal 按 target 匹配最新基线快照，无记录该段不渲染）
          +「展开查看」开右栏「进度计划」Tab（2026-11-14 起右栏一级 Tab，原 ToolSheet 退役；
          docs/gaea-ai-workbench-ui-2026-10.md §4 工具卡=工具入口之一）。 */}
      {item.name === "schedule_apply" && item.status === "done" && (
        <div className="px-3 py-1 flex items-center gap-2 border-b border-border-soft" data-testid="sched-apply-actions">
          <ScheduleApplyRollback args={item.args} />
          <span className="flex-1" />
          <button
            className="shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded-md border border-accent/40 bg-transparent text-accent text-[10px] cursor-pointer hover:bg-accent/10 transition-colors"
            onClick={() => emitFrontendEvent(FRONTEND_EVENTS.OPEN_TOOL, { tool: "schedule" })}
            title="在对话上方打开进度计划工具面板（临时面板，关闭回到对话）"
            data-testid="sched-apply-open-tool"
          >
            <LineChart size={10} aria-hidden />
            展开查看
          </button>
        </div>
      )}

      <div id={bodyId} ref={bodyRef} style={{ overflow: "hidden" }}>
        <div className="office-tool-card__body">
          {diffs.map((d, i) => {
            const { rows, folded } = unifiedRows(d.original, d.modified);
            if (rows.length === 0 && folded === 0) return null;
            return (
              <div className={`${innerPx} ${innerPb}`} key={i}>
                {d.label && <div className="office-tool-card__section-label">{d.label}</div>}
                <DiffRowsView rows={rows} folded={folded} />
              </div>
            );
          })}

          {hasNested && (
            <div className="pl-3 border-l border-border-soft ml-3">
              {nested.map((c) => (
                <ToolCard key={c.id} item={c} isToolVisible={isToolVisible} />
              ))}
            </div>
          )}

          {/* Codex 式 bash 命令块：$ 前缀终端风格，多行命令原样换行、超长行折行 */}
          {command && (
            <div className={`${innerPx} ${innerPb}`}>
              <pre className="office-tool-card__command px-3 py-2 whitespace-pre-wrap break-words text-fg-dim"><code>{`$ ${command}`}</code></pre>
            </div>
          )}

          {showArgsJson && (
            <div className={`${innerPx} ${innerPb}`}>
              {item.args && <pre className="office-tool-card__args px-3 py-2 overflow-auto whitespace-pre text-fg-dim"><code>{prettyArgs}</code></pre>}
            </div>
          )}
          {hasOutput && (
            <div className={`${innerPx} ${innerPb}`}>
              <div className="office-tool-card__section-label select-none">{t("tool.outputHeader", { n: bounded.totalLines })}</div>
              <pre className="office-tool-card__output px-3 py-2 overflow-auto max-h-72 whitespace-pre-wrap break-words text-fg-dim"><code><FileLinkText text={showFullOutput ? bounded.full : bounded.preview} compact /></code></pre>
              {bounded.preview !== bounded.full && (
                <button
                  type="button"
                  className="mt-1 px-2 py-0.5 border border-border-soft rounded bg-bg-soft text-fg-dim text-[11px] cursor-pointer hover:bg-bg-soft hover:text-fg transition-colors"
                  onClick={() => setShowFullOutput((v) => !v)}
                >
                  {showFullOutput
                    ? t("tool.collapseOutput")
                    : bounded.collapsed
                      ? t("tool.expandAllLines", { n: bounded.hiddenLines })
                      : t("tool.expandFullOutput")}
                </button>
              )}
              {item.truncated && (
                <div className="mt-1 px-2 py-0.5 border border-border-soft rounded bg-bg-soft text-fg-dim text-[11px]">
                  {t("tool.truncated")}
                </div>
              )}
            </div>
          )}

          {item.error && !item.recoverable && (
            <div className="office-tool-card__error" data-recoverable="false" role="alert">
              {item.error}
            </div>
          )}
          {item.error && item.recoverable && (
            <div className="office-tool-card__error" data-recoverable="true">
              {item.error}
            </div>
          )}
        </div>
      </div>
      {peekOpen && memoryPeek && (
        <MemoryPeekModal payload={{ tool: item.name, args: item.args }} onClose={() => setPeekOpen(false)} />
      )}
    </div>
  );
});
