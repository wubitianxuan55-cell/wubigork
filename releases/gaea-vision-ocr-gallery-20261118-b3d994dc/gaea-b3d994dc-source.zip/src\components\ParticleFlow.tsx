import { useEffect, useRef } from 'react'

type Props = {
  /** 唤醒度 arousal (0-100)，驱动微粒上升速度 */
  aro?: number
  className?: string
}

/** 琥珀光微粒上升动画 — 32 粒子，aro 越高上升越快（对齐 Ackem ParticleFlow） */
export function ParticleFlow({ aro = 0, className = '' }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let raf = 0
    const particles = Array.from({ length: 32 }, () => ({
      x: Math.random(),
      y: Math.random(),
      size: 1 + Math.random() * 2,
      speed: 0.00015 + Math.random() * 0.00025,
      opacity: 0.02 + Math.random() * 0.04,
    }))

    const speedMul = 1 + (Math.max(0, aro) / 100) * 0.5

    const draw = () => {
      // v4.365 后台空转治理：页面隐藏(keepAlive display:none)或窗口最小化时挂起绘制
      if (document.hidden || canvas.offsetParent === null) {
        raf = requestAnimationFrame(draw)
        return
      }
      const w = canvas.width
      const h = canvas.height
      ctx.clearRect(0, 0, w, h)
      for (const p of particles) {
        p.y -= p.speed * speedMul
        if (p.y < 0) {
          p.y = 1
          p.x = Math.random()
        }
        const x = p.x * w
        const y = p.y * h
        ctx.beginPath()
        ctx.arc(x, y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(196, 168, 112, ${p.opacity})`
        ctx.fill()
      }
      raf = requestAnimationFrame(draw)
    }

    const resize = () => {
      const parent = canvas.parentElement
      if (!parent) return
      canvas.width = parent.clientWidth
      canvas.height = parent.clientHeight
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(canvas.parentElement ?? canvas)
    draw()

    return () => {
      cancelAnimationFrame(raf)
      ro.disconnect()
    }
  }, [aro])

  return (
    <canvas
      ref={canvasRef}
      style={{ position: 'absolute', inset: 0, zIndex: 0, pointerEvents: 'none' }}
      className={className}
      aria-hidden
    />
  )
}
