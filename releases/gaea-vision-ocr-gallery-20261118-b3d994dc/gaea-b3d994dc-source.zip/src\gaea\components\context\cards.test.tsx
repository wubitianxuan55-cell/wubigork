// cards.test.tsx — dsh-context 头部仪表卡（cards.tsx）定向 jsdom 测试。
// 被测组件为纯展示（无 bridge 依赖；TokenCard v4.96 起带可选 onViewTrend
// 回调，缺省不渲染入口），无需 mock 外部模块。
import { fireEvent, render, screen, within } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type { ContextRequestRecord, ContextStats, ContextTiming } from "../../lib/types";
import { costHoverTitle, fmtDuration, SessionInfoCard, StatsCard, summarizeTokens, SummaryBar, TimingCard, TokenCard } from "./cards";
import type { ReactElement } from "react";
import { LocaleProvider } from "../../lib/i18n";
import type { DictKey } from "../../locales/en";

const renderZ = (ui: ReactElement) => {
  localStorage.setItem("gaea-lang", "zh");
  return render(<LocaleProvider>{ui}</LocaleProvider>);
};

const REQ = (seq: number, hit: number, miss: number, out: number): ContextRequestRecord => ({
  seq,
  ts: 1750000000 + seq,
  turn: 1,
  step: seq,
  category: { system: 0, tools: 0, user: 0, skill: 0, inject: 0, assistant: 0, tool: 0 },
  cacheHitTokens: hit,
  cacheMissTokens: miss,
  outputTokens: out,
});

// ─── fmtDuration / summarizeTokens 纯函数 ───────────────────────

// zh 直译器（i18n 收口批起 fmtDuration 单位词经 t 注入）：走真实 zh 字典插值，
// 断言口径与运行态中文界面逐字一致。键型收 DictKey 对齐 Translator 签名。
const zhT = (key: DictKey, vars?: Record<string, string | number>): string =>
  ({ "contextview.durSec": "{n} 秒", "contextview.durMinSec": "{m} 分 {s} 秒" })[key as "contextview.durSec"].replace(
    /\{(\w+)\}/g,
    (_, k) => String(vars?.[k] ?? `{${k}}`),
  );

describe("fmtDuration 时长格式化", () => {
  it("秒级与分钟级两种形态", () => {
    expect(fmtDuration(0, zhT)).toBe("0 秒");
    expect(fmtDuration(30000, zhT)).toBe("30 秒");
    expect(fmtDuration(65000, zhT)).toBe("1 分 5 秒");
    expect(fmtDuration(60000, zhT)).toBe("1 分 0 秒");
    expect(fmtDuration(3661000, zhT)).toBe("61 分 1 秒");
  });
});

describe("summarizeTokens 汇总", () => {
  it("累计 hit/miss/out，空请求归零", () => {
    expect(summarizeTokens([REQ(1, 300000, 5000, 1000), REQ(2, 100000, 5000, 2000)])).toEqual({
      hit: 400000, miss: 10000, out: 3000,
    });
    expect(summarizeTokens([])).toEqual({ hit: 0, miss: 0, out: 0 });
  });
});

// ─── StatsCard 上下文统计 ────────────────────────────────────────

describe("StatsCard", () => {
  const stats: ContextStats = {
    turns: 2, steps: 60, injects: 6, compacts: 1, prunes: 0, toolCalls: 279, images: 3, costEstimate: 3.83,
  };

  it("复合卡：四 tile+事件行+IO 行（1:1 重构后）", () => {
    renderZ(<StatsCard stats={stats} nodes={[]} files={[]} commands={[]} />);
    for (const label of ["轮次", "步数", "技能加载", "模型回复"]) {
      expect(screen.getByText(label)).toBeTruthy();
    }
    expect(screen.getByText("2")).toBeTruthy();
    expect(screen.getByText("60")).toBeTruthy();
    expect(screen.getByText("279")).toBeTruthy(); // 工具调用 chips（nodes 聚合）
  });

  it("复合卡不伪造费用（costEstimate 缺失无 ¥ 渲染）", () => {
    renderZ(<StatsCard stats={{ ...stats, costEstimate: undefined }} nodes={[]} files={[]} commands={[]} />);
    expect(screen.queryByText(/¥/)).toBeNull();
  });
});

// ─── TokenCard ──────────────────────────────────────────────────

describe("TokenCard", () => {
  const requests = [REQ(1, 300000, 5000, 1000), REQ(2, 100000, 5000, 2000)];

  it("环形中心显示缓存命中率，分解行显示三分类值与占比", () => {
    const { container } = renderZ(<TokenCard requests={requests} />);
    // 命中率 = hit/(hit+miss) = 400000/410000 → 97.56%（v4.69 环心两位小数）
    expect(screen.getByText("97.56%")).toBeTruthy();
    expect(screen.getByText("缓存输入")).toBeTruthy();
    expect(screen.getByText("400k")).toBeTruthy();
    expect(screen.getByText("10k")).toBeTruthy();
    expect(screen.getByText("3k")).toBeTruthy();
    // 占比 = 各分类 / 总量(413000)：97% / 2% / 1%
    expect(screen.getByText("97%")).toBeTruthy();
    expect(screen.getByText("2%")).toBeTruthy();
    expect(screen.getByText("1%")).toBeTruthy();
    // 环形：track + 3 段；绿段（缓存输入）dash 长度占总长 = 400000/413000
    const dashed = Array.from(container.querySelectorAll<SVGCircleElement>("circle[stroke-dasharray]"));
    expect(dashed.length).toBe(3);
    const lens = dashed.map((c) => Number(c.getAttribute("stroke-dasharray")!.split(" ")[0]));
    const green = container.querySelector('circle[stroke="#22c55e"]')!;
    expect(green).toBeTruthy();
    const greenLen = Number(green.getAttribute("stroke-dasharray")!.split(" ")[0]);
    expect(greenLen / lens.reduce((a, b) => a + b, 0)).toBeCloseTo(400000 / 413000, 3);
  });

  it("空请求：中心与数值空态「—」，占比 0%", () => {
    const { container } = renderZ(<TokenCard requests={[]} />);
    expect(screen.getAllByText("—").length).toBe(4); // 中心 + 3 行数值
    expect(screen.getAllByText("0%").length).toBe(3);
    // 只有 track，无数据段
    expect(container.querySelectorAll("circle").length).toBe(1);
  });

  it("v4.96 无 onViewTrend 回调：不渲染「查看趋势」入口（向后兼容，零破坏）", () => {
    renderZ(<TokenCard requests={requests} />);
    expect(screen.queryByTestId("token-view-trend")).toBeNull();
  });

  it("v4.96 有 onViewTrend 回调：渲染「查看趋势」入口，点击触发一次回调", () => {
    const onViewTrend = vi.fn();
    renderZ(<TokenCard requests={requests} onViewTrend={onViewTrend} />);
    const entry = screen.getByTestId("token-view-trend");
    expect(entry.textContent).toBe("查看趋势");
    fireEvent.click(entry);
    expect(onViewTrend).toHaveBeenCalledTimes(1);
  });
});

// ─── TimingCard ─────────────────────────────────────────────────

describe("TimingCard", () => {
  const timing: ContextTiming = {
    wallMs: 65000,
    ttftMs: 12000,
    genMs: 30000,
    calls: 5,
    toolsMs: 15000,
    toolCalls: 8,
    reasoningMs: 18000,
    reasoningBlocks: 4,
    textMs: 12000,
    textBlocks: 3,
    outputTokens: 2500,
    tools: [
      { name: "read_file", calls: 3, ms: 9000 },
      { name: "bash", calls: 5, ms: 6000 },
      { name: "grep", calls: 2, ms: 12000 },
      { name: "sed", calls: 1, ms: 1000 },
    ],
  };

  it("环形中心为活跃时长，四分解行含时长/次数/占比，其他开销为推导值", () => {
    renderZ(<TimingCard timing={timing} />);
    expect(screen.getAllByText("1 分 5 秒").length).toBeGreaterThanOrEqual(1); // 中心 wallMs（条带末刻度重复出现）
    // 行级断言（各行的「12 秒」「5 次」可能与工具排行重复，用行作用域消歧）
    const row = (label: string) => within(screen.getByText(label).closest("li")!); // 1:1 行容器是 li
    expect(row("模型等待").getByText("12 秒")).toBeTruthy();
    expect(row("模型等待").getByText("· 5 次")).toBeTruthy();
    expect(row("模型等待").getByText("18.5%")).toBeTruthy(); // 12000/65000
    // 1:1 六行：思考 18000→「18 秒 · 4 个内容块」、回复 12000→「12 秒 · 3 个内容块」
    expect(row("模型思考").getByText("18 秒")).toBeTruthy();
    expect(row("模型思考").getByText("· 4 个内容块")).toBeTruthy();
    expect(row("模型回复").getByText("12 秒")).toBeTruthy();
    expect(row("工具执行").getByText("15 秒")).toBeTruthy();
    expect(row("工具执行").getByText("· 8 次")).toBeTruthy();
    // 其他开销 = 65000-12000-30000-15000 = 8 秒，无计数显示「—」
    expect(row("其他开销").getByText("8 秒")).toBeTruthy();
    // 1:1：wall 在环心与时间轴条带末刻度出现两次 → getAllByText
    expect(screen.getAllByText("1 分 5 秒").length).toBeGreaterThanOrEqual(1);
  });

  it("tools 排行取时长 top3 迷你行", () => {
    renderZ(<TimingCard timing={timing} />);
    const tools = within(screen.getByTestId("timing-tools"));
    expect(tools.getByText("grep")).toBeTruthy(); // 12000ms 居首
    expect(tools.getByText("12 秒 · 2 次")).toBeTruthy();
    expect(tools.queryByText("sed")).toBeNull(); // 第 4 名被截断
  });

  it("timing undefined：骨架空态全「—」，不伪造数值", () => {
    const { container } = renderZ(<TimingCard />);
    expect(screen.getAllByText("—").length).toBeGreaterThanOrEqual(5); // 中心 + 5 行（1:1 重构后行结构）
    expect(screen.queryByText("1 分 5 秒")).toBeNull();
    expect(screen.queryByText("30 秒")).toBeNull();
    // 仅剩 track 圆环（骨架），无数据段
    expect(container.querySelectorAll("circle").length).toBe(1);
  });
});

// ─── SessionInfoCard ────────────────────────────────────────────

describe("SessionInfoCard", () => {
  it("行式键值直显五个字段", () => {
    renderZ(
      <SessionInfoCard sessionName="重构会话" space="办公空间" model="glm-5" window={128000} requests={42} />,
    );
    expect(screen.getByText("会话信息")).toBeTruthy();
    expect(screen.getByText("会话名")).toBeTruthy();
    expect(screen.getByText("重构会话")).toBeTruthy();
    expect(screen.getByText("办公空间")).toBeTruthy();
    expect(screen.getByText("glm-5")).toBeTruthy();
    expect(screen.getByText("128000")).toBeTruthy();
    expect(screen.getByText("42")).toBeTruthy();
  });
});

// ─── SummaryBar ─────────────────────────────────────────────────

describe("SummaryBar", () => {
  const requests = [REQ(1, 100, 100, 100), REQ(2, 100, 100, 100), REQ(3, 100, 100, 100)];

  it("单行拼装：会话徽标 + 水位 + 请求数 + 累计费用", () => {
    renderZ(<SummaryBar sessionName="重构会话" used={241800} window={1000000} requests={requests} costEstimate={3.83} />);
    expect(screen.getByText("重构会话")).toBeTruthy();
    expect(screen.getByText("241.8k / 1.0M · 24%")).toBeTruthy();
    expect(screen.getByText("3 次请求")).toBeTruthy();
    expect(screen.getByText("累计费用 ¥3.83")).toBeTruthy();
  });

  it("六分类图例 + 空闲窗口灰点；costEstimate 缺失显示「累计 —」", () => {
    renderZ(<SummaryBar sessionName="s" used={0} window={0} requests={[]} />);
    for (const label of ["系统提示词", "工具定义", "用户消息", "注入内容", "助手消息", "工具结果", "空闲窗口"]) {
      expect(screen.getByText(label)).toBeTruthy();
    }
    // v4.412 窗口未知（window=0）时百分比诚实「—」，不再伪造 0%
    expect(screen.getByText("0 / 0 · —")).toBeTruthy();
    expect(screen.getByText("0 次请求")).toBeTruthy();
    expect(screen.getByText("累计费用 —")).toBeTruthy();
  });
});

describe("costHoverTitle 2.5e 成本 hover", () => {
  const t = (k: string) => {
    const zh: Record<string, string> = {
      "contextview.costNoRate": "费用未估算",
      "contextview.costRateIn": "未缓存输入",
      "contextview.costRateOut": "输出",
      "contextview.costRateCache": "缓存命中",
      "contextview.costRateSource": "费率取自最近一次用量上报",
      "contextview.summaryCost": "累计费用",
    };
    return zh[k] ?? k;
  };

  it("有费率：输出三档明细 + 合计（USD 用 $）", () => {
    const title = costHoverTitle(
      { inputPer1M: 2, outputPer1M: 8, cacheHitPer1M: 0.5, currency: "CNY" },
      3.83,
      t,
    );
    expect(title).toContain("未缓存输入 ¥2 / 1M tok");
    expect(title).toContain("输出 ¥8 / 1M tok");
    expect(title).toContain("缓存命中 ¥0.5 / 1M tok");
    expect(title).toContain("累计费用 ¥3.83");
  });

  it("无费率：诚实说明费用未估算", () => {
    expect(costHoverTitle(undefined, undefined, t)).toBe("费用未估算");
    expect(costHoverTitle({}, undefined, t)).toBe("费用未估算");
  });
});

describe("TokenCard assistant 三拆（刀7）", () => {
  it("TokenCard 1:1 构成卡：传 current 时渲染 8 行三列（含思考/正文拆分）", () => {
    const stats = { turns: 1, steps: 1, injects: 0, compacts: 0, prunes: 0, toolCalls: 0, images: 0, assistantReasoning: 6000, assistantAnswerTokens: 3000, assistantCallTokens: 1000 };
    const current = { system: 100, tools: 200, user: 50, skill: 0, inject: 0, assistant: 10000, tool: 5000 };
    renderZ(<TokenCard requests={[REQ(1, 100, 200, 50)]} current={current} stats={stats} />);
    // 8 行齐全（思考/正文/工具调用三拆入构成行）
    expect(screen.getByText("助手思考")).toBeTruthy();
    expect(screen.getByText("助手正文")).toBeTruthy();
    expect(screen.getByText("工具调用")).toBeTruthy();
  });

  it("TokenCard 无 current 时回退缓存三类视图（向后兼容）", () => {
    renderZ(<TokenCard requests={[REQ(1, 300000, 5000, 1000), REQ(2, 100000, 5000, 2000)]} />);
    expect(screen.getByText("97.56%")).toBeTruthy();
  });
});
