/**
 * 图片生成 API
 * 封装所有后端图片调用，消除 (window as any)
 */

import type { GenResult } from '../components/imagegen/types'
import { app as bridgeApp } from '../gaea/lib/bridge'

// 三态回退（v4.58 wailsjsCompat 消费族模式）：?mock=1 下 window.go 刻意为空，
// wailsjsCompat 直调绕过 bridge mock——登记/清单读取统一经此 helper 走
// window.go.app.App 兼容代理 + bridgeApp mock 兜底（ImageHubAssets/
// ChapterArtList 已转正 AppBindings，mock 样例见 gaea/lib/mock/imagehub.ts）。
// T1 识图试用/创作资产追加：落盘 GaeaSavePastedImage、识图 GaeaRecognizeImage、
// OCR GaeaOCRText（mock 见 gaea/lib/mock/office.ts）、角色 CharacterList
// （mock 见 gaea/lib/mock/weixin.ts）——全部既有绑定，零新绑定。
type ImageHubFacade = {
  ImageHubAssets(space: string, sourceBoard: string, limit: number): Promise<Array<Record<string, unknown>>>
  ImageHubAssetDelete(space: string, path: string): Promise<Record<string, unknown>>
  ChapterArtList(chapterNum: number): Promise<Array<Record<string, unknown>>>
  AttachmentDataURL(path: string): Promise<string>
  SavePastedImage(dataUrl: string): Promise<string>
  ImageCutout(initImage: string, maskData: string): Promise<{ path?: string; asset_id?: string; error?: string }>
  RecognizeImage(imagePath: string, prompt: string): Promise<unknown>
  OCRText(imagePath: string): Promise<unknown>
  CharacterList(query: string, kind: string, chatOnly: boolean, page: number, pageSize: number):
    Promise<{ items?: Array<Record<string, unknown>>; total?: number }>
  // ── 图像域 legacy 直调族（v4.102 转正 AppBindings，此处统一走三态回退）──
  GenerateFreeImage(prompt: string, negative: string, size: string, initImage: string, model: string, seed: number, count: number, lora: string): Promise<{ error?: string; images?: Array<GenImageLike> }>
  CancelImageGeneration(): Promise<boolean>
  GenerateMedia(params: string): Promise<{ error?: string; results?: Array<GenImageLike>; mode?: string }>
  GenerateDiagram(prompt: string): Promise<{ error?: string; code?: string }>
  GetImageBackendInfo(): Promise<Partial<BackendInfo>>
  GetPortraitConfig(): Promise<{ backend?: string; model?: string }>
  SetPortraitConfig(backend: string, model: string): Promise<void>
  GetSinImageConfig(): Promise<{ backend?: string; model?: string }>
  SetSinImageConfig(backend: string, model: string): Promise<void>
  GetComfyUIStatus(): Promise<Record<string, unknown>>
  GetComfyUILoras(): Promise<Array<string>>
  GetComfyUITaskProgress(): Promise<Partial<ComfyTaskProgress>>
  StartComfyUI(): Promise<void>
  StopComfyUI(): Promise<void>
  WarmComfyUI(): Promise<{ started: boolean; reason?: string; model?: string }>
  GetSystemStats(): Promise<Partial<SystemStats>>
  OpenImageSaveDir(): Promise<void>
}
const appFacade = (): ImageHubFacade => (window.go?.app?.App ?? bridgeApp) as unknown as ImageHubFacade

export interface BackendInfo {
  backend: string
  model?: string
  image_model?: string
  comfyui_url?: string
  image_save_dir?: string
  comfyui_path?: string
  comfyui_python_path?: string
}

export interface SystemStats {
  cpu: number
  memTotal: number
  memUsed: number
  gpuName: string
  gpuUsage: number
  vramUsed: number
  vramTotal: number
}

export interface ComfyUIStatus {
  running: boolean
  port?: number
  url?: string
}

/** 后端返回的图片结果条目（动态载荷的最小消费面） */
interface GenImageLike {
  image?: string
  seed?: number
  time?: number
  prompt?: string
  model?: string
  size?: string
  kind?: string
  file_path?: string
  asset_id?: string
  parent_id?: string
}

/** 获取后端信息 */
export async function getImageBackendInfo(): Promise<BackendInfo> {
  const info = await appFacade().GetImageBackendInfo()
  return info as unknown as BackendInfo
}

/** 获取 ComfyUI 状态 */
export async function getComfyUIStatus(): Promise<ComfyUIStatus> {
  const s = await appFacade().GetComfyUIStatus()
  return s as unknown as ComfyUIStatus
}

/** 获取 ComfyUI 当前可用的 LoRA 列表（models/loras 相对路径，含子目录） */
export interface ComfyLorasResult {
  list: string[]
  error?: string
}

export async function getComfyUILoras(): Promise<ComfyLorasResult> {
  try {
    const list = await appFacade().GetComfyUILoras()
    return { list: Array.isArray(list) ? list : [] }
  } catch (e: unknown) {
    return { list: [], error: e instanceof Error ? e.message : 'LoRA 列表加载失败' }
  }
}

/** 数值收窄：绑定侧契约是 Partial<SystemStats>（缺字段/非数值都可能），统一收成有限数，缺省 0 */
function statNum(v: unknown): number {
  const n = typeof v === 'number' ? v : Number(v)
  return Number.isFinite(n) ? n : 0
}

/** 获取系统状态：Partial → 全字段归一化。此前缺字段直透消费方，ControlPanel 的
 *  memUsed.toFixed 等在字段缺失时抛 TypeError 整页崩进 ErrorBoundary（走查实证）。 */
export async function getSystemStats(): Promise<SystemStats | null> {
  try {
    const s = await appFacade().GetSystemStats()
    if (!s || typeof s !== 'object') return null
    const r = s as Partial<SystemStats>
    return {
      cpu: statNum(r.cpu),
      memTotal: statNum(r.memTotal),
      memUsed: statNum(r.memUsed),
      gpuName: typeof r.gpuName === 'string' ? r.gpuName : '',
      gpuUsage: statNum(r.gpuUsage),
      vramUsed: statNum(r.vramUsed),
      vramTotal: statNum(r.vramTotal),
    }
  } catch (_) {
    return null
  }
}

/** 获取角色库剧照独立后端/模型（空 = 跟随绘梦） */
export async function getPortraitConfig(): Promise<{ backend: string; model: string }> {
  try {
    const r = await appFacade().GetPortraitConfig()
    return (r || { backend: '', model: '' }) as { backend: string; model: string }
  } catch (_) {
    return { backend: '', model: '' }
  }
}

/** 设置角色库剧照独立后端/模型（空 = 跟随绘梦） */
export async function setPortraitConfig(backend: string, model: string): Promise<void> {
  await appFacade().SetPortraitConfig(backend, model)
}

/** 获取原罪插图独立生图后端/模型（空 = 跟随全局生图设置） */
export async function getSinImageConfig(): Promise<{ backend: string; model: string }> {
  try {
    const r = await appFacade().GetSinImageConfig()
    return (r || { backend: '', model: '' }) as { backend: string; model: string }
  } catch (_) {
    return { backend: '', model: '' }
  }
}

/** 设置原罪插图独立生图后端/模型（空 = 跟随全局生图设置） */
export async function setSinImageConfig(backend: string, model: string): Promise<void> {
  await appFacade().SetSinImageConfig(backend, model)
}

/** 生成图片 */
export async function generateImage(
  prompt: string, negative: string, size: string,
  model: string, seed: number, count: number,
  lora?: string,
): Promise<{ error?: string; images?: GenResult[] }> {
  const res = await appFacade().GenerateFreeImage(prompt.trim(), negative.trim(), size, '', model, seed, count, lora || '')
  if (res?.error) return { error: res.error }
  if (res?.images?.length) {
    const images: GenResult[] = res.images.map((img: GenImageLike) => ({
      image: img.image as string, seed: img.seed as number, time: img.time as number,
      prompt: img.prompt || prompt, model: img.model || model,
      size: img.size || size, negative: negative,
      file_path: img.file_path || undefined,
    }))
    return { images }
  }
  return {}
}

/** 取消当前正在执行的图片/视频生成任务 */
export async function cancelImageGeneration(): Promise<boolean> {
  return appFacade().CancelImageGeneration()
}

/**
 * 通过后端文件读取绑定把本地路径转为 data URL（历史图片恢复 / 下载 / 剧照）。
 * 复用现有 GaeaAttachmentDataURL（OfficeB 门面），不新增绑定。
 *
 * v4.257.1 修复：历史实现直连 `window.go.app.App.AttachmentDataURL`（S2-3 兼容
 * 代理）——该代理只认字面名，真机下 Go 方法名是 GaeaAttachmentDataURL，
 * 于是必抛「e(...).AttachmentDataURL is not a function」（原罪插图、章节配图
 * 历史缩略图都会中招）。规范路径改走 bridge 代理（按 gaeaToGaea 映射 + mock
 * 兜底）；只有 bridge 上确实没有这个方法时才退回旧直连形态。
 */
export async function readFileAsDataURL(path: string): Promise<string> {
  const viaBridge = bridgeApp.AttachmentDataURL
  if (typeof viaBridge === 'function') return viaBridge.call(bridgeApp, path)
  // bridge 未认领（极端环境）：退回旧直连形态（兼容代理已补映射，见 bridge/http.ts）
  return appFacade().AttachmentDataURL(path)
}

/** 图像域登记视图（ImageHubAssets 绑定，T1 画室素材库）。 */
export interface ImageHubAssetView {
  id?: string
  kind?: string
  path?: string
  mime?: string
  space?: string
  source_board?: string
  capability?: string
  backend?: string
  model?: string
  cost?: string
  created_at?: string
  prompt_truncate?: string
  params?: Record<string, unknown>
  /** 变体簇（阶段二刀 D）：源图条目 id（A→A' 同源链）；空=非派生产物 */
  parent_id?: string
}

/** 章节插图清单条目（ChapterArtList 绑定，T1）。 */
export interface ChapterArtEntry {
  chapter?: number
  asset_id?: string
  path?: string
  created_at?: string
}

/** 画室素材读取：按空间/来源筛选（失败 = 空列表，登记是辅助视图）。 */
export async function imageHubAssets(space: string, sourceBoard: string, limit: number): Promise<ImageHubAssetView[]> {
  try {
    const res = await appFacade().ImageHubAssets(space, sourceBoard, limit)
    return Array.isArray(res) ? res as unknown as ImageHubAssetView[] : []
  } catch (_) {
    return []
  }
}

/** 素材库删除（v4.502）：删盘上文件+移除该空间台账登记；登记守卫在 Go 侧
 * （未登记路径拒绝）。失败/异常统一落 error 键，由视图呈现。 */
export async function deleteImageHubAsset(
  space: string,
  path: string,
): Promise<{ ok?: boolean; file_removed?: boolean; removed_entries?: number; error?: string }> {
  try {
    const res = await appFacade().ImageHubAssetDelete(space, path)
    return (res && typeof res === 'object' ? res : {}) as { ok?: boolean; file_removed?: boolean; removed_entries?: number; error?: string }
  } catch (err: unknown) {
    return { error: err instanceof Error ? err.message : String(err) }
  }
}

/** 章节插图清单读取（失败 = 空列表，不阻断主流程）。 */
export async function chapterArtList(chapterNum: number): Promise<ChapterArtEntry[]> {
  try {
    const res = await appFacade().ChapterArtList(chapterNum)
    return Array.isArray(res) ? res as unknown as ChapterArtEntry[] : []
  } catch (_) {
    return []
  }
}

// ── T1 识图「读/懂」画室试用（零新绑定，原语 vision.read / vision.understand）──

/**
 * 粘贴/选择的图片落盘（GaeaSavePastedImage），返回可传给识图原语的本地路径。
 * 失败向上抛，由调用方诚实呈现错误原文。
 */
export async function savePastedImage(dataUrl: string): Promise<string> {
  return appFacade().SavePastedImage(dataUrl)
}

/** 识图调用结果规范视图：文本必给，模型名仅当返回里确实携带时才有。 */
export interface VisionCallResult {
  text: string
  model?: string
}

/** 归一化识图返回：字符串直取；对象按 text/content/description 取文本、model 取模型名。 */
function normalizeVisionResult(raw: unknown): VisionCallResult {
  if (typeof raw === 'string') return { text: raw }
  if (raw && typeof raw === 'object') {
    const o = raw as Record<string, unknown>
    const text = [o.text, o.content, o.description].find((v): v is string => typeof v === 'string')
    const model = typeof o.model === 'string' ? o.model : undefined
    if (text !== undefined) return { text, model }
    return { text: JSON.stringify(o), model }
  }
  return { text: String(raw ?? '') }
}

/** 识图-懂（GaeaRecognizeImage）：内容理解/描述，prompt 由调用方自填。 */
export async function visionUnderstand(imagePath: string, prompt: string): Promise<VisionCallResult> {
  return normalizeVisionResult(await appFacade().RecognizeImage(imagePath, prompt))
}

/** 识图-读（GaeaOCRText）：提取图内文字。 */
export async function visionRead(imagePath: string): Promise<VisionCallResult> {
  return normalizeVisionResult(await appFacade().OCRText(imagePath))
}

// ── T1 创作资产 · 角色槽（CharacterList 只读分页，零新绑定）──

/** 可聊天角色卡最小消费面（对齐 characterlib.Character 的展示字段）。 */
export interface ChatCharacterView {
  id?: string
  name?: string
  kind?: string
  gender?: string
  tags?: string[]
  portraitUrl?: string
  roleType?: string
  personality?: string
  background?: string
  appearance?: string
  referenceImages?: string[]
}

/** 分页拉取可聊天角色（chatOnly=true；失败 = 空列表，浏览是辅助视图）。 */
export async function chatCharacters(page: number, pageSize: number):
  Promise<{ items: ChatCharacterView[]; total: number }> {
  try {
    const res = await appFacade().CharacterList('', '', true, page, pageSize)
    const items = Array.isArray(res?.items)
      ? res.items as unknown as ChatCharacterView[]
      : []
    return { items, total: typeof res?.total === 'number' ? res.total : items.length }
  } catch (_) {
    return { items: [], total: 0 }
  }
}

// ── T1 画室「模型目录」创作语境视图（HerdsmanModelCatalog 只读，零新绑定）──
// HerdsmanModelCatalog 与 Get/SetEngineFailover 同为 legacy 绑定面（挂在后端
// ModelB 门面；模型中心「模型库」段经 api/engines.ts 消费同名绑定）。这里按
export interface ComfyTaskProgress {
  status: string
  elapsed: number
  /** 0-100 实时进度；-1/缺省 = 未知（未接入 ComfyUI 实时进度） */
  percent?: number
  /** 当前执行节点 class_type（如 KSampler / CLIPLoader） */
  node?: string
}

/** 获取当前 ComfyUI 任务状态（前端轮询显示） */
export async function getComfyUITaskProgress(): Promise<ComfyTaskProgress> {
  const p = await appFacade().GetComfyUITaskProgress()
  return (p || { status: '', elapsed: 0 }) as ComfyTaskProgress
}

/** 生成流程图/框架图：LLM 返回 Mermaid 代码，前端渲染为 PNG */
export async function generateDiagram(
  prompt: string,
): Promise<{ error?: string; code?: string }> {
  const res = await appFacade().GenerateDiagram(prompt.trim())
  return (res || {}) as { error?: string; code?: string }
}

/** 多模式媒体生成参数（文生图 / 图生图 / 文生视频） */
export interface MediaParams {
  prompt: string
  negative: string
  size: string
  model: string
  seed: number
  lora: string
  count: number
  mode: 'txt2img' | 'img2img' | 'edit' | 'outpaint' | 't2v'
  initImage?: string
  /** 蒙版局部重绘（阶段二刀 B）：灰度 PNG data URL，白=重绘区；仅 mode='edit' 消费 */
  mask?: string
  /** 扩图（阶段二刀 C）：四边扩展百分比（0-200，相对原图对应边长）；仅 mode='outpaint' */
  expand?: { left: number; top: number; right: number; bottom: number }
  /** 编辑源图落盘路径（阶段二刀 D 变体簇）：后端按 path 关联台账 ParentID */
  sourcePath?: string
  denoise?: number
  frames?: number
  fps?: number
  /** T2 角色参考槽：角色 ID 与参考图列表（data URL；首张作图生图种子） */
  characterId?: string
  refImages?: string[]
  refMethod?: string
}

/** 多模式媒体生成（绘梦页：图生图 / 文生视频） */
export async function generateMedia(
  params: MediaParams,
): Promise<{ error?: string; results?: GenResult[]; mode?: string }> {
  const res = await appFacade().GenerateMedia(JSON.stringify(params))
  if (res?.error) return { error: res.error }
  if (res?.results?.length) {
    const results: GenResult[] = res.results.map((img: GenImageLike) => ({
      image: img.image as string,
      seed: img.seed as number,
      time: img.time as number,
      prompt: img.prompt || params.prompt,
      model: img.model || params.model,
      size: img.size || params.size,
      negative: params.negative,
      kind: (img.kind || 'image') as 'image' | 'video',
      file_path: img.file_path || undefined,
      asset_id: img.asset_id || undefined,
      parent_id: img.parent_id || undefined,
    }))
    return { results, mode: res.mode }
  }
  return {}
}

/** 启动 ComfyUI */
/** 启动 ComfyUI */
export async function startComfyUI(): Promise<void> {
  await appFacade().StartComfyUI()
}

/**
 * CU1 绘梦页首入预热：后端提交一次 64×64 极小空跑把默认模型预加载进显存。
 * 静默语义：任何失败/跳过都返回 {started:false, reason}，绝不抛错打扰用户。
 */
export async function warmComfyUI(): Promise<{ started: boolean; reason?: string; model?: string }> {
  try {
    return await appFacade().WarmComfyUI()
  } catch {
    return { started: false, reason: 'unavailable' }
  }
}

/** 停止 ComfyUI */
export async function stopComfyUI(): Promise<void> {
  await appFacade().StopComfyUI()
}

/** 打开图片保存目录 */
export async function openImageSaveDir(): Promise<void> {
  await appFacade().OpenImageSaveDir()
}

/** 抠图/透明底导出（阶段二刀 E，T3 收官）：涂选保留主体（蒙版白=保留）→
 * 透明 PNG 落盘 ImageSaveDir+台账登记，返回路径与资产 id。零模型调用。 */
export async function imageCutout(initImage: string, maskData: string): Promise<{ path?: string; asset_id?: string; error?: string }> {
  const r = await appFacade().ImageCutout(initImage, maskData)
  return r ?? {}
}
