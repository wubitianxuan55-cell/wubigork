/**
 * 模型引擎 API
 * 封装所有模型引擎后端调用
 */

// ── 类型定义 ────────────────────────────────────────────────

export interface ModelInfo {
  id: string
  /** 展示名（可选）：后端 /models 下发或由 ID 解析（如 Model Hub 的
   *  tinyrick/Qwen3.8-…:Q6_K_P）；缺省时前端回退显示 id */
  name?: string
  owned_by: string
  status: string
  kind?: string // 后端分类：llm / tts / stt / image / embedding / rerank / ocr
  alias_of?: string // coding 端点家族下服务端实际服务的模型（套餐旧名自动切换）；std 家族为空（Go modelengine.ModelInfo.AliasOf）
  // ── B 刀：模型元数据（全可选；缺失=目录未下发该字段，前端徽标不占位） ──
  context_length?: number // 上下文窗口（tokens 绝对值，如 1000000=1M）
  max_output?: number // 最大输出 tokens
  price_in?: number // 输入单价；unit 空时=每百万 tokens，unit 非空时=单价
  price_out?: number // 输出单价（口径同上）
  currency?: 'CNY' | 'USD' // 计价币种（空=未计价）
  unit?: '' | 'call' | 'minute' // 计价单位：空=每百万 tokens；call=按次；minute=按分钟
  free?: boolean // 官方免费标记
  caps?: string[] // 能力标签：vision / tools / reasoning / search / json
  price_note?: string // 价格备注（如「促销价」「以官网为准」）
  points_in?: number // GLM coding 套餐积分系数：输入（积分=(输入×in+缓存×cached+输出×out)/10000）
  points_cached?: number // 积分系数：缓存命中输入
  points_out?: number // 积分系数：输出
  points_peak?: number // 积分系数：峰值时段（前端估算暂不使用，仅透传）
}

export interface EngineConfig {
  id: string
  name: string
  // custom = 用户自建 OpenAI 兼容服务商（A 刀），id 以 custom- 开头
  // strata = 本地 Strata 推理引擎（默认 127.0.0.1:8091/v1，
  // 免鉴权；离线模式按本地引擎放行；档位目录现仅 uncensored 一档）
  // whirl = 本地 WHIRL 推理引擎（Windows HIP，127.0.0.1:8126/v1，免鉴权；
  // 档位 qwen35_whirl 服务 35B whirlfix2，与 llama 同模型的 1.91x 快路径）
  type: 'xai' | 'herdsman' | 'deepseek' | 'glm' | 'breeze' | 'opencode-go' | 'custom' | 'strata' | 'llama' | 'whirl'
  label?: string
  color?: string
  icon?: string
  is_local?: boolean
  base_url: string
  enabled: boolean
  default_model: string
  models: ModelInfo[]
  status?: EngineStatus
  // ── 价目 v1（自定义引擎用户价目）：引擎级统一价，每百万 tokens，币种 CNY ──
  // 读取侧 undefined = 未设置（后端 *float64 nil + omitempty）；保存侧经
  // SaveEngine 传数字 = 设置（0 = 清除 = 不计价），缺省（undefined/null）=
  // 不修改——地址框/启停等局部保存不会误清除价目（Go 侧指针三态合并）。
  // 费用折算优先消费用户价目（stats.estimatePrice 最高优先层），无价目时
  // 行为与现状完全一致（0 = 未填 = 不计价）。
  user_price_in?: number | null // 输入单价（¥/百万 tokens）
  user_price_out?: number | null // 输出单价（¥/百万 tokens）
}
export interface EngineStatus {
  id: string
  connected: boolean
  model_count: number
  /** 连续 ≥3 次巡检失败时后端带「连续 N 次探测失败」前缀（C 刀） */
  error: string
  last_checked?: string
  latency_ms?: number
}

export interface ModelUsageStats {
  engine_id: string
  model: string
  call_count: number
  success_count: number
  fail_count: number
  input_tokens: number
  output_tokens: number
  total_tokens: number
  cache_hit_tokens?: number // KV 缓存命中 prompt token（coding 积分估算用，未上报时缺省）
  total_duration_ms: number
  estimated_cost?: number
  currency?: string
  billing_mode?: string // 计费口径："coding_points"=GLM 编码套餐积分内调用（费用恒 0 不入总额）；空=按量计费（Go modelengine.BillingCodingPoints）
  last_error?: string
  last_called_at?: string
}

/** 按引擎聚合小计（ModelStatsSummary.engines 的值，Go modelengine.EngineSubtotal） */
export interface EngineSubtotal {
  tokens: number
  calls: number
  estimated_cost_cny: number
}

export interface TrendPoint {
  time: string
  calls: number
  success_calls: number
  fail_calls: number
  input_tokens: number
  output_tokens: number
  total_tokens: number
  cost: number
}

export interface ModelStatsSummary {
  total_calls: number
  success_calls: number
  fail_calls: number
  total_tokens: number
  input_tokens: number
  output_tokens: number
  total_duration_ms: number
  avg_duration_ms: number
  total_cost: number
  trend: TrendPoint[]
  per_model: ModelUsageStats[]
  engines?: Record<string, EngineSubtotal> // 按引擎聚合小计（编码套餐口径以 "<engine>@coding" 单列、费用 0）；旧 stats.json 无此字段
  since?: string
  usd_to_cny?: number
  catalog_version?: string // B 刀：价格目录版本（估算费用/积分系数依据，旧 stats.json 无此字段）
  catalog_source?: string // 价格目录来源（如 bigmodel）
}

/** Herdsman 模型库条目（来自 herdsman skill models list） */
export interface HerdsmanCatalogModel {
  name: string
  display_name: string
  type: string
  runtime: string
  inference_engines?: string[]
  capabilities?: string[]
  installed: boolean
  running: boolean
  status: string
  run_status?: string
  quantization?: string
  parameter_count?: number
  active_parameters?: number
  is_moe?: boolean
  file_size?: number
  llama_cpp_variants?: string[]
  /** 用途建议（后端按受控测评结论生成，如「日常对话/识图首选」） */
  hint?: string
}

export interface HerdsmanCatalog {
  models: HerdsmanCatalogModel[]
  total: number
  installed: number
  running: number
  source: string
  error?: string
  /** 已装模型占用（字节，E1-4 磁盘治理） */
  installed_bytes?: number
  /** 数据目录所在卷总量（字节） */
  disk_total?: number
  /** 数据目录所在卷余量（字节） */
  disk_free?: number
  disk_error?: string
}

/** Herdsman 生命周期操作结果 */
export interface HerdsmanOpResult {
  ok: boolean
  status: string
  message: string
}

/** 某模型在本机的实测启动参数（launch_records） */
export interface HerdsmanLaunchPreset {
  model: string
  engine: string
  port: number
  started_at: string
  options: Record<string, unknown>
}

/** Herdsman 单模型调用聚合（来自 model_stats/events.jsonl） */
export interface HerdsmanModelStat {
  model: string
  type: string
  runtime: string
  calls: number
  succeeded: number
  failed: number
  input_tokens: number
  output_tokens: number
  total_duration_ms: number
  avg_duration_ms: number
  avg_ttft_ms: number
  avg_prompt_tps: number
  avg_predicted_tps: number
  last_called_at: string
}

export interface HerdsmanModelStats {
  total: number
  since: string
  per_model: HerdsmanModelStat[]
  source: string
  error?: string
}

// ── 阶段 3 D3-2 分流统计（本地 vs 云端） ───────────────────

export interface UsageSide {
  calls: number
  success_calls: number
  fail_calls: number
  input_tokens: number
  output_tokens: number
  total_tokens: number
  cache_hit_tokens?: number
  cache_miss_tokens?: number
  total_duration_ms: number
  cost: number
  engines: string[]
}

export interface SavingsView {
  ref_price_per_mtok: number
  would_cost_cloud: number
  saved: number
  note: string
}

export interface UsageOverview {
  cloud: UsageSide
  local: UsageSide
  savings: SavingsView
  cache_hit_tokens?: number
  cache_miss_tokens?: number
  cache_hit_rate?: number
}

// ── 阶段 3 D3-3 Herdsman 受控测评 ──────────────────────────

export interface BenchmarkSummary {
  total_cases: number
  succeeded: number
  failed: number
  canceled: number
  avg_duration_ms: number
  avg_ttft_ms: number
  avg_tps: number
}

export interface BenchmarkRunSummary {
  id: string
  created_at: string
  finished_at?: string
  status: string
  model_names: string[]
  variants: string[]
  context_sizes: number[]
  summary?: BenchmarkSummary
}

export interface BenchmarkPromptRequest {
  user_prompt: string
  temperature: number
  top_p: number
  top_k: number
  repeat_penalty: number
  max_tokens: number
  stream: boolean
  timeout_seconds: number
}

export interface BenchmarkRequest {
  model_names: string[]
  variants: string[]
  context_sizes: number[]
  cache_reuse_mode: string
  warmup_count: number
  repeat_count: number
  concurrency: number
  request: BenchmarkPromptRequest
}

/** 流式探针结果（D3-4 断流/卡顿观察） */
export interface StreamProbeResult {
  model: string
  ok: boolean
  ttft_ms: number
  chunks: number
  tokens: number
  duration_ms: number
  max_gap_ms: number
  avg_gap_ms: number
  completed: boolean
  interrupted: boolean
  error?: string
  response_start?: string
}

// ── 阶段七 7.1-2 路由学习：成本归因账本 + 改绑建议（模型中心「成本归因」tab） ──

/** 功能维度用量汇总（RouteLedgerView.features 元素；一行 = feature×引擎×模型桶） */
export interface FeatureUsageSummary {
  feature: string // 功能绑定键（chat/office/...；空串 = 历史/未标记）
  engine_id: string
  model: string
  calls: number
  tokens_in: number
  tokens_out: number
  cost_cny: number // 估算成本（既有 EstimateCostCNY 口径；本地引擎恒 0 属实呈现）
  avg_ms: number
  success_rate: number // 0-1
}

/** 归因账本总览（口径同 FeatureUsageSummary 的全量汇总） */
export interface RouteLedgerTotal {
  calls: number
  tokens_in: number
  tokens_out: number
  cost_cny: number
  avg_ms: number
  success_rate: number // 0-1
}

export interface RouteLedgerView {
  generated_at: string
  total: RouteLedgerTotal
  features: FeatureUsageSummary[]
}

/** 建议端点（from / to 共用基础形状） */
export interface RouteEndpoint {
  engine_id: string
  model: string
}

/** 建议目标端（to）：在端点之上附本地/云端与评分证据 */
export interface RouteSuggestionTarget extends RouteEndpoint {
  is_local: boolean
  success_rate?: number // 0-1；无样本时缺省（无样本不给建议）
  cost_cny: number
}

export interface RouteSuggestion {
  id: string // 确定性 ID：feature:fromEngine/fromModel>toEngine/toModel
  feature: string
  reason: string
  evidence: string
  from: RouteEndpoint
  to: RouteSuggestionTarget
  score_gap: number // 候选 score − 当前绑定 score（≥0.25 才出建议）
}

export interface RouteSuggestionsView {
  generated_at: string
  suggestions: RouteSuggestion[]
}

// ── API 函数 ─────────────────────────────────────────────────

import type { AppFacade } from '../types/wails'
// 纯浏览器 dev mock（?mock=1）下 window.go 刻意为空（mock-scenarios 锁定断言，
// 不得往 window.go 挂对象，否则 realApp 劫持 app 代理使 mock 兜底失效）；
// 此处回退 bridge 的 app 代理（realApp 优先、shell 外落 mock），让 mock 绑定面
// 已实现的调度方法（Get/SetEngineFailover）在浏览器走查可用；mock 未实现的方法
// 与原先一样抛 TypeError，走各调用方既有的 catch 降级路径，行为不变。
import { app as bridgeApp } from '../gaea/lib/bridge'

const App = (): AppFacade => (window.go?.app?.App ?? bridgeApp) as unknown as AppFacade

// ── 外部本地引擎进程生命周期（strata_proc.go / qwen35_proc.go） ──

export interface EngineProfileOption {
  id: string
  label: string
}

export interface ManagedEngineStatusResult {
  running: boolean
  port?: number
  served_models?: string[]
  profile?: string
  default_profile?: string
  profiles?: EngineProfileOption[]
  project?: string
  serve_script?: string
  config?: string
  other?: string
  stdout_log?: string
  stderr_log?: string
}

export interface ManagedEngineStartResult {
  started: boolean
  reason?: string // already-running / port-occupied / project-not-found / python-not-found / serve-script-not-found / config-not-found / exited-early / timeout / spawn-failed
  waited_ms?: number
  served_models?: string[]
  profile?: string
  model?: string
  profiles?: EngineProfileOption[]
  project?: string
  serve_script?: string
  config?: string
  other?: string
  stdout_log?: string
  stderr_log?: string
  log?: string
  error?: string
}

export interface ManagedEngineStopResult {
  stopped: boolean
  reason?: string
}


// ── 自管 Llama 引擎（8124，Qwen3.6-35B / Gemma 4 E4B 档位） ──
export type LlamaEngineStatusResult = ManagedEngineStatusResult
export type LlamaEngineStartResult = ManagedEngineStartResult
export type LlamaEngineStopResult = ManagedEngineStopResult

export async function getLlamaEngineStatus(): Promise<LlamaEngineStatusResult> {
  const result = await App().Qwen35EngineStatus()
  return result as LlamaEngineStatusResult
}

export async function startLlamaEngine(profile: string): Promise<LlamaEngineStartResult> {
  const result = await App().Qwen35EngineStart(profile)
  return result as LlamaEngineStartResult
}

export async function stopLlamaEngine(): Promise<LlamaEngineStopResult> {
  const result = await App().Qwen35EngineStop()
  return result as LlamaEngineStopResult
}

/** Strata 引擎运行状态（8091 /v1/models 探活） */
export async function getStrataEngineStatus(): Promise<ManagedEngineStatusResult> {
  const result = await App().StrataEngineStatus()
  return result as ManagedEngineStatusResult
}

/** 启动 Strata 指定档位（现阶段仅 qwen38fn_flash 一档；幂等） */
export async function startStrataEngine(profile: string): Promise<ManagedEngineStartResult> {
  const result = await App().StrataEngineStart(profile)
  return result as ManagedEngineStartResult
}

/** 停止 Strata 引擎（不管谁启动的都能停；空闲时调用） */
export async function stopStrataEngine(): Promise<ManagedEngineStopResult> {
  const result = await App().StrataEngineStop()
  return result as ManagedEngineStopResult
}

// ── 自管 WHIRL 引擎（8126，Windows HIP 推理；档位 qwen35_whirl） ──
// 启动走受管目录通用路径（EngineCard/managed catalog），前端无专属包装——
// 曾有 startWhirlEngine 死包装随 knip 清账退役（Go WhirlEngineStart 绑定保留）。
export type WhirlEngineStatusResult = ManagedEngineStatusResult
export type WhirlEngineStopResult = ManagedEngineStopResult

/** WHIRL 引擎运行状态（8126 /v1/models 探活 + gguf/bin 在位诊断） */
export async function getWhirlEngineStatus(): Promise<WhirlEngineStatusResult> {
  const result = await App().WhirlEngineStatus()
  return result as WhirlEngineStatusResult
}

/** 停止 WHIRL 引擎（不管谁启动的都能停） */
export async function stopWhirlEngine(): Promise<WhirlEngineStopResult> {
  const result = await App().WhirlEngineStop()
  return result as WhirlEngineStopResult
}

// ── 受管引擎官方版本检查（Strata / llama / WHIRL；GitHub releases/latest） ──
export interface EngineUpdateCheckResult {
  engine: string
  local_version: string
  latest_version: string
  latest_name?: string
  release_url?: string
  has_update: boolean
  checked_at: string
  error?: string
}

/** 检查单个引擎的官方最新版本（后端 30 分钟缓存；只告知不自动升级） */
export async function checkEngineUpdate(engineID: string): Promise<EngineUpdateCheckResult> {
  const result = await App().EngineUpdateCheck(engineID)
  return result as EngineUpdateCheckResult
}

/** 获取所有引擎配置 */
export async function getEngines(): Promise<EngineConfig[]> {
  const result = await App().GetEngines()
  return result as EngineConfig[]
}

/** 模型量化档位适用面标注（阶段十 10.2；无标记返回空串） */
export async function getQuantSuitability(model: string): Promise<string> {
  const result = await App().QuantSuitability(model)
  return typeof result === 'string' ? result : ''
}

/** 本地资源占用遥测（模型中心资源条 / 右舷内核状态 / 首页矩阵共用）。
 *  必须经 App()（window.go.app.App 兼容代理 + bridgeApp mock 兜底）——
 *  wailsjsCompat 直调 window.go.app.ModelB 会绕过 bridge mock，
 *  ?mock=1 浏览器走查报「资源加载失败」（v4.55 同族教训）。 */
export async function getModelMonitor(): Promise<unknown> {
  const result = await App().GetModelMonitor()
  return result
}

/** 运行监测聚合快照（「运行监测」板块；同上必须经 App() 兼容代理）。 */
export async function getRuntimeMonitor(): Promise<unknown> {
  const result = await App().RuntimeMonitor()
  return result
}

/** 保存引擎配置 */
export async function saveEngine(cfg: EngineConfig): Promise<void> {
  await App().SaveEngine(cfg)
}

/** 添加自定义引擎（OpenAI 兼容，type=custom），返回引擎 ID（custom-*） */
export async function addCustomEngine(name: string, baseURL: string, apiKey: string): Promise<string> {
  const result = await App().AddCustomEngine(name, baseURL, apiKey)
  return result as string
}

/** 更新自定义引擎（apiKey 空串 = 不修改 Key） */
export async function updateCustomEngine(engineID: string, name: string, baseURL: string, apiKey: string): Promise<void> {
  await App().UpdateCustomEngine(engineID, name, baseURL, apiKey)
}

/** 删除自定义引擎（连同其功能绑定能力） */
export async function removeCustomEngine(engineID: string): Promise<void> {
  await App().RemoveCustomEngine(engineID)
}

/** 测试引擎连接 */
export async function testEngineConnection(engineID: string): Promise<EngineStatus> {
  const result = await App().TestEngineConnection(engineID)
  return result as EngineStatus
}

/** 刷新引擎模型列表 */
export async function refreshEngineModels(engineID: string): Promise<ModelInfo[]> {
  const result = await App().RefreshEngineModels(engineID)
  return result as ModelInfo[]
}

/** 设置引擎默认模型 */
export async function setEngineDefaultModel(engineID: string, modelName: string): Promise<void> {
  await App().SetEngineDefaultModel(engineID, modelName)
}

/** 切换活跃引擎 */
export async function setActiveEngine(engineID: string): Promise<void> {
  await App().SetActiveEngine(engineID)
}

/** 设置办公「提取文字」使用的 OCR 引擎与模型 */
export async function setActiveOCRModel(engineID: string, modelID: string): Promise<void> {
  await App().SetActiveOCRModel(engineID, modelID)
}

/** 获取当前 OCR 激活模型（空=自动选择） */
export async function getActiveOCRModel(): Promise<{ engine: string; model: string }> {
  const result = await App().GetActiveOCRModel()
  return result as { engine: string; model: string }
}

/** 获取当前活跃引擎 */
export async function getActiveEngine(): Promise<string> {
  const result = await App().GetActiveEngine()
  return result as string
}

/** 设置 DeepSeek API Key */
export async function setDeepseekKey(apiKey: string): Promise<void> {
  await App().SetDeepseekKey(apiKey)
}

/** 获取 DeepSeek Key 状态（脱敏显示） */
export async function getDeepseekKeyStatus(): Promise<{ configured: boolean; masked: string }> {
  const result = await App().GetDeepseekKeyStatus()
  return result as { configured: boolean; masked: string }
}

/** 设置 GLM (智谱) API Key */
export async function setGlmKey(apiKey: string): Promise<void> {
  await App().SetGlmKey(apiKey)
}

/** 设置 GLM 端点家族（std=标准按量付费 / coding=编码套餐额度；官方双端点） */
export async function setGlmEndpoint(family: 'std' | 'coding'): Promise<void> {
  await App().SetGlmEndpoint(family)
}

/** 获取 GLM Key 状态（脱敏显示） */
export async function getGlmKeyStatus(): Promise<{ configured: boolean; masked: string }> {
  const result = await App().GetGlmKeyStatus()
  return result as { configured: boolean; masked: string }
}

/** 设置 OpenCode Go API Key */
export async function setOpencodeGoKey(apiKey: string): Promise<void> {
  await App().SetOpencodeGoKey(apiKey)
}

/** 获取 OpenCode Go Key 状态（脱敏显示） */
export async function getOpencodeGoKeyStatus(): Promise<{ configured: boolean; masked: string }> {
  const result = await App().GetOpencodeGoKeyStatus()
  return result as { configured: boolean; masked: string }
}

/** 获取模型调用统计汇总 */
export async function getModelCallStats(): Promise<ModelStatsSummary> {
  const result = await App().GetModelCallStats()
  return result as ModelStatsSummary
}

/** 获取成本归因账本（阶段七 7.1-2：按功能绑定键聚合的用量/成本/成功率视图） */
export async function getRouteLedger(): Promise<RouteLedgerView> {
  const result = await App().GaeaRouteLedger()
  return result as RouteLedgerView
}

/** 获取改绑建议（后端现算 + 合并忽略表；评分差超阈值才出现） */
export async function getRouteSuggestions(): Promise<RouteSuggestionsView> {
  const result = await App().GaeaRouteSuggestions()
  return result as RouteSuggestionsView
}

/** 采纳一条改绑建议（后端内部经 SetFeatureModel 即时重建；绑定面靠既有
 *  feature-model-changed 事件自动刷新，前端无需手动刷绑定区） */
export async function applyRouteSuggestion(id: string): Promise<void> {
  await App().GaeaRouteSuggestionApply(id)
}

/** 忽略一条改绑建议（写忽略状态，被忽略建议不再出现） */
export async function ignoreRouteSuggestion(id: string): Promise<void> {
  await App().GaeaRouteSuggestionIgnore(id)
}

/** 获取美元→人民币汇率（费用估算折算用，默认 7.2；T6-6.2） */
export async function getUsdCnyRate(): Promise<number> {
  const result = await App().GaeaGetUsdCnyRate()
  return result as number
}

/** 设置美元→人民币汇率（持久化到 usd_cny_rate 并即时生效；T6-6.2） */
export async function setUsdCnyRate(rate: number): Promise<void> {
  await App().GaeaSetUsdCnyRate(rate)
}

/** 获取 Herdsman 完整模型目录（模型中心「模型库」） */
export async function getHerdsmanCatalog(): Promise<HerdsmanCatalog> {
  const result = await App().HerdsmanModelCatalog()
  return result as HerdsmanCatalog
}

/** 获取 Herdsman 完整模型目录（模型中心「模型库」） */
export async function getHerdsmanLaunchPresets(): Promise<HerdsmanLaunchPreset[]> {
  const result = await App().HerdsmanLaunchPresets()
  return result as HerdsmanLaunchPreset[]
}

/** 获取 Herdsman 本地调用统计（model_stats/events.jsonl 聚合） */
export async function getHerdsmanModelStats(): Promise<HerdsmanModelStats> {
  const result = await App().HerdsmanModelStats()
  return result as HerdsmanModelStats
}

/** 启动 Herdsman 模型（等冷启动完成） */
export async function startHerdsmanModel(model: string): Promise<HerdsmanOpResult> {
  const result = await App().HerdsmanModelStart(model)
  return result as HerdsmanOpResult
}

/** 停止 Herdsman 模型 */
export async function stopHerdsmanModel(model: string): Promise<HerdsmanOpResult> {
  const result = await App().HerdsmanModelStop(model)
  return result as HerdsmanOpResult
}

/** 下载 Herdsman 模型（等安装完成） */
export async function downloadHerdsmanModel(model: string): Promise<HerdsmanOpResult> {
  const result = await App().HerdsmanModelDownload(model)
  return result as HerdsmanOpResult
}

/** 卸载 Herdsman 模型 */
export async function uninstallHerdsmanModel(model: string): Promise<HerdsmanOpResult> {
  const result = await App().HerdsmanModelUninstall(model)
  return result as HerdsmanOpResult
}

/** 重置模型调用统计 */
export async function resetModelCallStats(): Promise<void> {
  await App().ResetModelCallStats()
}

/** 分流统计总览（本地 vs 云端 + 节省对比，D3-2） */
export async function getUsageOverview(): Promise<UsageOverview> {
  const result = await App().GaeaUsageOverview()
  return result as UsageOverview
}

/** Herdsman 受控测评运行列表（D3-3） */
export async function getBenchmarkList(): Promise<BenchmarkRunSummary[]> {
  const result = await App().GaeaBenchmarkList()
  return result as BenchmarkRunSummary[]
}

/** 发起一次受控测评（返回运行 ID） */
export async function startBenchmark(req: BenchmarkRequest): Promise<string> {
  const result = await App().GaeaBenchmarkStart(req)
  return result as string
}

/** 导出测评报告（Markdown），返回文件路径 */
export async function exportBenchmark(id: string, dir: string): Promise<string> {
  const result = await App().GaeaBenchmarkExport(id, dir)
  return result as string
}

/** 流式探针：对模型发起一次 SSE 流式请求，观察 TTFT/分块间隔/断流（D3-4） */
export async function streamProbe(model: string): Promise<StreamProbeResult> {
  const result = await App().GaeaBenchmarkStreamProbe(model)
  return result as StreamProbeResult
}

// ── C 刀：健康巡检 + 故障转移 v0 ─────────────────────────────
// GetEngineFailover/SetEngineFailover 挂在后端 ModelB 门面（并行线实现中）；
// 这里经 initBridge 的 window.go.app.App 兼容代理按方法名路由（bridge.ts）。
// AppBindings 认领 + bindingNames 再生成待后端合入后收口，此前用 AppFacade
// 的既有索引签名（unknown → 收窄）调用：未合入环境读取拒绝 → 按 null 降级，
// UI 显示「未知」并禁用开关。

/** 读取故障转移开关；读取失败/后端未合入返回 null（UI 显示「未知」并禁用） */
export async function getEngineFailover(): Promise<boolean | null> {
  try {
    const v = await App().GetEngineFailover()
    return typeof v === 'boolean' ? v : null
  } catch {
    return null
  }
}

/** 设置故障转移开关（调用失败自动换其他已连接引擎重试一次，默认关） */
export async function setEngineFailover(enabled: boolean): Promise<void> {
  await App().SetEngineFailover(enabled)
}
