import type React from "react";
import { BarChart3, Blocks, Brain, ListTree, MessageSquare, PieChart } from "../icons";

// 对话窗口上方的视图标签（dsh-context 移植，v4.17-v4.20 已完整接通）：
// [对话] 现有 Transcript；[轨迹] 事件账本（概览/搜索/折叠/增量渲染）；
// [上下文] 上下文构成看板（趋势/事件/文件活动/浏览器/Agent 网络）。
// v4.72：删除「概览」tab（统计信息已由上下文页 Token/费用/会话信息卡承载）。
// v4.73：左侧「记忆」入口迁入主区 tab（对话/轨迹/上下文/记忆）。
// v4.542 刀3：第五 tab「洞察」（跨会话 Context Insights，对标 dsh-context
// 洞察页；会话级四 tab 之后的第一个跨会话视图）。
export type ChatTabId = "chat" | "trajectory" | "context" | "memory" | "insights" | "fleet";

/** 视图 tab id 单源（useSubagentTabs 白名单/App 持久化校验共用）：
 *  漏新 id 的后果=被当成子代理会话 tab 吃掉（2026-11-05/2026-11-15 两次真机
 *  定罪；2026-11-17 审查批4 自 wenxue 树回种单源——此前本树 handleChatTabSelect
 *  仍是硬编码内联名单，是下一次「第四犯」的火种）。 */
export const CHAT_VIEW_TAB_IDS: ChatTabId[] = ["chat", "trajectory", "context", "memory", "insights", "fleet"];

/** 动态会话 tab（子代理独立会话，better-sidebar openSubagent 语义）。 */
export interface ChatSessionTab {
  id: string;
  label: string;
  /** 会话状态（子代理运行态；有值时 tab 前显示实时状态点，与主代理运行态同口径；
      aborted = 用户中止（D4 结算词汇） */
  status?: "queued" | "running" | "completed" | "failed" | "aborted";
  /** 悬停详情（任务/状态/模型等完整信息；缺省回退 id） */
  detail?: string;
}

const TABS: { id: ChatTabId; label: string; icon: typeof MessageSquare }[] = [
  { id: "chat", label: "对话", icon: MessageSquare },
  { id: "trajectory", label: "轨迹", icon: ListTree },
  { id: "context", label: "上下文", icon: BarChart3 },
  { id: "memory", label: "记忆", icon: Brain },
  { id: "insights", label: "洞察", icon: PieChart },
  { id: "fleet", label: "编队", icon: Blocks },
];

export function ChatTabs({ active, onChange, tabs, labelOverrides, className, extraTabs, onCloseExtra }: {
  active: string;
  onChange: (id: string) => void;
  /** 渲染的视图 tab 子集（按传入顺序；缺省全部四个——原罪复用只挂 对话/轨迹/上下文）。 */
  tabs?: ChatTabId[];
  /** 标签文案覆盖（原罪主 tab 显示「故事」；键缺省回落内置文案）。 */
  labelOverrides?: Partial<Record<ChatTabId, string>>;
  /** 外部追加类（宿主布局调整内边距用；不影响内部结构）。 */
  className?: string;
  /** 独立会话 tab（如子代理会话），渲染在四视图之后。 */
  extraTabs?: ChatSessionTab[];
  /** 关闭动态会话 tab。 */
  onCloseExtra?: (id: string) => void;
}) {
  const visible = (tabs ?? TABS.map((t) => t.id))
    .map((id) => TABS.find((t) => t.id === id))
    .filter((t): t is (typeof TABS)[number] => !!t);
  // tablist 键盘导航（v4.427）：←/→（含 Home/End）在全部 tab（主视图+动态会话）
  // 间循环。roving tabindex：仅选中项在 tab 序里，方向键/点击移动焦点。
  const onListKeyDown = (e: React.KeyboardEvent) => {
    if (e.key !== "ArrowLeft" && e.key !== "ArrowRight" && e.key !== "Home" && e.key !== "End") return;
    e.preventDefault();
    const nodes = Array.from(
      (e.currentTarget as HTMLElement).querySelectorAll<HTMLElement>('[role="tab"]'),
    );
    if (nodes.length === 0) return;
    const idx = nodes.findIndex((n) => n.getAttribute("aria-selected") === "true");
    let next = idx;
    if (e.key === "Home") next = 0;
    else if (e.key === "End") next = nodes.length - 1;
    else if (idx < 0) next = 0;
    else next = (idx + (e.key === "ArrowRight" ? 1 : -1) + nodes.length) % nodes.length;
    nodes[next]?.focus();
    nodes[next]?.click();
  };
  return (
    <div
      className={`flex items-center gap-1 px-12 pt-2 pb-0 border-b border-border-soft bg-bg/80 select-none ${className ?? ""}`}
      role="tablist"
      onKeyDown={onListKeyDown}
    >
      {visible.map((t) => {
        const Icon = t.icon;
        const selected = t.id === active;
        return (
          <button
            key={t.id}
            type="button"
            role="tab"
            data-chat-view-tab={t.id}
            aria-selected={selected}
            tabIndex={selected ? 0 : -1}
            className={`relative flex items-center gap-1.5 px-3 py-1.5 text-[12px] rounded-t-md border-0 bg-transparent cursor-pointer transition-colors ${
              selected ? "text-accent" : "text-fg-dim hover:text-fg"
            }`}
            onClick={() => onChange(t.id)}
            title={t.id === "trajectory" ? "工具调用/步骤时间线" : undefined}
          >
            <Icon size={13} aria-hidden />
            {labelOverrides?.[t.id] ?? t.label}
            {selected && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-accent" />}
          </button>
        );
      })}
      {(extraTabs ?? []).map((s) => {
        const selected = s.id === active;
        return (
          <div
            key={s.id}
            role="tab"
            aria-selected={selected}
            tabIndex={selected ? 0 : -1}
            data-chat-session-tab={s.id}
            className={`relative flex items-center gap-1.5 px-3 py-1.5 text-[12px] rounded-t-md border-0 cursor-pointer transition-colors ${
              selected ? "text-accent" : "text-fg-dim hover:text-fg"
            }`}
            onClick={() => onChange(s.id)}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                onChange(s.id);
              }
            }}
            title={s.detail || s.id}
          >
            {s.status && (
              <span
                data-testid={`chat-tab-status-${s.id}`}
                className="inline-block h-1.5 w-1.5 rounded-full shrink-0"
                style={{
                  background:
                    s.status === "running"
                      ? "var(--gaea-glow)"
                      : s.status === "queued"
                        ? "var(--fg-faint)"
                        : s.status === "failed"
                          ? "var(--md-sys-color-destructive)"
                          : "var(--md-sys-color-success)",
                }}
                aria-hidden
              />
            )}
            <MessageSquare size={13} />
            <span className="max-w-[140px] truncate">{s.label}</span>
            {onCloseExtra && (
              <button
                type="button"
                aria-label={`关闭 ${s.label}`}
                className="flex items-center justify-center w-4 h-4 rounded text-fg-faint hover:text-fg hover:bg-bg-soft"
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseExtra(s.id);
                }}
              >
                <svg width="8" height="8" viewBox="0 0 10 10" aria-hidden>
                  <path d="M1 1l8 8M9 1L1 9" stroke="currentColor" strokeWidth="1.4" />
                </svg>
              </button>
            )}
            {selected && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-accent" />}
          </div>
        );
      })}
    </div>
  );
}
