// Composer（T6-10.1 巨型组件拆分后的编排层，行为零变化）
// 文本/排队/键盘/高度状态 + 跨 hook 装配；菜单/附件/工作区逻辑见 gaea/hooks/，
// 纯展示组件见 components/composer/。
import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, ClipboardEvent, DragEvent, KeyboardEvent, PointerEvent as ReactPointerEvent, ReactNode } from "react";
import { useT } from "../lib/i18n";
import { clearLayoutSize, loadLayoutSize, saveLayoutSize } from "../lib/layoutPreferences";
import { applyTableConversion, detectTableBlock } from "../lib/tableData";
import { useComposerInsertStore } from "../lib/store";
import { app as defaultApp } from "../lib/bridge";
import type { ComposerBridge } from "../lib/composerBridge";
import { getComposerDraft, saveComposerDraft } from "../../lib/composerDrafts";
import { SlashMenu } from "./SlashMenu";
import { ArgMenu } from "./ArgMenu";
import { FileMenu } from "./FileMenu";
import { MenuContainer } from "./MenuContainer";
import { usePasteBlocks, PasteBlocksUI } from "./PasteManager";
import { ScreenCropOverlay } from "./ScreenCropOverlay";
import { useComposerMenus } from "../hooks/useComposerMenus";
import { useComposerAttachments } from "../hooks/useComposerAttachments";
import { useComposerWorkspace } from "../hooks/useComposerWorkspace";
import { ComposerDragOverlay } from "./composer/ComposerDragOverlay";
import { ComposerWorkspaceMenu } from "./composer/ComposerWorkspaceMenu";
import { ComposerAttachmentBar } from "./composer/ComposerAttachmentBar";
import { ComposerQueueList } from "./composer/ComposerQueueList";
import {
  dropSending, firstPending, insertAt, isQueueBusy, makeQueueItem,
  markSending, moveItem, pendingItems, removeAt, revertSending, type ComposerQueueItem,
} from "./composer/composerQueue";
import { ComposerTableBanner } from "./composer/ComposerTableBanner";
import { ComposerInputRow } from "./composer/ComposerInputRow";
import { ComposerToolbar } from "./composer/ComposerToolbar";
import { SkillRecordModal } from "./SkillRecordModal";

// 新输入卡固定含 112px 输入区 + 43px 工具栏。旧版曾允许 86~104px，
// 桌面端持久化后会裁掉整个工具栏；下限必须覆盖新卡片的完整内容。
const COMPOSER_MIN_HEIGHT = 164;
const COMPOSER_DEFAULT_HEIGHT = 164;
const COMPOSER_MAX_HEIGHT = 360;
const COMPOSER_MAX_VIEWPORT_RATIO = 0.4;
const INPUT_HISTORY_KEY = "gaea.inputHistory";
const MAX_INPUT_HISTORY = 50;

function useDebounce<T>(value: T, delay: number): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => { const t = setTimeout(() => setDebounced(value), delay); return () => clearTimeout(t); }, [value, delay]);
  return debounced;
}

function composerMaxHeight(): number {
  if (typeof window === "undefined") return COMPOSER_MAX_HEIGHT;
  return Math.max(COMPOSER_MIN_HEIGHT, Math.min(COMPOSER_MAX_HEIGHT, Math.floor(window.innerHeight * COMPOSER_MAX_VIEWPORT_RATIO)));
}
function clampComposerHeight(h: number): number {
  return Math.min(Math.max(Math.round(h), COMPOSER_MIN_HEIGHT), composerMaxHeight());
}
function loadComposerHeight(): number {
  return loadLayoutSize("composerHeightV2", COMPOSER_DEFAULT_HEIGHT, clampComposerHeight);
}

export type ComposerVariant = "office" | "wenxue";

export interface ComposerProps {
  running: boolean; cwd?: string;
  /** 宿主生成的会话草稿键；缺省不持久化，保持独立复用场景零变化。 */
  sessionKey?: string;
  /** placeholder 覆盖（sin 加性缝）：disabled 态显示宿主文案而非「加载中…」。 */
  placeholderOverride?: string;
  onSend: (displayText: string, submitText?: string) => void;
  onSteer?: (text: string) => void;
  onCancel: () => string | undefined; permLevel?: string; onSetPermLevel?: (p: "ask" | "auto" | "yolo") => void;
  thinkLevel?: string; onSetThinkLevel?: (level: "fast" | "normal" | "deep") => void;
  /** 计划模式（v4.420）：状态由 App 层从计划回执推导，点击走动词链 */
  planActive?: boolean; onTogglePlan?: () => void;
  /** 会话上下文使用状态；由宿主注入，统一落在输入卡底部工具栏内。 */
  contextStatus?: ReactNode;
  onPickFolder: (path?: string) => Promise<string>; disabled?: boolean;
  /** 打开办公工具面板（CAD 图纸/进度计划）；2026-11-14 起两者为右栏一级 Tab。 */
  onOpenTool?: (tool: "cad" | "schedule") => void;
  /** 卸载时队列未清空（宿主用 key 重挂 = 队列被静默丢弃）——如实上报条数，
   *  宿主可提示「排队 N 条已随切换清空」。可选；办公场景不传零影响。 */
  onQueueDrop?: (count: number) => void;
  /** 双壳单源适配：文学壳显式传入自己的 bridge/store/命令过滤。 */
  variant?: ComposerVariant;
  bridge?: ComposerBridge;
  insertStore?: typeof useComposerInsertStore;
  filterCommand?: (name: string) => boolean;
}

export function Composer({
  running, cwd, sessionKey, onSend, onSteer, onCancel, permLevel, onSetPermLevel, thinkLevel, onSetThinkLevel, onPickFolder, disabled, planActive, onTogglePlan, onQueueDrop, onOpenTool, contextStatus, placeholderOverride,
  variant = "office", bridge: bridgeOverride, insertStore, filterCommand,
}: ComposerProps) {
  const bridge = bridgeOverride ?? defaultApp;
  const composerInsertStore = insertStore ?? useComposerInsertStore;
  const t = useT();
  const initialDraft = useMemo(() => getComposerDraft(sessionKey), [sessionKey]);
  const [text, setText] = useState(initialDraft.text);
  // 粘贴表格即数据：识别 CSV/TSV 表格块，发送时转 Markdown 表格（可关）
  const tableInfo = useMemo(() => detectTableBlock(text), [text]);
  const [tableMode, setTableMode] = useState(true);
  const debouncedText = useDebounce(text, 80);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const paste = usePasteBlocks(text, setText, taRef);
  const composerCardRef = useRef<HTMLDivElement>(null);
  const wasRunning = useRef(running);

  // ── 附件/粘贴/截图/识图/OCR（useComposerAttachments） ──
  const att = useComposerAttachments({
    text, setText, taRef, running, onSend,
    initialAttachments: initialDraft.attachments,
    bridge,
  });
  const {
    attachments, setAttachments, uploadTasks, pendingPaste, cropSrc, setCropSrc, captureBusy,
    recognizingPath, ocrPath, attachDroppedFiles, handlePickFiles,
    handleScreenshot, handleCropConfirm, handleRecognize, handleOCRText,
    retryUploadTask, removeUploadTask,
  } = att;

  // ── 工作区切换菜单（useComposerWorkspace） ──
  const ws = useComposerWorkspace({ cwd, onPickFolder, bridge, variant });
  const {
    workspaceName, workspaceMenuOpen, setWorkspaceMenuOpen,
    workspaceQuery, setWorkspaceQuery, filteredWorkspaces,
    workspaceAnchorRef, workspaceMenuRef, chooseWorkspace, requestCreateNovel,
  } = ws;

  // ── / 命令、/ 参数、@ 文件菜单（useComposerMenus） ──
  const setTextCaretEnd = (next: string) => {
    setText(next);
    requestAnimationFrame(() => { const ta = taRef.current; if (ta) { ta.focus(); ta.selectionStart = ta.selectionEnd = next.length; } });
  };
  const menus = useComposerMenus({ text, debouncedText, setTextCaretEnd, cwd, bridge, filterCommand });
  const {
    slashMatches, argRes, atItems, menuMode, menuCount, menuWaiting,
    active, setActive, setDismissed, pickCommand, pickArg, pickEntry, pickActive,
  } = menus;

  // 排队（pending 可编辑/删除/插话；sending = 已派出等回合接手，整列锁定）
  const initialQueue = useMemo<ComposerQueueItem[]>(
    () => initialDraft.queue
      .filter((item) => item.status === "pending")
      .map((item) => ({ ...item, status: "pending" })),
    [initialDraft],
  );
  const queueRef = useRef<ComposerQueueItem[]>(initialQueue);
  const [queue, setQueue] = useState<ComposerQueueItem[]>(initialQueue);
  // Restored pending rows are visible but not auto-dispatched on mount: the
  // previous run may already be over. They are armed only by observing a live
  // running=true turn, preventing cross-session duplicate sends.
  const queueArmedRef = useRef(initialQueue.length === 0 || running);
  const syncQueue = (next: ComposerQueueItem[]) => {
    queueRef.current = next;
    setQueue(next);
  };
  const queueLen = queue.length;
  useEffect(() => {
    saveComposerDraft(sessionKey, {
      text,
      attachments,
      queue: queue.filter((item) => item.status === "pending"),
    });
  }, [sessionKey, text, attachments, queue]);
  // 卸载时队列未清空如实上报（ref 读取，避免闭包过期；仅卸载触发一次）
  const queueDropRef = useRef(onQueueDrop)
  queueDropRef.current = onQueueDrop
  useEffect(() => () => {
    const n = queueRef.current.length
    if (n > 0) queueDropRef.current?.(n)
  }, [])
  const correctionRef = useRef<string | null>(null);               // 纠正模式待发送文本
  const onSendRef = useRef(onSend);
  onSendRef.current = onSend;
  const onSteerRef = useRef(onSteer);
  onSteerRef.current = onSteer;
  // Shift 键追踪（用于发送按钮提示 / 纠正发送）
  const [shiftHeld, setShiftHeld] = useState(false);
  useEffect(() => {
    const onDown = (e: globalThis.KeyboardEvent) => { if (e.key === "Shift") setShiftHeld(true); };
    const onUp = (e: globalThis.KeyboardEvent) => { if (e.key === "Shift") setShiftHeld(false); };
    window.addEventListener("keydown", onDown);
    window.addEventListener("keyup", onUp);
    return () => { window.removeEventListener("keydown", onDown); window.removeEventListener("keyup", onUp); };
  }, []);
  useEffect(() => {
    // 纠正模式优先：取消后 running→false，立即发送纠正文本
    if (!running && correctionRef.current) {
      const correction = correctionRef.current;
      correctionRef.current = null;
      onSendRef.current(correction, correction);
      return;
    }
    if (running) {
      queueArmedRef.current = true;
      if (isQueueBusy(queueRef.current)) syncQueue(dropSending(queueRef.current));
      return;
    }
    if (!queueArmedRef.current) return;
    if (isQueueBusy(queueRef.current)) return;
    const next = firstPending(queueRef.current);
    if (!next) return;
    syncQueue(markSending(queueRef.current, next.id));
    let dispatched = false;
    const timer = setTimeout(() => {
      dispatched = true;
      onSendRef.current(next.text, next.text);
    }, 50);
    return () => {
      clearTimeout(timer);
      if (!dispatched) syncQueue(revertSending(queueRef.current, next.id));
    };
  }, [running]);

  useEffect(() => {
    if (wasRunning.current && !running && text.trim() === "") {
      paste.clearBlocks();
    }
    wasRunning.current = running;
    // eslint-disable-next-line react-hooks/exhaustive-deps -- paste 为 usePasteBlocks 每次渲染新建的对象，补依赖会导致 effect 每渲染重跑；其 clearBlocks 方法本身是 useCallback([]) 稳定
  }, [running, text]);

  // 右侧资料面板「一键 @ 引用」→ 插入输入框
  const pendingAt = composerInsertStore((s) => s.pendingAt);
  useEffect(() => {
    if (!pendingAt) return;
    const at = composerInsertStore.getState().consumeAt();
    if (!at) return;
    setText((prev) => prev + (prev && !prev.endsWith(" ") ? " " : "") + "@" + at + " ");
    requestAnimationFrame(() => { taRef.current?.focus(); });
  }, [pendingAt, composerInsertStore]);
  // 资料面板「摘要后引用」：把摘要文本插入输入框（可编辑后再发送）。
  const pendingText = composerInsertStore((s) => s.pendingText);
  useEffect(() => {
    if (!pendingText) return;
    const text = composerInsertStore.getState().consumeText();
    if (!text) return;
    setText((prev) => prev + (prev ? "\n\n" : "") + text);
    requestAnimationFrame(() => { taRef.current?.focus(); });
  }, [pendingText, composerInsertStore]);

  // ── 拖放 ──
  const [dragOver, setDragOver] = useState(false);

  // 粘贴处理
  const onPaste = (e: ClipboardEvent<HTMLTextAreaElement>) => {
    const files = Array.from(e.clipboardData.files);
    if (files.length > 0) { e.preventDefault(); void attachDroppedFiles(files); return; }
    // 剪贴板图片（如截图/复制的网页图片）：转为图片附件上下文，而不是静默丢弃
    const imageItem = Array.from(e.clipboardData.items).find(
      (it) => it.type.startsWith("image/")
    );
    if (imageItem) {
      e.preventDefault();
      const file = imageItem.getAsFile();
      if (file) void attachDroppedFiles([file]);
      return;
    }
    paste.onPaste(e);
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    const files = Array.from(e.dataTransfer.files);
    if (files.length === 0) return;
    e.preventDefault(); setDragOver(false); void attachDroppedFiles(files);
  };
  const onDragOver = (e: DragEvent<HTMLDivElement>) => {
    if (!Array.from(e.dataTransfer.items).some((it) => it.kind === "file")) return;
    e.preventDefault(); setDragOver(true);
  };
  const onDragLeave = () => setDragOver(false);

  const pushInputHistory = (display: string) => {
    if (!display.trim()) return;
    try {
      const history = JSON.parse(sessionStorage.getItem(INPUT_HISTORY_KEY) || "[]") as string[];
      history.unshift(display);
      sessionStorage.setItem(INPUT_HISTORY_KEY, JSON.stringify(history.slice(0, MAX_INPUT_HISTORY)));
    } catch {}
  };

  // 组装待发送文本（表格块展开 + 附件引用）；空输入/paste 未决返回 null。
  const assembleSubmit = (): { displayText: string; submitText: string } | null => {
    const converted = tableMode ? applyTableConversion(text, true) : text;
    const tTrim = converted.trim();
    if ((!tTrim && attachments.length === 0) || pendingPaste > 0 || uploadTasks.length > 0) return null;
    // 含空格路径用 @"..." 引号形式（消费端原罪 sin_file_refs 支持引号 token）：
    // 裸 @token 在第一个空格处截断，"C:\Users\John Doe\a.txt" 这类路径注入后
    // 静默失效。不含空格的路径保持裸形式（办公/原罪的既有解析口径零变化）。
    const refs = attachments.map((a) => (/\s/.test(a.path) ? `@"${a.path}"` : `@${a.path}`)).join(" ");
    const displayText = [tTrim, refs].filter(Boolean).join(tTrim && refs ? " " : "");
    const submitText = [paste.expandBlocks(tTrim), refs].filter(Boolean).join(tTrim && refs ? " " : "");
    if (!displayText.trim()) return null;
    return { displayText, submitText };
  };

  // 入队（2026-09-17 对齐 DSH/Codex：运行中发送默认排队，回合结束后 FIFO 派发；
  // 队列卡可拖拽排序/撤回编辑/单条·全部插话/取消）。
  const enqueueSubmit = () => {
    const parts = assembleSubmit();
    if (!parts) return;
    pushInputHistory(parts.displayText);
    syncQueue([...queueRef.current, makeQueueItem(parts.submitText)]);
    setText("");
    setAttachments([]);
  };

  const submit = () => {
    if (disabled) return;
    if (running) { enqueueSubmit(); return; } // v3.6.0 的「Enter=插话」退役为 Alt+Enter（2026-09-17 用户拍板）
    const parts = assembleSubmit();
    if (!parts) return;
    pushInputHistory(parts.displayText);
    setHistoryIndex(-1);
    onSend(parts.displayText, parts.submitText);
    setText("");
    setAttachments([]);
  };

  const handleCancel = () => {
    syncQueue([]);
    const restored = onCancel();
    if (typeof restored === "string") setTextCaretEnd(restored);
  };

  // 发送中整列锁定：不可编辑、删除、Steer（停止当前回合仍走 handleCancel）。
  const cancelQueueItem = (index: number) => {
    if (isQueueBusy(queueRef.current)) return;
    const item = queueRef.current[index];
    if (!item || item.status !== "pending") return;
    syncQueue(removeAt(queueRef.current, index));
  };

  const cancelAllQueue = () => {
    if (isQueueBusy(queueRef.current)) return;
    syncQueue([]);
  };

  const steerQueueItem = (index: number) => {
    if (!running || isQueueBusy(queueRef.current)) return;
    const item = queueRef.current[index];
    if (!item || item.status !== "pending") return;
    onSteerRef.current?.(item.text);
    syncQueue(removeAt(queueRef.current, index));
  };

  const steerAllQueue = () => {
    if (!running || isQueueBusy(queueRef.current)) return;
    const pending = pendingItems(queueRef.current);
    if (pending.length === 0) return;
    for (const item of pending) onSteerRef.current?.(item.text);
    syncQueue(queueRef.current.filter((q) => q.status === "sending"));
  };

  const reorderQueue = (from: number, to: number) => {
    syncQueue(moveItem(queueRef.current, from, to));
  };

  // 撤回排队项到输入框编辑（对齐 agentsroom 消息队列 / vm0 withdraw）：
  // 点击排队卡片 → 该项从队列移除、文本回填输入框；输入框已有草稿先暂存
  // 回队列原位（保持顺序），避免输入内容丢失。改完 Enter 重新入队/发送。
  const editQueueItem = (index: number) => {
    if (isQueueBusy(queueRef.current)) return;
    const target = queueRef.current[index];
    if (target == null || target.status !== "pending") return;
    const draft = text.trim();
    let next = removeAt(queueRef.current, index);
    if (draft && draft !== target.text) {
      next = insertAt(next, Math.min(index, next.length), makeQueueItem(draft));
    }
    syncQueue(next);
    setText(target.text);
    setAttachments([]);
    requestAnimationFrame(() => { const ta = taRef.current; if (ta) { ta.focus(); ta.selectionStart = ta.selectionEnd = target.text.length; } });
  };

  // ── 高度调整 ──
  const [composerHeight, setComposerHeight] = useState<number>(loadComposerHeight);
  const [composerResizing, setComposerResizing] = useState(false);
  const [recordOpen, setRecordOpen] = useState(false);
  useEffect(() => {
    const onResize = () => setComposerHeight((h) => clampComposerHeight(h));
    window.addEventListener("resize", onResize); return () => window.removeEventListener("resize", onResize);
  }, []);
  const saveComposerHeight = (h: number) => saveLayoutSize("composerHeightV2", h, clampComposerHeight);
  const resetComposerHeight = () => { setComposerHeight(COMPOSER_DEFAULT_HEIGHT); clearLayoutSize("composerHeightV2"); };
  const onComposerResizeStart = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (e.button !== 0) return;
    const card = composerCardRef.current; if (!card) return;
    e.preventDefault();
    const startY = e.clientY;
    const startHeight = composerHeight || card.getBoundingClientRect().height;
    let nextHeight = clampComposerHeight(startHeight);
    let moved = false;
    setComposerResizing(true); document.body.classList.add("composer-resizing");
    const onMove = (ev: PointerEvent) => { moved = true; nextHeight = clampComposerHeight(startHeight + startY - ev.clientY); setComposerHeight(nextHeight); };
    const onUp = () => { setComposerResizing(false); document.body.classList.remove("composer-resizing"); if (moved) saveComposerHeight(nextHeight); document.removeEventListener("pointermove", onMove); document.removeEventListener("pointerup", onUp); document.removeEventListener("pointercancel", onUp); };
    document.addEventListener("pointermove", onMove); document.addEventListener("pointerup", onUp); document.addEventListener("pointercancel", onUp);
  };

  // ── 历史 ──
  const [historyIndex, setHistoryIndex] = useState(-1);
  const historyDraft = useRef("");
  const navigateHistory = (dir: 1 | -1) => {
    try {
      const history: string[] = JSON.parse(sessionStorage.getItem(INPUT_HISTORY_KEY) || "[]");
      if (history.length === 0) return;
      if (historyIndex === -1) historyDraft.current = text;
      const next = Math.max(-1, Math.min(history.length - 1, historyIndex + dir));
      setHistoryIndex(next); setText(next === -1 ? historyDraft.current : history[next] || "");
    } catch {}
  };

  // ── 键盘处理 ──
  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    const composing = e.nativeEvent.isComposing;
    if (menuWaiting && menuMode === null && !composing) {
      if (["Enter", "Tab", "ArrowUp", "ArrowDown", "Escape"].includes(e.key)) e.preventDefault();
      if (e.key === "Escape") setDismissed(true);
      return;
    }
    if (menuMode && !composing) {
      if (e.key === "ArrowDown") { e.preventDefault(); setActive((i) => (i + 1) % menuCount); return; }
      if (e.key === "ArrowUp") { e.preventDefault(); setActive((i) => (i - 1 + menuCount) % menuCount); return; }
      if (e.key === "Enter" || e.key === "Tab") { e.preventDefault(); pickActive(); return; }
      if (e.key === "Escape") { e.preventDefault(); setDismissed(true); return; }
    }
    if (!menuMode && !composing) {
      if (e.key === "ArrowUp" && text === "") { e.preventDefault(); navigateHistory(1); return; }
      if (e.key === "ArrowDown" && historyIndex >= 0) { e.preventDefault(); navigateHistory(-1); return; }
      if (e.key !== "ArrowUp" && e.key !== "ArrowDown" && historyIndex >= 0) setHistoryIndex(-1);
    }
    if (e.key === "Enter" && e.shiftKey && !composing) {
      // 纠正模式：Shift+Enter → 清空队列 + 取消当前轮次 + 立即发送新文本
      e.preventDefault();
      if (disabled) return;
      const parts = assembleSubmit();
      if (!parts) return;
      pushInputHistory(parts.displayText);
      setHistoryIndex(-1);
      syncQueue([]);
      onCancel();
      correctionRef.current = parts.submitText;
      setText("");
      setAttachments([]);
      return;
    }
    // Alt+Enter：直插当前回合（显式插话，不入队——2026-09-17 起 Enter 已改排队）
    if (e.key === "Enter" && e.altKey && !e.shiftKey && !composing) {
      e.preventDefault();
      if (disabled || !running) return;
      const parts = assembleSubmit();
      if (!parts) return;
      pushInputHistory(parts.displayText);
      onSteerRef.current?.(parts.submitText);
      setText("");
      setAttachments([]);
      return;
    }
    if (e.key === "Enter" && !e.shiftKey && !composing) { e.preventDefault(); submit(); }
    if (e.key === "Escape" && running) { e.preventDefault(); handleCancel(); }
  };

  const composerCardStyle = { "--composer-height": `${composerHeight}px` } as CSSProperties;

  // ── 项目感知 placeholder ──
  // placeholderOverride（2026-11-15 sin 升格刀加性缝）：宿主可覆盖 disabled 态
  // 的「加载中…」文案（原罪未绑书=「先在书架选择一本书」）。缺省 undefined =
  // 办公行为逐字节不变。
  const placeholderText = useMemo(() => {
    if (placeholderOverride) return placeholderOverride;
    if (disabled) return t("common.loading");
    if (isQueueBusy(queue)) return t("composer.queueSending");
    if (running && queueLen > 0) return t("composer.queuePending", { n: queueLen });
    if (running) return t("composer.runningHint");
    return t("composer.placeholder");
  }, [placeholderOverride, disabled, running, queueLen, queue, t]);

  return (
    <div className="office-composer-root relative max-w-(--maxw) mx-auto">
      {/* ── 拖放指示器 ── */}
      <ComposerDragOverlay show={dragOver} />

      {/* ── 工作区切换菜单 ── */}
      {workspaceMenuOpen && cwd && (
        <ComposerWorkspaceMenu
          menuRef={workspaceMenuRef}
          query={workspaceQuery}
          onQueryChange={setWorkspaceQuery}
          workspaces={filteredWorkspaces}
          onChoose={chooseWorkspace}
          onCreateNovel={requestCreateNovel}
          onClose={() => setWorkspaceMenuOpen(false)}
        />
      )}

      {/* ── 菜单（命令/参数/文件）── */}
      {menuWaiting && menuMode === null && (
        <MenuContainer count={1}>
          <div role="status" className="px-2 py-1.5 text-[12px] text-fg-faint">
            {t("common.loading")}
          </div>
        </MenuContainer>
      )}
      {menuMode === "slash" && <SlashMenu items={slashMatches} activeIndex={active} onPick={pickCommand} onHover={setActive} />}
      {menuMode === "slasharg" && argRes && <ArgMenu items={argRes.items} activeIndex={active} onPick={pickArg} onHover={setActive} />}
      {menuMode === "at" && <FileMenu items={atItems} activeIndex={active} onPick={pickEntry} onHover={setActive} />}

      {/* ── 附件预览 ── */}
      <ComposerAttachmentBar
        attachments={attachments}
        uploads={uploadTasks}
        running={running}
        recognizingPath={recognizingPath}
        ocrPath={ocrPath}
        onRecognize={handleRecognize}
        onOCRText={handleOCRText}
        onRemove={(path) => setAttachments((prev) => prev.filter((x) => x.path !== path))}
        onRetryUpload={(id) => void retryUploadTask(id)}
        onRemoveUpload={removeUploadTask}
      />

      {/* ── 粘贴块 ── */}
      <PasteBlocksUI
        blocks={paste.activePastedBlocks}
        openLabels={paste.openPastedLabels}
        onTogglePreview={paste.togglePreview}
        onExpand={paste.expandBlock}
        onRemove={paste.removeBlock}
      />

      {/* ── 排队列表 ── */}
      {queue.length > 0 && (
        <ComposerQueueList
          items={queue}
          running={running}
          onCancelItem={cancelQueueItem}
          onEditItem={editQueueItem}
          onSteerItem={steerQueueItem}
          onSteerAll={steerAllQueue}
          onCancelAll={cancelAllQueue}
          onReorder={reorderQueue}
        />
      )}

      {/* ── 输入卡片（Luminous Glass：玻璃底 + 顶部 1px 高光线 + 聚焦收敛光晕） ── */}
      <div
        className={`office-composer-card relative flex flex-col border border-border-soft/80 bg-bg-elev/70 backdrop-blur-xl backdrop-saturate-150 rounded-2xl overflow-hidden shadow-[inset_0_1px_0_color-mix(in_srgb,var(--fg)_6%,transparent)] transition-[border-color,box-shadow,background] duration-[var(--dur-base)] focus-within:border-accent/30 focus-within:shadow-[inset_0_1px_0_color-mix(in_srgb,var(--fg)_6%,transparent),0_0_0_1px_var(--accent-soft),0_0_22px_color-mix(in_srgb,var(--accent)_10%,transparent),var(--ds-shadow-composer)] ${composerResizing ? "cursor-ns-resize" : ""}`}
        style={{ height: "var(--composer-height)", ...composerCardStyle }}
        ref={composerCardRef}
      >
        {/* 顶部 1px 高光线（v3-edge 渐变） */}
        <div aria-hidden className="pointer-events-none absolute top-0 left-0 right-0 h-px z-[4]" style={{ background: "var(--v3-edge)" }} />
        {/* 拖拽调整大小把手 */}
        <div
          className="absolute top-0 left-[14px] right-[14px] z-[5] h-2 cursor-ns-resize no-drag touch-none"
          onPointerDown={onComposerResizeStart}
          onDoubleClick={resetComposerHeight}
        />

        {/* 粘贴表格即数据：检测到表格块时提示，可关 */}
        {tableInfo && !disabled && (
          <ComposerTableBanner
            rows={tableInfo.rows}
            cols={tableInfo.cols}
            tableMode={tableMode}
            onTableModeChange={setTableMode}
          />
        )}

        {/* 主输入行 */}
        <ComposerInputRow
          taRef={taRef}
          text={text}
          onTextChange={setText}
          onPaste={onPaste}
          onKeyDown={onKeyDown}
          placeholder={placeholderText}
          disabled={disabled ?? false}
          running={running}
          composerHeightFixed
          dragOver={dragOver}
          shiftHeld={shiftHeld}
          queueLen={queueLen}
          pendingPaste={pendingPaste + uploadTasks.length}
          attachmentsCount={attachments.length}
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onStop={handleCancel}
          onSubmit={submit}
          onQueue={enqueueSubmit}
        />

        {/* 底部工具栏 */}
        <ComposerToolbar
          cwd={cwd}
          workspaceName={workspaceName}
          workspaceMenuOpen={workspaceMenuOpen}
          onToggleWorkspaceMenu={() => { if (!running) setWorkspaceMenuOpen((o) => !o) }}
          workspaceAnchorRef={workspaceAnchorRef}
          running={running}
          pendingPaste={pendingPaste + uploadTasks.length}
          captureBusy={captureBusy}
          onPickFiles={() => void handlePickFiles()}
          onScreenshot={() => void handleScreenshot()}
          onRecordSkill={() => setRecordOpen(true)}
          onOpenTool={onOpenTool}
          permLevel={permLevel}
          onSetPermLevel={onSetPermLevel}
          thinkLevel={thinkLevel}
          onSetThinkLevel={onSetThinkLevel}
          planActive={planActive}
          onTogglePlan={onTogglePlan}
          contextStatus={contextStatus}
        />
      </div>

      {/* 会话录制技能浮层（阶段七 7.2-1） */}
      <SkillRecordModal open={recordOpen} onClose={() => setRecordOpen(false)} bridge={bridge} />

      {/* 截图裁剪浮层 */}
      {cropSrc && (
        <ScreenCropOverlay
          src={cropSrc}
          onCancel={() => setCropSrc(null)}
          onConfirm={(d) => void handleCropConfirm(d)}
        />
      )}
    </div>
  );
}

