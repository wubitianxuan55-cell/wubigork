// T7-4（v2.37.0）Transcript 轮级 memo：TurnBlock/ProcessCard 稳定化验证。
// 子组件（UserMessage/AssistantMessage/ToolCard）用 vi.mock 换成计数函数，
// 从而验证「同 props 重渲染不调用子组件、内容变化才调用」的 memo 语义。
import { beforeAll, describe, expect, it, vi } from "vitest";
// P4-H7：en 字典按需加载后，默认 locale=en 的模块级 t() 需先等 chunk 就绪
import { loadLocale, LocaleProvider } from "../lib/i18n";
import { render } from "@testing-library/react";
import { ProcessCard, TurnBlock } from "./Transcript";
import type { Item } from "../lib/store";

vi.mock("./Message", () => ({
  UserMessage: vi.fn(() => null),
  AssistantMessage: vi.fn(() => null),
}));
vi.mock("./ToolCard", () => ({
  ToolCard: vi.fn(() => null),
}));

import * as MessageModule from "./Message";
import * as ToolCardModule from "./ToolCard";

function u(id: string, text: string): Item { return { kind: "user", id, text }; }
function a(id: string, text: string): Item { return { kind: "assistant", id, text, reasoning: "", streaming: false }; }
function tool(id: string, name: string): Item { return { kind: "tool", id, name, args: "", readOnly: false, status: "done" }; }

const noop = () => {};
const turnElsRef = { current: new Map<number, HTMLElement>() };
const noSubcalls = new Map<string, never>();

describe("TurnBlock 轮级 memo（T7-4）", () => {
  beforeAll(() => loadLocale("en"));


  it("props 引用不变时 rerender 不重渲染子消息；段内容变化才重渲染", () => {
    const userMock = vi.mocked(MessageModule.UserMessage);
    userMock.mockClear();
    const seg = { processItems: [] as Item[], outsideItems: [u("u1", "第一问")] };
    const props = {
      seg, running: false, isLast: false, turnNo: 0, openTurn: null,
      onToggleTurn: noop, onRewindTurn: noop, onCollapse: noop,
      dismissedErrors: new Set<string>(), onDismissError: noop,
      turnElsRef,
    };
    const { rerender } = render(<TurnBlock {...props} />);
    expect(userMock).toHaveBeenCalledTimes(1);

    // 相同 props 重渲染：memo 跳过，UserMessage 不重渲染
    rerender(<TurnBlock {...props} />);
    expect(userMock).toHaveBeenCalledTimes(1);

    // 段内容变化：才重新渲染
    rerender(<TurnBlock {...props} seg={{ processItems: [], outsideItems: [u("u2", "第二问")] }} />);
    expect(userMock).toHaveBeenCalledTimes(2);
  });

  it("assistant 段：同一段 rerender 不重渲染 AssistantMessage", () => {
    const assistantMock = vi.mocked(MessageModule.AssistantMessage);
    assistantMock.mockClear();
    const seg = { processItems: [] as Item[], outsideItems: [a("a1", "回答内容")] };
    const props = {
      seg, running: false, isLast: true, turnNo: undefined, openTurn: null,
      onToggleTurn: noop, onRewindTurn: noop, onCollapse: noop,
      dismissedErrors: new Set<string>(), onDismissError: noop,
      turnElsRef,
    };
    const { rerender } = render(<TurnBlock {...props} />);
    expect(assistantMock).toHaveBeenCalledTimes(1);

    rerender(<TurnBlock {...props} />);
    expect(assistantMock).toHaveBeenCalledTimes(1);

    rerender(<TurnBlock {...props} seg={{ processItems: [], outsideItems: [a("a2", "新回答")] }} />);
    expect(assistantMock).toHaveBeenCalledTimes(2);
  });

  it("TurnBlock 是 React.memo 组件", () => {
    expect((TurnBlock as unknown as { $$typeof?: unknown }).$$typeof).toBe(Symbol.for("react.memo"));
  });

  it("第 2 轮起在用户消息上方渲染回合分隔线（v4.27）", () => {
    const seg = { processItems: [] as Item[], outsideItems: [u("u2", "第二轮问题")] };
    const { container } = render(
      <TurnBlock
        seg={seg} running={false} isLast={false} turnNo={1} openTurn={null}
        onToggleTurn={noop} onRewindTurn={noop} onCollapse={noop}
        dismissedErrors={new Set<string>()} onDismissError={noop}
        turnElsRef={turnElsRef}
      />,
    );
    const divider = container.querySelector(".turn-divider");
    expect(divider).not.toBeNull();
    expect(divider?.getAttribute("role")).toBe("separator");
    expect(divider?.textContent).toContain("2");
  });

  it("首轮（turnNo=0）不渲染回合分隔线", () => {
    const seg = { processItems: [] as Item[], outsideItems: [u("u1", "第一问")] };
    const { container } = render(
      <TurnBlock
        seg={seg} running={false} isLast={false} turnNo={0} openTurn={null}
        onToggleTurn={noop} onRewindTurn={noop} onCollapse={noop}
        dismissedErrors={new Set<string>()} onDismissError={noop}
        turnElsRef={turnElsRef}
      />,
    );
    expect(container.querySelector(".turn-divider")).toBeNull();
  });

  // v4.505：todo_write 不进过程卡——待办有专属面板（useTodoExtractor →
  // 任务待办区），外部项渲染线同款过滤；纯 todo_write 段不空壳出卡。
  it("todo_write 不进过程卡：卡体无该卡、计数只含真实工具", () => {
    const toolMock = vi.mocked(ToolCardModule.ToolCard);
    toolMock.mockClear();
    const think: Item = { kind: "assistant", id: "r1", text: "", reasoning: "想一下", streaming: false };
    const todo: Item = { kind: "tool", id: "tw1", name: "todo_write", args: "{}", readOnly: false, status: "done" };
    const seg = {
      processItems: [think, todo, tool("b1", "bash")],
      outsideItems: [],
    };
    const { container } = render(
      <LocaleProvider>
        <TurnBlock
          seg={seg} running={false} isLast={false} turnNo={0} openTurn={null}
          onToggleTurn={noop} onRewindTurn={noop} onCollapse={noop}
          dismissedErrors={new Set<string>()} onDismissError={noop}
          turnElsRef={turnElsRef}
        />
      </LocaleProvider>,
    );
    const calls = toolMock.mock.calls;
    expect(calls.length).toBe(1);
    expect((calls[0][0] as { item: Extract<Item, { kind: "tool" }> }).item.name).toBe("bash");
    expect(container.textContent).not.toContain("todo_write");
  });

  it("纯 todo_write 段不空壳出卡（无过程卡头）", () => {
    const todo: Item = { kind: "tool", id: "tw2", name: "todo_write", args: "{}", readOnly: false, status: "done" };
    const seg = { processItems: [todo], outsideItems: [] };
    const { container } = render(
      <TurnBlock
        seg={seg} running={false} isLast={false} turnNo={0} openTurn={null}
        onToggleTurn={noop} onRewindTurn={noop} onCollapse={noop}
        dismissedErrors={new Set<string>()} onDismissError={noop}
        turnElsRef={turnElsRef}
      />,
    );
    expect(container.querySelectorAll("button[aria-expanded]").length).toBe(0);
  });
});

describe("ProcessCard memo（T7-4）", () => {
  it("相同 props 不重渲染工具卡；items 变化才重渲染", () => {
    const toolMock = vi.mocked(ToolCardModule.ToolCard);
    toolMock.mockClear();
    const items = [tool("t1", "read_file")];
    const { rerender } = render(
      <ProcessCard items={items} toolCount={1} thoughtCount={0} small={false} subcallsByParent={noSubcalls} />,
    );
    expect(toolMock).toHaveBeenCalledTimes(1);

    rerender(
      <ProcessCard items={items} toolCount={1} thoughtCount={0} small={false} subcallsByParent={noSubcalls} />,
    );
    expect(toolMock).toHaveBeenCalledTimes(1);

    rerender(
      <ProcessCard items={[tool("t2", "write_file")]} toolCount={1} thoughtCount={0} small={false} subcallsByParent={noSubcalls} />,
    );
    expect(toolMock).toHaveBeenCalledTimes(2);
  });

  it("子调用收集：父工具卡拿到段内子调用列表", () => {
    const toolMock = vi.mocked(ToolCardModule.ToolCard);
    toolMock.mockClear();
    const parent: Item = { kind: "tool", id: "p1", name: "run_bash", args: "", readOnly: false, status: "done" };
    const child: Item = { kind: "tool", id: "c1", name: "read_file", args: "", readOnly: false, status: "done", parentId: "p1" };
    render(
      <ProcessCard items={[parent, child]} toolCount={2} thoughtCount={0} small={false} subcallsByParent={new Map([["p1", [child]]])} />,
    );
    const first = toolMock.mock.calls[0];
    expect(first?.[0]?.item?.id).toBe("p1");
    expect(first?.[0]?.subcalls).toHaveLength(1);
    expect(first?.[0]?.subcalls?.[0]?.id).toBe("c1");
  });

  it("ProcessCard 是 React.memo 组件", () => {
    expect((ProcessCard as unknown as { $$typeof?: unknown }).$$typeof).toBe(Symbol.for("react.memo"));
  });

  // 纯思考段（v4.308 视觉降噪）：不出过程卡头，只渲染裸思考行 + 行数摘要
  it("纯思考段走 bare 模式：无卡头按钮，思考行带行数 meta", () => {
    const { container } = render(
      <LocaleProvider>
        <ProcessCard
          items={[{ kind: "assistant", id: "r1", text: "", reasoning: "第一行\n\n第二行", streaming: false } as Item]}
          toolCount={0}
          thoughtCount={1}
          small={false}
          subcallsByParent={noSubcalls}
        />
      </LocaleProvider>,
    );
    const bare = container.querySelector("[data-bare-process]");
    expect(bare).not.toBeNull();
    // 无过程卡头（头部 button 只可能是思考行自己的 .reasoning__head）
    expect(bare?.querySelector(":scope > button")).toBeNull();
    expect(bare?.querySelector(".reasoning__head")).not.toBeNull();
    // 行数摘要：两段非空行 → 「2 行」
    expect(bare?.querySelector(".reasoning__meta")?.textContent).toContain("2");
  });

  it("含工具段不出 bare 模式（保留卡头与折叠）", () => {
    const { container } = render(
      <ProcessCard items={[tool("t1", "read_file")]} toolCount={1} thoughtCount={0} small={false} subcallsByParent={noSubcalls} />,
    );
    expect(container.querySelector("[data-bare-process]")).toBeNull();
  });
});
