// v4.57 i18n 收尾冒烟：composer 家族（Composer/输入行/工具栏/拖放指示器）
// 的三语字典接线。钉住 zh 断言原硬编码文案；en 抽查一条验证键值生效。
import { beforeAll, describe, expect, it, vi, afterEach } from "vitest";
import { fireEvent, render, screen, cleanup } from "@testing-library/react";
import { Composer } from "../Composer";
import { ComposerInputRow } from "./ComposerInputRow";
import { ComposerToolbar } from "./ComposerToolbar";
import { ComposerDragOverlay } from "./ComposerDragOverlay";
import { LocaleProvider, loadLocale } from "../../lib/i18n";

// P4-H7：en 字典按需加载——切换/渲染 en 断言前先等 chunk 就绪
beforeAll(() => loadLocale("en"));


import { ToastProvider } from "../Toast";

// Composer 编排层经 hooks 触达 bridge（Commands/SlashArgs/ListDir/ListWorkspaces…）：
// 统一给一个「任何方法都 resolve(null)」的桩，动作未触发时不产生行为。
// vi.hoisted：vi.mock 工厂被提升到文件顶，桩必须随提升创建。
const appStub = vi.hoisted(() => new Proxy({}, { get: () => vi.fn().mockResolvedValue(null) }));

vi.mock("../../lib/bridge", () => ({
  app: appStub,
  openExternal: vi.fn(),
  onEvent: vi.fn(() => () => {}),
  onReady: vi.fn(() => () => {}),
}));

const renderT = (ui: React.ReactNode, lang: "zh" | "en" = "zh") => {
  localStorage.setItem("gaea-lang", lang);
  return render(
    <LocaleProvider>
      <ToastProvider>{ui}</ToastProvider>
    </LocaleProvider>,
  );
};

const noop = () => {};
const nullRef = { current: null } as React.RefObject<HTMLTextAreaElement>;

describe("ComposerInputRow i18n 冒烟", () => {
  afterEach(cleanup);

  it("运行中发送按钮 title：插话/排队/纠正三态走字典（zh）", () => {
    renderT(
      <ComposerInputRow
        taRef={nullRef}
        text="hi"
        onTextChange={noop}
        onPaste={noop}
        onKeyDown={noop}
        placeholder="p"
        disabled={false}
        running
        composerHeightFixed={false}
        dragOver={false}
        shiftHeld={false}
        queueLen={2}
        pendingPaste={0}
        attachmentsCount={0}
        onDrop={noop}
        onDragOver={noop}
        onDragLeave={noop}
        onStop={noop}
        onSubmit={noop}
        onQueue={noop}
      />,
    );
    expect(screen.getByTitle("排队发送 (2)")).toBeTruthy();
    expect(screen.getByTitle("排队发送（当前回合结束后执行，与插话不同：插话立即调整当前任务）")).toBeTruthy();
    cleanup();
    renderT(
      <ComposerInputRow
        taRef={nullRef}
        text="hi"
        onTextChange={noop}
        onPaste={noop}
        onKeyDown={noop}
        placeholder="p"
        disabled={false}
        running
        composerHeightFixed={false}
        dragOver={false}
        shiftHeld={false}
        queueLen={0}
        pendingPaste={0}
        attachmentsCount={0}
        onDrop={noop}
        onDragOver={noop}
        onDragLeave={noop}
        onStop={noop}
        onSubmit={noop}
        onQueue={noop}
      />,
    );
    // 2026-09-17 起 Enter=排队（对齐 DSH/Codex），插话退役为 Alt+Enter
    expect(screen.getByTitle("排队发送（Enter）· Alt+Enter 插话调整")).toBeTruthy();
  });

  it("Shift 按住时 title 切纠正发送；空闲时回退 composer.send", () => {
    renderT(
      <ComposerInputRow
        taRef={nullRef}
        text="hi"
        onTextChange={noop}
        onPaste={noop}
        onKeyDown={noop}
        placeholder="p"
        disabled={false}
        running
        composerHeightFixed={false}
        dragOver={false}
        shiftHeld
        queueLen={0}
        pendingPaste={0}
        attachmentsCount={0}
        onDrop={noop}
        onDragOver={noop}
        onDragLeave={noop}
        onStop={noop}
        onSubmit={noop}
        onQueue={noop}
      />,
    );
    expect(screen.getByTitle("纠正发送（Shift+Enter）")).toBeTruthy();
    cleanup();
    renderT(
      <ComposerInputRow
        taRef={nullRef}
        text="hi"
        onTextChange={noop}
        onPaste={noop}
        onKeyDown={noop}
        placeholder="p"
        disabled={false}
        running={false}
        composerHeightFixed={false}
        dragOver={false}
        shiftHeld={false}
        queueLen={0}
        pendingPaste={0}
        attachmentsCount={0}
        onDrop={noop}
        onDragOver={noop}
        onDragLeave={noop}
        onStop={noop}
        onSubmit={noop}
        onQueue={noop}
      />,
    );
    expect(screen.getByTitle("发送（Enter）")).toBeTruthy();
  });
});

describe("ComposerToolbar i18n 冒烟", () => {
  afterEach(cleanup);

  it("参数钮显示当前取值，弹出层内权限/思考徽标与截图 title 走字典（zh）", () => {
    renderT(
      <ComposerToolbar
        cwd="/ws"
        workspaceName="ws"
        workspaceMenuOpen={false}
        onToggleWorkspaceMenu={noop}
        workspaceAnchorRef={{ current: null } as React.RefObject<HTMLDivElement>}
        running={false}
        pendingPaste={0}
        captureBusy={false}
        onPickFiles={noop}
        onScreenshot={noop}
        permLevel="ask"
        onSetPermLevel={noop}
        thinkLevel="normal"
        onSetThinkLevel={noop}
      />,
    );
    // 简化批：6 chip 收进「参数」钮——先验常驻面，再开弹出层验 chip 文案
    expect(screen.getByTitle("截图：捕获屏幕并裁剪附加")).toBeTruthy();
    expect(screen.getByText("/ 命令")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "会话参数（权限级别 · 思考深度）" }));
    expect(screen.getByTestId("composer-params-menu")).toBeTruthy();
    expect(screen.getByText("询问")).toBeTruthy();
    expect(screen.getByText("自动")).toBeTruthy();
    expect(screen.getByText("标准")).toBeTruthy();
    // 弹出层分组标签走字典
    expect(screen.getByText("权限级别")).toBeTruthy();
    expect(screen.getByText("思考深度")).toBeTruthy();
  });
});

describe("ComposerDragOverlay i18n 冒烟", () => {
  afterEach(cleanup);

  it("show=true 显示释放提示（zh/en 各渲染一次）", () => {
    renderT(<ComposerDragOverlay show />);
    expect(screen.getByText("释放以添加文件")).toBeTruthy();
    cleanup();
    renderT(<ComposerDragOverlay show />, "en");
    expect(screen.getByText("Release to add files")).toBeTruthy();
  });
});

describe("Composer i18n 冒烟", () => {
  afterEach(() => {
    cleanup();
    localStorage.removeItem("gaea.work.layoutPreferences.v1");
  });

  it("上下文状态通过插槽进入输入卡底部工具栏，不再生成独立 meta 行", () => {
    renderT(
      <Composer
        running={false}
        cwd="/ws"
        onSend={noop}
        onCancel={() => undefined}
        onPickFolder={async () => "/ws"}
        contextStatus={<button type="button" data-testid="ctx-slot">剩余 90%</button>}
      />,
    );
    const slot = screen.getByTestId("ctx-slot");
    expect(slot.closest(".office-composer-toolbar")).toBeTruthy();
    expect(slot.closest(".office-toolbar-context")).toBeTruthy();
    expect(document.querySelector(".office-composer-meta")).toBeNull();
  });

  it("旧版矮输入框持久化值不再生效，新 UI 使用完整输入卡基线", () => {
    localStorage.setItem(
      "gaea.work.layoutPreferences.v1",
      JSON.stringify({ sizes: { composerHeight: 104, composerHeightV2: 104 } }),
    );
    renderT(
      <Composer
        running={false}
        cwd="/ws"
        onSend={noop}
        onCancel={() => undefined}
        onPickFolder={async () => "/ws"}
      />,
    );
    const card = document.querySelector(".office-composer-card") as HTMLElement;
    expect(card).toBeTruthy();
    expect(card.style.getPropertyValue("--composer-height")).toBe("164px");
    expect(card.classList.contains("flex")).toBe(true);
  });

  it("placeholder 走字典：空闲统一任务提示（zh/en）/运行中提示（zh）", () => {
    renderT(
      <Composer running={false} cwd="/ws" onSend={noop} onCancel={() => undefined} onPickFolder={async () => "/ws"} />,
    );
    expect(screen.getByPlaceholderText("描述任务，或拖入文件…")).toBeTruthy();
    cleanup();

    renderT(
      <Composer running cwd="/ws" onSend={noop} onCancel={() => undefined} onPickFolder={async () => "/ws"} />,
    );
    expect(screen.getByPlaceholderText("任务执行中… Enter 排队发送 · Alt+Enter 插话调整 · Shift+Enter 纠正")).toBeTruthy();
    cleanup();

    renderT(
      <Composer running={false} cwd="/ws" onSend={noop} onCancel={() => undefined} onPickFolder={async () => "/ws"} />,
      "en",
    );
    expect(screen.getByPlaceholderText("Describe a task, or drop a file…")).toBeTruthy();
  });
});
