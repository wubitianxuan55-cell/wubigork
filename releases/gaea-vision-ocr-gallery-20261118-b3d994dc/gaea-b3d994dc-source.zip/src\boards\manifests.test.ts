import { describe, expect, it, vi, beforeEach } from 'vitest'
import {
  canonicalBoards, menuBoards, navigateWhitelist, shortcutMap,
  DEFAULT_BOARD_ID, projectAnchorId, getBoard, boardLabel, resolveBoardIcon,
  normalizeManifests, deriveMenuBoards, deriveNavigateWhitelist,
  deriveShortcutMap, deriveBoard, deriveProjectAnchorId,
  loadBoardManifests, subscribeBoards, getActiveBoards,
  getActiveMenuBoards, getActiveNavigateWhitelist, getActiveShortcutMap,
  getActiveBoard,
  resetActiveBoardsForTest,
} from './manifests'
import { app } from '../gaea/lib/bridge'
import { registerPage, getPageComponent, listRegisteredPages, clearPageRegistry } from './pageRegistry'
import { boardSpace } from './space'

// 数据源 seam（§5.3 前端侧）：mock 掉 gaea/lib/bridge 的 app.GetBoardManifests，
// 隔离后端提供者，验证「后端优先 / 失败回退静态 / 差集归一」。其它桥接导出
// （BridgeError/onEvent 等）经 importOriginal 原样保留，仅替换 app。
vi.mock('../gaea/lib/bridge', async (importOriginal) => ({
  ...(await importOriginal()),
  app: { GetBoardManifests: vi.fn() },
}))

// vi.mock 不改 TS 静态类型（GetBoardManifests 仍是 Record<string, unknown>[]），
// 用 loosely typed 引用以便测试注入纯对象 fixture。
const getBoardManifestsMock = app.GetBoardManifests as unknown as {
  mockResolvedValue(v: unknown): void
  mockRejectedValue(e: unknown): void
  mockReset(): void
}

// 后端 GetBoardManifests 契约形态（对齐 internal/app/board/builtins.go）：
// 业务板块子集（含 cost 造价数据库 + code 独立入口 + pantheon + D7 knowledge），
// 无 home 壳层，weixin.page=""、label=微信助手（2026-10-31 去掉隐喻名）。
const BACKEND_FIXTURE = [
  { id: 'chat', label: '聊天', icon: 'MessageOutlined', page: 'ChatPage', lazy: true, keepAlive: true, layout: 'full', shortcut: 'ctrl+1', menuOrder: 1, inMenu: true, featureModel: 'chat' },
  { id: 'wenxue', label: '文学', icon: 'ReadOutlined', page: 'WenxuePage', lazy: true, keepAlive: true, layout: 'full', shortcut: 'ctrl+2', menuOrder: 2, inMenu: true, featureModel: 'wenxue' },
  { id: 'imagegen', label: '绘梦', icon: 'PictureOutlined', page: 'ImageGenPage', lazy: true, keepAlive: true, layout: 'padded', shortcut: 'ctrl+3', menuOrder: 3, inMenu: true, featureModel: 'imagegen' },
  { id: 'gaea', label: '办公', icon: 'ToolOutlined', page: 'GaeaPage', lazy: true, keepAlive: true, layout: 'full', shortcut: 'ctrl+4', menuOrder: 4, inMenu: true, featureModel: 'gaea' },
  { id: 'cost', label: '造价数据库', icon: 'AccountBookOutlined', page: 'CostLibraryPage', lazy: true, keepAlive: true, layout: 'padded', menuOrder: 5, inMenu: true, featureModel: 'cost' },
  { id: 'code', label: '编程', icon: 'CodeOutlined', page: 'ProgrammingPage', lazy: true, keepAlive: true, layout: 'padded', menuOrder: 6, inMenu: true, space: 'independent' },
  { id: 'pantheon', label: '众神殿', icon: 'CrownOutlined', page: 'PantheonPage', lazy: true, keepAlive: true, layout: 'full', menuOrder: 6, inMenu: true },
  { id: 'memoryhub', label: '记忆中枢', icon: 'DatabaseOutlined', page: 'MemoryHubPage', lazy: true, keepAlive: true, layout: 'padded', menuOrder: 7, inMenu: true },
  { id: 'modelcenter', label: '模型中心', icon: 'ApiOutlined', page: 'ModelCenterPage', lazy: true, keepAlive: true, layout: 'padded', menuOrder: 8, inMenu: true },
  { id: 'characterlib', label: '角色库', icon: 'TeamOutlined', page: 'CharacterLibraryPage', lazy: true, keepAlive: true, layout: 'padded', menuOrder: 9, inMenu: true, featureModel: 'characterlib' },
  { id: 'settings', label: '设置', icon: 'SettingOutlined', page: 'SettingsPage', lazy: true, keepAlive: true, layout: 'padded', menuOrder: 10, inMenu: false },
  { id: 'weixin', label: '微信助手', icon: 'WechatOutlined', page: '', lazy: false, keepAlive: true, layout: 'padded', menuOrder: 11, inMenu: false },
  { id: 'knowledge', label: '知识库', icon: 'BookOutlined', page: 'KnowledgePage', lazy: true, keepAlive: true, layout: 'padded', menuOrder: 8, inMenu: true, featureModel: 'knowledge' },
]

// 3.0 附 B 收敛映射回归：manifest 派生结果必须与旧 MainLayout 硬编码一致（像素级）。

describe('menuBoards（附 B #4：filter(inMenu) + sort(menuOrder)）', () => {
  it('菜单顺序：聊天 → … → 进度计划 → 文学 → 运行监测（共 13 项；文学 2026-11-15 接替退役小说板块的一级位）', () => {
    expect(menuBoards.map((b) => b.id)).toEqual([
      'chat', 'wenxue', 'imagegen', 'gaea', 'cost', 'pantheon', 'memoryhub', 'modelcenter', 'characterlib', 'weixin', 'schedule', 'runtime',
    ])
  })

  it('菜单文案与现状一致（含众神殿）', () => {
    expect(menuBoards.map((b) => b.label)).toEqual([
      '聊天', '文学', '绘梦', '办公', '造价数据库', '众神殿', '记忆中枢', '模型中心', '角色库', '微信助手', '进度计划', '运行监测',
    ])
  })

  it('菜单图标名与现状一致（antd 图标注册表可解析）', () => {
    const expected = ['MessageOutlined', 'ReadOutlined', 'PictureOutlined',
      'ToolOutlined', 'AccountBookOutlined', 'CrownOutlined', 'DatabaseOutlined', 'ApiOutlined', 'TeamOutlined', 'WechatOutlined',
      'ScheduleOutlined', 'MonitorOutlined']
    expect(menuBoards.map((b) => b.icon)).toEqual(expected)
    for (const b of menuBoards) {
      expect(resolveBoardIcon(b.icon), `icon ${b.icon} 可解析`).not.toBeNull()
    }
  })

  it('settings 不进菜单（inMenu=false）；weixin v4.4 起进菜单（inMenu=true）；2026-11-14 拍板 schedule 恢复一级板块（inMenu=true）', () => {
    expect(menuBoards.map((b) => b.id)).not.toContain('settings')
    expect(menuBoards.map((b) => b.id)).toContain('weixin')
    expect(menuBoards.map((b) => b.id)).toContain('schedule')
  })
})

describe('getActiveMenuBoards（一级导航合一 2026-10-26：全量菜单，不再按空间分域）', () => {
  it('全量序 = 全部 inMenu 板块（menuOrder 派生；首页已删除）', () => {
    expect(getActiveMenuBoards().map((b) => b.id)).toEqual([
      'chat', 'wenxue', 'imagegen', 'gaea', 'cost', 'pantheon', 'memoryhub', 'modelcenter', 'characterlib', 'weixin', 'schedule', 'runtime',
    ])
    expect(getActiveMenuBoards().map((b) => b.label)).toEqual([
      '聊天', '文学', '绘梦', '办公', '造价数据库', '众神殿', '记忆中枢', '模型中心', '角色库', '微信助手', '进度计划', '运行监测',
    ])
  })

  it('主 rail 剔除 independent（编程走 foot 单列）、settings（inMenu=false 右上入口）；schedule 2026-11-14 拍板起回主 rail', () => {
    const menus = getActiveMenuBoards()
    expect(menus.filter((b) => boardSpace(b) === 'independent')).toHaveLength(0)
    const ids = menus.map((b) => b.id)
    expect(ids).not.toContain('settings')
    expect(ids).toContain('schedule')
  })

  it('编程恢复到独立窗口分面，不重复占用主 rail', () => {
    const independent = getActiveBoards().filter((b) => boardSpace(b) === 'independent')
    expect(independent.map((b) => b.id)).toEqual(['code'])
    expect(getActiveMenuBoards().map((b) => b.id)).not.toContain('code')
  })
})

describe('navigateWhitelist（附 B #2：manifest 派生导航白名单）', () => {
  // 白名单与 inMenu 解耦——注册即可导航，inMenu 只控菜单。
  // settings 在 canonicalBoards 中 inMenu=false 但有隐式入口（右上角按钮），解耦后
  // 也进白名单 = 允许 NAVIGATE 直达（v4.164 前科根治，藏板块不再静默丢导航）。
  // 瘦身刀1（v4.168.0）曾把 schedule 藏出菜单；2026-11-14 拍板起 schedule 恢复一级
  // 板块（inMenu=true），白名单语义不变（注册即可导航）。
  it('注册即可导航：全部业务板块（仍含 inMenu=false 的 settings；首页已删除）', () => {
    expect(navigateWhitelist).toEqual([
      'chat', 'wenxue', 'imagegen', 'gaea', 'cost', 'code', 'pantheon', 'memoryhub', 'modelcenter', 'characterlib', 'settings', 'weixin', 'schedule', 'runtime',
    ])
  })
})

describe('shortcutMap（附 B #6：Ctrl+1~4 显式声明）', () => {
  it('ctrl+1~4 → chat/wenxue/imagegen/gaea（文学接替 novel 一级位）', () => {
    expect(shortcutMap['ctrl+1']).toBe('chat')
    expect(shortcutMap['ctrl+2']).toBe('wenxue')
    expect(shortcutMap['ctrl+3']).toBe('imagegen')
    expect(shortcutMap['ctrl+4']).toBe('gaea')
  })

  it('快捷键不依赖菜单数组顺序（声明式）', () => {
    const declared = canonicalBoards.filter((b) => b.shortcut)
    expect(declared.map((b) => b.shortcut)).toEqual(['ctrl+1', 'ctrl+2', 'ctrl+3', 'ctrl+4'])
  })
})

describe('layout / breadcrumb / default board（附 B #8/#9/#10）', () => {
  it('chat/gaea/pantheon = full（全出血），其余 = padded', () => {
    expect(getBoard('chat')?.layout).toBe('full')
    expect(getBoard('gaea')?.layout).toBe('full')
    expect(getBoard('pantheon')?.layout).toBe('full')
    for (const id of ['imagegen', 'cost', 'code', 'memoryhub', 'modelcenter', 'characterlib', 'settings', 'schedule']) {
      expect(getBoard(id)?.layout, id).toBe('padded')
    }
  })

  it('面包屑项目锚点 = wenxue（2026-11-15 文学接替 novel 锚点位）', () => {
    expect(projectAnchorId).toBe('wenxue')
    expect(getBoard('wenxue')?.breadcrumb?.anchorTo).toBe('wenxue')
  })

  it('首页已删除，启动页固定为办公', () => {
    expect(getBoard('home')).toBeUndefined()
    expect(DEFAULT_BOARD_ID).toBe('gaea')
    expect(getBoard(DEFAULT_BOARD_ID)?.page).toBe('GaeaPage')
  })

  it('settings 隐式入口：inMenu=false 但仍可达（附 B #12）', () => {
    expect(getBoard('settings')?.inMenu).toBe(false)
    expect(getBoard('settings')?.page).toBe('SettingsPage')
  })
})

describe('boardLabel（附 B #7：pageLabels = manifest.label）', () => {
  it('按 id 取显示名', () => {
    expect(boardLabel('chat')).toBe('聊天')
    expect(boardLabel('wenxue')).toBe('文学')
    expect(boardLabel('gaea')).toBe('办公')
  })
  it('未知 id 返回自身（安全退化）', () => {
    expect(boardLabel('__missing__')).toBe('__missing__')
  })
})


describe('normalizeManifests（板块差集归一：后端清单 + 静态字段兜底）', () => {
  it('过滤后端 knowledge（已并入记忆中枢）与已删除的 home 壳层', () => {
    const merged = normalizeManifests(BACKEND_FIXTURE)
    const ids = merged.map((b) => b.id)
    expect(ids).not.toContain('knowledge')
    expect(ids).not.toContain('home')
    expect(merged).toHaveLength(12)
  })

  it('差集 #3：weixin 以后端为准（page=""，label=微信助手，inMenu=false）', () => {
    const merged = normalizeManifests(BACKEND_FIXTURE)
    const wx = deriveBoard(merged, 'weixin')
    expect(wx?.page).toBe('')
    expect(wx?.label).toBe('微信助手')
    expect(wx?.inMenu).toBe(false)
  })

  it('重叠 id 后端字段优先：菜单顺序/文案与静态一致（knowledge 被过滤，不尾随）', () => {
    const menu = deriveMenuBoards(normalizeManifests(BACKEND_FIXTURE))
    expect(menu.map((b) => b.id)).toEqual([
      'chat', 'wenxue', 'imagegen', 'gaea', 'cost', 'code', 'pantheon', 'memoryhub', 'modelcenter', 'characterlib',
    ])
    expect(menu.map((b) => b.label)).toEqual([
      '聊天', '文学', '绘梦', '办公', '造价数据库', '编程', '众神殿', '记忆中枢', '模型中心', '角色库',
    ])
  })

  // 刀0 解耦：fixture 中 settings/weixin 均 inMenu=false 但已注册 → 进白名单
  // （settings 隐式入口、weixin 注册存在，注册即可导航）；home/knowledge
  // 已并入记忆中枢被过滤（不单列也不尾随）。
  it('注册即可导航：inMenu=false 的 settings/weixin 进白名单；home/knowledge 被过滤', () => {
    expect(deriveNavigateWhitelist(normalizeManifests(BACKEND_FIXTURE))).toEqual([
      'chat', 'wenxue', 'imagegen', 'gaea', 'cost', 'code', 'pantheon', 'memoryhub', 'modelcenter', 'characterlib', 'settings', 'weixin',
    ])
  })

  it('快捷键 ctrl+1~4 后端声明保留（像素回归）', () => {
    const sc = deriveShortcutMap(normalizeManifests(BACKEND_FIXTURE))
    expect(sc['ctrl+1']).toBe('chat')
    expect(sc['ctrl+2']).toBe('wenxue')
    expect(sc['ctrl+3']).toBe('imagegen')
    expect(sc['ctrl+4']).toBe('gaea')
  })

  it('布局：chat/gaea/pantheon=full，其余 padded', () => {
    const merged = normalizeManifests(BACKEND_FIXTURE)
    expect(deriveBoard(merged, 'chat')?.layout).toBe('full')
    expect(deriveBoard(merged, 'gaea')?.layout).toBe('full')
    expect(deriveBoard(merged, 'pantheon')?.layout).toBe('full')
    for (const id of ['imagegen', 'cost', 'code', 'memoryhub', 'modelcenter', 'characterlib', 'settings']) {
      expect(deriveBoard(merged, id)?.layout, id).toBe('padded')
    }
  })

  it('面包屑项目锚点回退 wenxue（fixture 无声明，走 ?? 锚点兜底）', () => {
    expect(deriveProjectAnchorId(normalizeManifests(BACKEND_FIXTURE))).toBe('wenxue')
  })

  it('knowledge 已被过滤：一级导航不并入（记忆中枢承载），图标注册表仍可解析', () => {
    expect(resolveBoardIcon('BookOutlined')).not.toBeNull()
    expect(deriveBoard(normalizeManifests(BACKEND_FIXTURE), 'knowledge')).toBeUndefined()
  })

  it('后端残留 home 清单时强制过滤（旧数据 fail-closed）', () => {
    const withHome = [
      { id: 'home', label: '首页', icon: 'HomeOutlined', page: 'home', lazy: false, keepAlive: true, layout: 'padded', menuOrder: 0, inMenu: true, isHome: true },
      ...BACKEND_FIXTURE,
    ]
    const merged = normalizeManifests(withHome)
    expect(merged.map((b) => b.id)).not.toContain('home')
  })

  it('空输入 → []（回退决策在 loadBoardManifests 层）', () => {
    expect(normalizeManifests([])).toEqual([])
  })
})

describe('loadBoardManifests（数据源 seam：后端优先 / fail-closed 回退静态）', () => {
  beforeEach(() => {
    resetActiveBoardsForTest()
    getBoardManifestsMock.mockReset()
  })

  it('后端成功 → 合并清单生效（home/knowledge 过滤）并通知订阅者', async () => {
    getBoardManifestsMock.mockResolvedValue(BACKEND_FIXTURE)
    const cb = vi.fn()
    const unsub = subscribeBoards(cb)
    const result = await loadBoardManifests()
    unsub()
    expect(result.map((b) => b.id)).not.toContain('home')
    expect(result.map((b) => b.id)).not.toContain('knowledge')
    expect(getActiveBoards()).toBe(result)
    expect(cb).toHaveBeenCalledTimes(1)
  })

  it('后端失败 → fail-closed 回退静态 canonicalBoards（壳层永远可用）', async () => {
    getBoardManifestsMock.mockRejectedValue(new Error('window.go 未注入（浏览器 dev mock）'))
    const result = await loadBoardManifests()
    expect(result).toBe(canonicalBoards)
    expect(getActiveBoards()).toBe(canonicalBoards)
    expect(getActiveMenuBoards().map((b) => b.id)).toEqual(menuBoards.map((b) => b.id))
  })

  it('后端返回空数组/非数组 → 回退静态清单', async () => {
    getBoardManifestsMock.mockResolvedValue([])
    expect(await loadBoardManifests()).toBe(canonicalBoards)
    getBoardManifestsMock.mockResolvedValue(undefined)
    expect(await loadBoardManifests()).toBe(canonicalBoards)
  })

  it('活动派生视图跟随合并清单（消费者侧：菜单/白名单/快捷键/布局）', async () => {
    getBoardManifestsMock.mockResolvedValue(BACKEND_FIXTURE)
    await loadBoardManifests()
    expect(getActiveMenuBoards().map((b) => b.id)).toEqual([
      'chat', 'wenxue', 'imagegen', 'gaea', 'cost', 'pantheon', 'memoryhub', 'modelcenter', 'characterlib',
    ])
    expect(getActiveNavigateWhitelist()).not.toContain('knowledge')
    expect(getActiveShortcutMap()['ctrl+4']).toBe('gaea')
    expect(getActiveBoard('knowledge')).toBeUndefined()
    expect(DEFAULT_BOARD_ID).toBe('gaea')
  })

  it('订阅退订后不再收到通知', async () => {
    getBoardManifestsMock.mockResolvedValue(BACKEND_FIXTURE)
    const cb = vi.fn()
    const unsub = subscribeBoards(cb)
    await loadBoardManifests()
    unsub()
    const before = cb.mock.calls.length
    await loadBoardManifests()
    expect(cb.mock.calls.length).toBe(before)
  })

  it('resetActiveBoardsForTest 恢复静态基线（测试隔离）', async () => {
    getBoardManifestsMock.mockResolvedValue(BACKEND_FIXTURE)
    await loadBoardManifests()
    // knowledge 过滤后活动清单是后端合并结果，引用与静态 fallback 不同
    expect(getActiveBoards()).not.toBe(canonicalBoards)
    resetActiveBoardsForTest()
    expect(getActiveBoards()).toBe(canonicalBoards)
  })
})

describe('canonicalBoards 一致性', () => {
  it('板块 id 唯一', () => {
    const ids = canonicalBoards.map((b) => b.id)
    expect(new Set(ids).size).toBe(ids.length)
  })
  it('菜单 menuOrder 唯一且连续', () => {
    const orders = menuBoards.map((b) => b.menuOrder)
    expect(new Set(orders).size).toBe(orders.length)
    expect(orders).toEqual([...orders].sort((a, b) => (a ?? 0) - (b ?? 0)))
  })
  it('全部板块 icon 名可被图标注册表解析', () => {
    for (const b of canonicalBoards) {
      expect(resolveBoardIcon(b.icon), `icon ${b.icon}（${b.id}）`).not.toBeNull()
    }
  })
  it('每个板块都声明了 page（PageRegistry 查找键）', () => {
    for (const b of canonicalBoards) {
      expect(b.page.length, `${b.id}.page 非空`).toBeGreaterThan(0)
    }
  })
})

describe('PageRegistry（附 B #3/#5：main.tsx 集中注册）', () => {
  it('registerPage/getPageComponent 往返', () => {
    clearPageRegistry()
    const Fake = () => null
    registerPage('ChatPage', Fake)
    expect(getPageComponent('ChatPage')).toBe(Fake)
    expect(listRegisteredPages()).toEqual(['ChatPage'])
  })
  it('未注册返回 undefined（走旧 pageComponents fallback）', () => {
    clearPageRegistry()
    expect(getPageComponent('NoSuchPage')).toBeUndefined()
  })
  it('重复注册覆盖（幂等）', () => {
    clearPageRegistry()
    const A = () => null
    const B = () => null
    registerPage('P', A)
    registerPage('P', B)
    expect(getPageComponent('P')).toBe(B)
  })
})
