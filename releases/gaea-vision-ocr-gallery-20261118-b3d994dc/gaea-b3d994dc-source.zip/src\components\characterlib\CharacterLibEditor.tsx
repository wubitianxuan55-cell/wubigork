// CharacterLibEditor.tsx — 角色库详情：档案册视图（相卡面板）
// 档案眉 → 立绘横幅 → 身份栏 + 卷宗正文 → 底部操作条
// 随机生成：顶部「随机补全 / 全部随机」，每个字段旁 ↻ 可单独随机（含性格）
import React, { useEffect, useMemo, useRef, useState } from 'react'
import { app } from '../../gaea/lib/bridge'
import {
  Modal, Input, Select, Switch, Slider, Typography, message, Button, Dropdown,
} from 'antd'
import {
  SaveOutlined, CloseOutlined, PictureOutlined, ThunderboltOutlined,
  ExperimentOutlined, RetweetOutlined, LoadingOutlined, IdcardOutlined,
  AimOutlined, SoundOutlined } from '@ant-design/icons'
import TisorRadar from '../TisorRadar'
import {
  saveCharacter, generateFill, generateRandom, generatePortrait, generatePortraitWithRef, generateCharacterSheet, scoreCharacterConsistency,
  type LibraryCharacter,
} from '../../api/characterlib'
import { readFileAsDataURL } from '../../api/image'
import { cancelImageGeneration } from '../../api/image'
import { useComfyTaskProgress } from '../imagegen/useComfyTaskProgress'
import { COMFY_NODE_LABELS } from '../imagegen/GenerationProgress'
import { PortraitImg } from './PortraitImg'
import { CHARACTER_STATUS_OPTIONS, characterStatusLabel } from '../../utils/characterStatus'
import { playVoicePreview, playCharacterVoiceLine, genderDefaultVoiceDesc, stopVoicePreview, resolveVoiceLine } from './voicePreview'
import { inShellEnv, pickImageAsDataUrl } from '../../gaea/lib/pickFile'
import './character-detail.css'

const { Text } = Typography
const { TextArea } = Input

const GENDER_OPTIONS = [
  { value: 'female', label: '女性' },
  { value: 'male', label: '男性' },
  { value: 'neutral', label: '中性其他' },
]

const ROLE_OPTIONS = [
  { value: 'protagonist', label: '主角' },
  { value: 'antagonist', label: '反派' },
  { value: 'supporting', label: '配角' },
  { value: 'minor', label: '龙套' },
]

// 角色状态枚举统一来自 utils/characterStatus（T6-7.5 状态收敛：非法值回退默认）
const STATUS_OPTIONS = CHARACTER_STATUS_OPTIONS

const DIM_META: { key: keyof LibraryCharacter['dims']; label: string; desc: string }[] = [
  { key: 'T', label: 'T 温柔', desc: '体贴与温度' },
  { key: 'I', label: 'I 主动', desc: '发起与推进' },
  { key: 'S', label: 'S 顺从', desc: '配合与依赖' },
  { key: 'O', label: 'O 独特', desc: '个性与表达' },
  { key: 'R', label: 'R 矜持', desc: '克制与距离' },
]

const KIND_META: Record<string, string> = {
  builtin: '内置',
  custom: '自定义',
  assistant: '助手',
}

const ROLE_LABELS: Record<string, string> = {
  protagonist: '主角', antagonist: '反派', supporting: '配角', minor: '龙套',
}

const GENDER_LABELS: Record<string, string> = {
  female: '女性', male: '男性', neutral: '中性',
}



// AI 可单独随机的字段 → 中文名（用于按钮 title 与提示）
const FIELD_LABELS: Record<string, string> = {
  personality: '性格',
  background: '背景',
  appearance: '外貌',
  figure: '身材',
  motivation: '动机',
  arc: '角色弧线',
  notes: '备注',
  tags: '标签',
  dialogueSamples: '对话样本',
  voiceGuide: '口吻指南',
  behaviorRules: '行为规则',
  emotionLogic: '情感逻辑',
  ttsLine: '专属台词',
}

// 本地即时随机的年龄池（无需 AI）
const AGE_POOL = [
  '17', '18', '19', '20', '21', '22', '23', '24', '25', '26',
  '27', '28', '29', '30', '31', '32', '34', '36', '38', '40', '45',
]

const pick = <T,>(arr: readonly T[]): T => arr[Math.floor(Math.random() * arr.length)]

interface Props {
  open: boolean
  character: LibraryCharacter | null
  projects: string[]
  onClose: () => void
  onSaved: (c: LibraryCharacter) => void
  isCurrentPersona?: boolean
  index?: number
}

function emptyDims() {
  return { T: 50, I: 50, S: 50, O: 50, R: 50 }
}

function toForm(c: LibraryCharacter | null): Partial<LibraryCharacter> {
  if (!c) return { tags: [], dialogueSamples: [], dims: emptyDims(), referenceImages: [], referenceScores: [] }
  return {
    ...c,
    tags: c.tags ?? [],
    dialogueSamples: c.dialogueSamples ?? [],
    dims: c.dims ?? emptyDims(),
    referenceImages: c.referenceImages ?? [],
    referenceScores: c.referenceScores ?? [],
  }
}

const CharacterLibEditor: React.FC<Props> = ({
  open, character, projects, onClose, onSaved,
  isCurrentPersona = false, index = 0,
}) => {
  const [form, setForm] = useState<Partial<LibraryCharacter>>(() => toForm(character))
  const [saving, setSaving] = useState(false)
  const [filling, setFilling] = useState(false)
  const [genAll, setGenAll] = useState(false)
  const [genDims, setGenDims] = useState(false)
  const [fieldGen, setFieldGen] = useState<string | null>(null)
  const [genPortrait, setGenPortrait] = useState(false)
  // 克隆音色清单（Breeze 服务在线才有内容；离线时下拉仅「自动」档）
  const [breezeVoices, setBreezeVoices] = useState<Array<{ id: string; seconds?: number }>>([])
  // 试听段合成/播放中（试听按钮 loading；合成用表单当前值，未保存也可试）
  const [voicePreviewing, setVoicePreviewing] = useState(false)
  useEffect(() => {
    if (!open) return
    void (async () => {
      try {
        const res = await app.BreezeListVoices() as { voices?: Array<{ id: string; seconds?: number }> }
        setBreezeVoices(Array.isArray(res?.voices) ? res.voices : [])
      } catch (_) {
        setBreezeVoices([])
      }
    })()
  }, [open])
  // 抽屉关闭/组件卸载即停试听段（防界面关了声音还在）
  useEffect(() => {
    if (!open) stopVoicePreview()
  }, [open])
  useEffect(() => () => stopVoicePreview(), [])
  const previewVoice = () => {
    const voiceId = ((form.ttsVoiceId ?? '') as string).trim()
    const desc = ((form.ttsDesc ?? '') as string).trim() || genderDefaultVoiceDesc(form.gender)
    const line = resolveVoiceLine({ name: form.name, ttsLine: form.ttsLine, dialogueSamples: form.dialogueSamples })
    setVoicePreviewing(true)
    const job = (form.id ?? '') !== ''
      // 已保存：走文件缓存链（命中播文件秒开，未命中合成落盘——「语音文件已生成」）
      ? playCharacterVoiceLine({
          id: form.id, name: form.name, ttsLine: form.ttsLine,
          ttsVoiceId: form.ttsVoiceId, ttsDesc: form.ttsDesc,
          gender: form.gender, dialogueSamples: form.dialogueSamples,
        })
      // 未保存新角色：无 id 无法落盘，临时实时试听（保存后即入文件缓存链）
      : playVoicePreview(line, voiceId, desc)
    void job.finally(() => setVoicePreviewing(false))
  }
  const [refGenIdx, setRefGenIdx] = useState<number | null>(null)
  const [sheetGen, setSheetGen] = useState(false)
  // 一致性评分进行中的参考图下标（v4.404，文字锚点 v1）
  const [scoreIdx, setScoreIdx] = useState<number | null>(null)
  const imageGenBusy = !!genPortrait || sheetGen
  // ComfyUI 生成进度（v4.406，FE6-06 收敛）：剧照/设定卡生成期间轮询同源快照，
  // 载入/排队可见——共用 useComfyTaskProgress（读失败保留上一帧，页面隐藏跳帧）
  const comfyProgress = useComfyTaskProgress(imageGenBusy)
  // 取消生成（v4.407）：走全局 CancelImageGeneration（context+/interrupt 双达）
  const handleCancelImageGen = async () => {
    try {
      await cancelImageGeneration()
    } catch { /* 取消失败静默——生成自身会结束或超时 */ }
  }
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (open) setForm(toForm(character))
  }, [open, character])

  const isNew = !character
  const kindLabel = character?.kind ? KIND_META[character.kind] || KIND_META.custom : KIND_META.custom
  const busy = saving || filling || genAll || genDims || !!fieldGen || refGenIdx !== null

  const patch = (p: Partial<LibraryCharacter>) => setForm(prev => ({ ...prev, ...p }))
  const patchTags = (v: string) => patch({ tags: v.split(/[,，]/).map(s => s.trim()).filter(Boolean) })
  const patchSamples = (v: string) => patch({ dialogueSamples: v.split('\n').map(s => s.trim()).filter(Boolean) })
  const patchDims = (key: keyof LibraryCharacter['dims'], v: number) => {
    setForm(prev => ({ ...prev, dims: { ...(prev.dims ?? emptyDims()), [key]: v } }))
  }

  const handleSave = async () => {
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return
    }
    setSaving(true)
    try {
      const saved = await saveCharacter({
        ...form,
        name: form.name.trim(),
        kind: form.kind || 'custom',
      })
      message.success(isNew ? '角色已创建' : '角色已保存')
      onSaved(saved)
      onClose()
    } catch (err: unknown) {
      message.error(`保存失败：${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setSaving(false)
    }
  }

  const handleFill = async () => {
    if (busy) return
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return
    }
    setFilling(true)
    try {
      const filled = await generateFill(form)
      const wasDimsDefault = !form.dims || (['T', 'I', 'S', 'O', 'R'] as const).every(k => form.dims![k] === 50)
      let filledCount = 0
      const textKeys = ['roleType', 'gender', 'age', 'personality', 'appearance', 'figure',
        'background', 'motivation', 'arc', 'status', 'notes', 'behaviorRules', 'emotionLogic'] as const
      for (const k of textKeys) {
        const f = form[k] as string | undefined
        const g = filled[k] as string | undefined
        if (!f?.trim() && g?.trim()) filledCount++
      }
      if (!(form.tags ?? []).length && (filled.tags ?? []).length) filledCount++
      const nowDims = filled.dims
      if (wasDimsDefault && nowDims && !(['T', 'I', 'S', 'O', 'R'] as const).every(k => nowDims[k] === 50)) {
        filledCount++
      }
      setForm(filled as Partial<LibraryCharacter>)
      message.success(filledCount > 0
        ? `已补齐 ${filledCount} 处空缺，检查后保存`
        : '没有空缺字段需要补齐')
    } catch (err: unknown) {
      message.error(`补齐失败：${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setFilling(false)
    }
  }

  const handleRandomAll = async () => {
    if (busy) return
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return
    }
    setGenAll(true)
    try {
      const next = await generateRandom(form, 'all')
      setForm(next as Partial<LibraryCharacter>)
      message.success('已重新随机全部设定（含性格，姓名不变），检查后保存')
    } catch (err: unknown) {
      message.error(`全部随机失败：${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setGenAll(false)
    }
  }

  const randomizeDims = async () => {
    if (busy) return
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return
    }
    setGenDims(true)
    try {
      // AI 按当前性格生成一致的五维人格（后端 dims 随机目标）
      const next = await generateRandom(form, 'dims')
      setForm(next as Partial<LibraryCharacter>)
      message.success('已按性格随机五维人格，检查后保存')
    } catch {
      // 后端不可用时本地随机兜底（保持原行为）
      const next = {} as LibraryCharacter['dims']
      ;(['T', 'I', 'S', 'O', 'R'] as const).forEach(k => {
        next[k] = 25 + Math.floor(Math.random() * 66)
      })
      patch({ dims: next })
      message.success('已随机五维数值（本地兜底）')
    } finally {
      setGenDims(false)
    }
  }

  const randomizeField = async (key: string) => {
    if (busy) return
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return
    }
    // 枚举字段本地即时随机（无需 AI）
    if (key === 'gender') {
      patch({ gender: pick(GENDER_OPTIONS).value })
      message.success('已随机性别')
      return
    }
    if (key === 'roleType') {
      patch({ roleType: pick(ROLE_OPTIONS).value })
      message.success('已随机定位')
      return
    }
    if (key === 'status') {
      patch({ status: pick(STATUS_OPTIONS).value })
      message.success('已随机状态')
      return
    }
    if (key === 'age') {
      patch({ age: pick(AGE_POOL) })
      message.success('已随机年龄')
      return
    }
    // 文本字段走 AI 按字段随机
    const label = FIELD_LABELS[key] || key
    setFieldGen(key)
    try {
      const next = await generateRandom(form, key)
      setForm(next as Partial<LibraryCharacter>)
      message.success(`已重新随机${label}，检查后保存`)
    } catch (err: unknown) {
      message.error(`随机${label}失败：${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setFieldGen(null)
    }
  }

  const handleGeneratePortrait = async () => {
    if (busy) return
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return
    }
    setGenPortrait(true)
    try {
      const img = await generatePortrait(form)
      patch({ portraitUrl: img })
      message.success('剧照已生成，检查后保存')
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err)
      if (msg.includes('context canceled')) { message.info('已取消生成'); return }
      message.error(`剧照生成失败：${msg}`)
    } finally {
      setGenPortrait(false)
    }
  }

  // 以第 i 张参考图生成剧照（img2img 低 denoise 保留角色特征）：
  // 保存后参考图是本地文件路径，先读回 data URL 再传给后端。
  const handleGenerateWithRef = async (i: number) => {
    if (busy) return
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return
    }
    const ref = (form.referenceImages ?? [])[i]
    if (!ref) return
    setRefGenIdx(i)
    try {
      const dataUrl = ref.startsWith('data:') ? ref : await readFileAsDataURL(ref)
      const img = await generatePortraitWithRef(form, '', dataUrl)
      patch({ portraitUrl: img })
      message.success('剧照已按参考图生成，检查后保存')
    } catch (err: unknown) {
      message.error(`参考图生成失败：${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setRefGenIdx(null)
    }
  }

  // 设定卡生成共用前置守卫（单张/连发同口径）：名称非空+至少一张参考或剧照。
  const sheetGuard = (): boolean => {
    if (busy) return false
    if (!form.name?.trim()) {
      message.warning('角色名称不能为空')
      return false
    }
    if (!(form.referenceImages?.length) && !form.portraitUrl) {
      message.warning('设定卡生成需要至少一张参考图或剧照（以参考锚定人物）')
      return false
    }
    return true
  }

  // 生成设定卡（阶段三刀 C）：qedit 以参考图（最多 3 张）锚定人物；
  // variant 选模板（triptych 三视图并排默认/front·side·back 单视图分张/
  // sitting·action 姿势扩展）。产物直接追加进参考图列表（设定卡即最佳参考，
  // 画廊=参考图列表）。
  const handleGenerateSheet = async (variant: string) => {
    if (!sheetGuard()) return
    setSheetGen(true)
    try {
      const img = await generateCharacterSheet(form, variant)
      patch({ referenceImages: [...(form.referenceImages ?? []), img] })
      message.success('设定卡已生成并加入参考图（保存后落盘）')
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err)
      if (msg.includes('context canceled')) { message.info('已取消生成'); return }
      message.error(`设定卡生成失败：${msg}`)
    } finally {
      setSheetGen(false)
    }
  }

  // 三视图分张连发（v4.402）：正/侧/背三张排队生成，逐张追加进参考图列表
  // （每张完整分辨率，可单独作参考）。首张失败即中止（系统性故障：后端/权重，
  // 连发只会重复报错）；中途失败继续其余，结束如实汇总。
  const sheetSplitViews: Array<{ key: string; label: string }> = [
    { key: 'front', label: '正面' },
    { key: 'side', label: '左侧面' },
    { key: 'back', label: '背面' },
  ]
  const handleGenerateSheetSplit = async () => {
    if (!sheetGuard()) return
    setSheetGen(true)
    const failed: string[] = []
    let current = [...(form.referenceImages ?? [])]
    const closeLoading = message.loading(`分张生成中 0/${sheetSplitViews.length}…`, 0)
    try {
      for (let i = 0; i < sheetSplitViews.length; i++) {
        const view = sheetSplitViews[i]
        try {
          const img = await generateCharacterSheet(form, view.key)
          current = [...current, img]
          patch({ referenceImages: current })
        } catch (err: unknown) {
          const msg = err instanceof Error ? err.message : String(err)
          if (i === 0) {
            // 首张失败=系统性故障（后端/权重/参考），中止连发
            message.error(`分张中止（${view.label}失败：${msg}）——可先单张生成排查`)
            return
          }
          failed.push(view.label)
        }
      }
      if (failed.length) {
        message.warning(`分张完成，${failed.join('、')}失败（可从菜单单张重试）`)
      } else {
        message.success('三视图分张已全部生成并加入参考图（保存后落盘）')
      }
    } finally {
      closeLoading()
      setSheetGen(false)
    }
  }

  const removeRef = (i: number) => {
    const refs = [...(form.referenceImages ?? [])]
    refs.splice(i, 1)
    // 评分与参考图索引对齐（v4.411）：移除时同下标分数一并移除
    const scores = [...(form.referenceScores ?? [])]
    if (i < scores.length) scores.splice(i, 1)
    patch({ referenceImages: refs, referenceScores: scores })
  }

  // 一致性评分（v4.404）：视觉模型拿这张参考图对照角色文字设定打分；
  // 结果 Modal 呈现（总评+不一致点），score<60 提示补参考。
  const handleScoreRef = async (i: number) => {
    if (busy || scoreIdx !== null) return
    const ref = (form.referenceImages ?? [])[i]
    if (!ref) return
    setScoreIdx(i)
    try {
      const res = await scoreCharacterConsistency(form, ref)
      // 评分写回元数据（v4.411）：分数随 form 保存进角色库（与参考图索引对齐）
      const scores = [...(form.referenceScores ?? [])]
      while (scores.length < (form.referenceImages ?? []).length) scores.push(0)
      scores[i] = res.score
      patch({ referenceScores: scores })
      const low = res.score < 60
      Modal.info({
        title: `一致性评分：${res.score} 分`,
        content: (
          <div data-testid="consistency-score-modal">
            <p>{res.summary || '（无总评）'}</p>
            {(res.issues?.length ?? 0) > 0 && (
              <ul>{res.issues.map((it, k) => <li key={k}>{it}</li>)}</ul>
            )}
            {low && <p>建议补充不同角度/光照的参考图后再生成，提高一致性。</p>}
          </div>
        ),
      })
    } catch (err: unknown) {
      message.error(`一致性评分失败：${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setScoreIdx(null)
    }
  }

  // 选择本地图片 → data URL 追加进参考图列表（保存时后端会本地化落盘）。
  const onPickRefFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      const dataUrl = String(reader.result || '')
      if (!dataUrl) return
      patch({ referenceImages: [...(form.referenceImages ?? []), dataUrl] })
      message.success('参考图已添加，保存后生效')
    }
    reader.onerror = () => message.error('读取图片失败')
    reader.readAsDataURL(file)
  }

  // 添加参考图（审计刀A，v4.162 实证）：Wails 壳内 <input type=file>.click()
  // 不弹文件对话框（点击无反应），改走 GaeaPickFiles 系统对话框读回 data URL；
  // 浏览器回退原生 input 弹框。扩展名不合法由 pickImageAsDataUrl 抛错，这里
  // message 提示（fail-closed 不静默吞）；取消=返回 null 静默返回。
  const onPickRef = async () => {
    if (!inShellEnv()) { fileRef.current?.click(); return }
    try {
      const dataUrl = await pickImageAsDataUrl()
      if (!dataUrl) return
      patch({ referenceImages: [...(form.referenceImages ?? []), dataUrl] })
      message.success('参考图已添加，保存后生效')
    } catch (e) {
      message.error(`添加参考图失败：${e instanceof Error ? e.message : String(e)}`)
    }
  }

  const dims = useMemo(() => form.dims ?? emptyDims(), [form.dims])
  const heroMeta = [
    form.roleType ? ROLE_LABELS[form.roleType] || form.roleType : '',
    form.gender ? GENDER_LABELS[form.gender] || form.gender : '',
    form.age,
    // 非法状态回退默认（'Alive'），不泄露原始英文串
    form.status ? characterStatusLabel(form.status) : '',
  ].filter(Boolean).join(' · ')

  const fieldLabel = (t: string, diceKey?: string) => (
    <div className="cd-label-row">
      <label className="cd-label">{t}</label>
      {diceKey && (
        <Button
          size="small"
          type="text"
          className="cd-dice"
          icon={fieldGen === diceKey ? <LoadingOutlined /> : <RetweetOutlined />}
          loading={fieldGen === diceKey}
          disabled={busy && fieldGen !== diceKey}
          title={`随机生成${FIELD_LABELS[diceKey] || t}`}
          onClick={() => randomizeField(diceKey)}
        />
      )}
    </div>
  )

  const section = (title: string, children: React.ReactNode, action?: React.ReactNode) => (
    <section className="cd-sec">
      <h4 className="cd-sec-title">{title}{action}</h4>
      {children}
    </section>
  )

  return (
    <Modal
      open={open}
      onCancel={onClose}
      footer={null}
      closable={false}
      width={900}
      className="cd-modal"
      // 自定义眉部无 antd title：给对话框补可访问名（a11y，纯 attribute 零视觉变化）
      aria-label="角色档案编辑器"
      destroyOnHidden
      transitionName=""
      maskTransitionName=""
      styles={{
        content: { padding: 0, borderRadius: 16, overflow: 'hidden', background: 'var(--md-sys-color-surface-container)' },
        body: { padding: 0 },
      }}
    >
      <div className="cd">
        <div className="cd-scroll">
          {/* 档案眉 */}
          <div className="cd-head">
            <span className="cd-no">
              {isNew ? '新建档案' : `角色档案 · NO.${String(index + 1).padStart(3, '0')}`}
            </span>
            <div className="cd-head-right">
              {!isNew && <span className="cd-kind">{kindLabel}</span>}
              {form.chatEnabled && (
                <span className="cd-chat"><i className="cd-chat-dot" />可聊天</span>
              )}
              {isCurrentPersona && <span className="cd-current">当前人格</span>}
              <Button type="text" size="small" icon={<CloseOutlined />} title="关闭" aria-label="关闭" onClick={onClose} className="cd-close" />
            </div>
          </div>

          <div className="cd-body">
            {/* 身份栏 */}
            <aside className="cd-rail">
              {/* 立绘档案卡（竖向 3:4，剧照完整可见） */}
              <div className="cd-hero cd-sheen">
                {form.portraitUrl ? (
                  <PortraitImg className="cd-hero-img" src={form.portraitUrl} alt={form.name || '角色立绘'} />
                ) : (
                  <div className="cd-hero-ph">{form.name?.slice(0, 1) || '?'}</div>
                )}
                <div className="cd-hero-shade" />
                <div className="cd-hero-gens">
                  <Button
                    size="small"
                    icon={<PictureOutlined />}
                    loading={genPortrait}
                    disabled={busy}
                    onClick={handleGeneratePortrait}
                    className="cd-hero-gen"
                    title="按角色设定生成剧照"
                  >
                    生成剧照
                  </Button>
                  <Dropdown.Button
                    size="small"
                    icon={<IdcardOutlined />}
                    loading={sheetGen}
                    disabled={busy}
                    onClick={() => void handleGenerateSheet('triptych')}
                    menu={{
                      items: [
                        { key: 'triptych', label: '三视图并排' },
                        { key: 'front', label: '正面全身' },
                        { key: 'side', label: '左侧面全身' },
                        { key: 'back', label: '背面全身' },
                        { key: 'sitting', label: '坐姿' },
                        { key: 'action', label: '动态姿势' },
                        { type: 'divider' },
                        { key: 'split3', label: '三视图分张（连发）' },
                      ],
                      onClick: e =>
                        void (e.key === 'split3' ? handleGenerateSheetSplit() : handleGenerateSheet(e.key)),
                    }}
                    className="cd-hero-gen"
                    data-testid="gen-character-sheet"
                    title="以参考图生成设定卡（Qwen 参考编辑，本地 ComfyUI）——主按钮三视图并排，箭头选模板"
                  >
                    生成设定卡
                  </Dropdown.Button>
                </div>
                {imageGenBusy && (comfyProgress.status === 'running' || comfyProgress.status === 'queued') && (
                  <div className="cd-hero-progress" data-testid="cd-comfy-progress" aria-live="polite">
                    {comfyProgress.status === 'queued'
                      ? '排队中（前有任务）'
                      : comfyProgress.node
                        ? `${COMFY_NODE_LABELS[comfyProgress.node] || comfyProgress.node} · 已用时 ${comfyProgress.elapsed}s`
                        : `生成中 · 已用时 ${comfyProgress.elapsed}s`}
                    <Button
                      size="small"
                      type="text"
                      className="cd-progress-cancel"
                      data-testid="cd-cancel-gen"
                      aria-label="取消生成"
                      title="取消生成（中断 ComfyUI 当前任务）"
                      onClick={() => void handleCancelImageGen()}
                    >
                      取消
                    </Button>
                  </div>
                )}
                <div className="cd-hero-info">
                  <h2 className="cd-hero-name">{form.name || '未命名角色'}</h2>
                  {heroMeta && <p className="cd-hero-meta">{heroMeta}</p>}
                </div>
              </div>

              <div className="cd-field">
                {fieldLabel('名称 *')}
                <Input size="small" value={form.name ?? ''} onChange={e => patch({ name: e.target.value })}
                  placeholder="角色名" />
              </div>
              <div className="cd-field">
                {fieldLabel('立绘 URL')}
                <Input size="small" value={form.portraitUrl ?? ''}
                  onChange={e => patch({ portraitUrl: e.target.value })}
                  placeholder="https://... 或 data:image/..." />
                {form.portraitUrl && (
                  <PortraitImg className="cd-thumb" src={form.portraitUrl} alt="立绘预览" />
                )}
              </div>
              <div className="cd-grid2">
                <div className="cd-field">
                  {fieldLabel('性别', 'gender')}
                  <Select size="small" value={form.gender ?? ''} style={{ width: '100%' }}
                    onChange={v => patch({ gender: v })} options={GENDER_OPTIONS} allowClear />
                </div>
                <div className="cd-field">
                  {fieldLabel('年龄', 'age')}
                  <Input size="small" value={form.age ?? ''} onChange={e => patch({ age: e.target.value })}
                    placeholder="23 / 外观二十五六" />
                </div>
                <div className="cd-field">
                  {fieldLabel('定位', 'roleType')}
                  <Select size="small" value={form.roleType ?? ''} style={{ width: '100%' }}
                    onChange={v => patch({ roleType: v })} options={ROLE_OPTIONS} allowClear />
                </div>
                <div className="cd-field">
                  {fieldLabel('状态', 'status')}
                  <Select size="small" value={form.status ?? ''} style={{ width: '100%' }}
                    onChange={v => patch({ status: v })} options={STATUS_OPTIONS} allowClear />
                </div>
              </div>
              <div className="cd-field">
                {fieldLabel('标签', 'tags')}
                <Input size="small" value={(form.tags ?? []).join('，')} onChange={e => patchTags(e.target.value)}
                  placeholder="女主，剑修" />
                {(form.tags ?? []).length > 0 && (
                  <div className="cd-tags">
                    {(form.tags ?? []).slice(0, 6).map(t => <span key={t} className="cd-tag">#{t}</span>)}
                  </div>
                )}
              </div>
              <div className="cd-radar">
                <div className="cd-radar-head">
                  <Text className="cd-radar-title">五维人格</Text>
                  <Button size="small" type="text" className="cd-dice"
                    icon={genDims ? <LoadingOutlined /> : <RetweetOutlined />}
                    loading={genDims}
                    title="按性格随机五维人格" disabled={busy && !genDims} onClick={() => void randomizeDims()} />
                </div>
                <TisorRadar dims={dims} size={132} color="var(--gaea-glow)" />
                <div className="cd-dims">
                  {DIM_META.map(d => (
                    <div key={d.key} className="cd-dim">
                      <Text className="cd-dim-label" title={d.desc}>{d.label}</Text>
                      <Slider min={0} max={100} value={dims[d.key] ?? 50}
                        onChange={v => patchDims(d.key, Number(v))} tooltip={{ formatter: (v?: number) => `${v}` }} />
                      <Text className="cd-dim-val">{dims[d.key] ?? 50}</Text>
                    </div>
                  ))}
                </div>
              </div>
              <div className="cd-chat-toggle">
                <div>
                  <Text className="cd-toggle-title">可聊天</Text>
                  <div className="cd-toggle-desc">出现在聊天板块的人格列表</div>
                </div>
                <Switch size="small" checked={!!form.chatEnabled} onChange={v => patch({ chatEnabled: v })} />
              </div>
            </aside>

            {/* 卷宗正文 */}
            <main className="cd-main">
              {/* 随机生成工具条 */}
              <div className="cd-genbar">
                <span className="cd-genbar-title">随机生成</span>
                <Button size="small" icon={<ThunderboltOutlined />} loading={filling}
                  disabled={busy && !filling} onClick={handleFill}
                  title="仅补齐空缺字段，保留已有内容">随机补齐</Button>
                <Button size="small" icon={<ExperimentOutlined />} loading={genAll}
                  disabled={busy && !genAll} onClick={handleRandomAll}
                  title="重新随机全部设定（含性格），姓名不变">全部随机</Button>
                <span className="cd-genbar-hint">字段旁 ↻ 可单独随机</span>
              </div>

              {section('小说设定', (
                <div className="cd-fields">
                  {[
                    { key: 'personality' as const, label: '性格', rows: 2 },
                    { key: 'background' as const, label: '背景', rows: 2 },
                    { key: 'appearance' as const, label: '外貌', rows: 2 },
                    { key: 'figure' as const, label: '身材体型', rows: 1 },
                    { key: 'motivation' as const, label: '动机', rows: 2 },
                    { key: 'arc' as const, label: '角色弧线', rows: 2 },
                  ].map(f => (
                    <div key={f.key} className="cd-field">
                      {fieldLabel(f.label, f.key)}
                      <TextArea className="cd-area" size="small" rows={f.rows} value={form[f.key] ?? ''}
                        onChange={e => patch({ [f.key]: e.target.value })} />
                    </div>
                  ))}
                </div>
              ))}
              {section('参考图', (
                <div className="cd-refs">
                  {(form.referenceImages ?? []).length > 0 && (
                    <div className="cd-refs-grid">
                      {(form.referenceImages ?? []).map((ref, i) => (
                        <div key={`${ref}-${i}`} className="cd-ref">
                          <PortraitImg className="cd-ref-img" src={ref} alt={`参考图 ${i + 1}`} />
                          {(form.referenceScores ?? [])[i] > 0 && (
                            <span
                              className={`cd-ref-score ${((form.referenceScores ?? [])[i] ?? 0) >= 80 ? 'cd-ref-score-good' : ((form.referenceScores ?? [])[i] ?? 0) >= 60 ? 'cd-ref-score-mid' : 'cd-ref-score-low'}`}
                              data-testid={`ref-score-${i}`}
                            >
                              {(form.referenceScores ?? [])[i]}分
                            </span>
                          )}
                          <div className="cd-ref-actions">
                            <Button
                              size="small"
                              type="text"
                              className="cd-dice"
                              icon={scoreIdx === i ? <LoadingOutlined /> : <AimOutlined />}
                              loading={scoreIdx === i}
                              disabled={(busy && scoreIdx !== i) || (scoreIdx !== null && scoreIdx !== i)}
                              title="一致性评分（视觉模型对照文字设定）"
                              data-testid={`score-ref-${i}`}
                              onClick={() => void handleScoreRef(i)}
                            />
                            <Button
                              size="small"
                              type="text"
                              className="cd-dice"
                              icon={refGenIdx === i ? <LoadingOutlined /> : <ThunderboltOutlined />}
                              loading={refGenIdx === i}
                              disabled={busy && refGenIdx !== i}
                              title="以这张参考图生成剧照（img2img）"
                              onClick={() => void handleGenerateWithRef(i)}
                            />
                            <Button
                              size="small"
                              type="text"
                              className="cd-dice"
                              icon={<CloseOutlined />}
                              title="移除参考图"
                              disabled={busy}
                              onClick={() => removeRef(i)}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  <input ref={fileRef} type="file" accept="image/*" hidden onChange={onPickRefFile} />
                  <div className="cd-refs-foot">
                    <Button size="small" icon={<PictureOutlined />} disabled={busy} onClick={() => void onPickRef()}>
                      添加参考图
                    </Button>
                    <span className="cd-refs-hint">以参考图生成立绘可保留角色特征（img2img，需 krea2 / z-image-turbo）</span>
                  </div>
                </div>
              ))}
              {section('对话样本', (
                <div className="cd-field">
                  {fieldLabel('每行一条，供 AI 说话节拍', 'dialogueSamples')}
                  <TextArea className="cd-area" size="small" rows={3} value={(form.dialogueSamples ?? []).join('\n')}
                    onChange={e => patchSamples(e.target.value)}
                    placeholder={'「你……你才不是为我来的吧。」\n「剑修不问红尘。」'} />
                </div>
              ))}
              {section('备注', (
                <div className="cd-field">
                  <TextArea className="cd-area" size="small" rows={2} value={form.notes ?? ''}
                    onChange={e => patch({ notes: e.target.value })} />
                </div>
              ), (
                <Button size="small" type="text" className="cd-dice" icon={<RetweetOutlined />}
                  title="随机生成备注" disabled={busy} onClick={() => randomizeField('notes')} />
              ))}
              {section('聊天设定', (
                <div className="cd-fields">
                  {[
                    { key: 'voiceGuide' as const, label: '口吻指南', rows: 3, ph: '角色怎么说话：语气、用词、节奏…' },
                    { key: 'behaviorRules' as const, label: '行为规则', rows: 2, ph: '互动中的行为边界与习惯' },
                    { key: 'emotionLogic' as const, label: '情感逻辑', rows: 2, ph: '对用户的情绪反应模式' },
                  ].map(f => (
                    <div key={f.key} className="cd-field">
                      {fieldLabel(f.label, f.key)}
                      <TextArea className="cd-area" size="small" rows={f.rows} value={form[f.key] ?? ''} placeholder={f.ph}
                        onChange={e => patch({ [f.key]: e.target.value })} />
                    </div>
                  ))}
                  {/* 角色音色预设（TTS）：聊天选中该角色即用其音色（breeze 合成）；
                      专属语音台词=试听段念的词（AI 可随机设计，空时回退对话样本首条/姓名问候） */}
                  <div className="cd-field">
                    <div className="cd-label-row">
                      <label className="cd-label">专属语音台词</label>
                      <Button size="small" type="text" className="cd-dice"
                        icon={fieldGen === 'ttsLine' ? <LoadingOutlined /> : <RetweetOutlined />}
                        loading={fieldGen === 'ttsLine'}
                        disabled={busy && fieldGen !== 'ttsLine'}
                        title="随机生成专属台词"
                        onClick={() => randomizeField('ttsLine')} />
                      <Button size="small" type="text" icon={<SoundOutlined />} loading={voicePreviewing}
                        onClick={previewVoice}
                        title={form.id ? '试听台词语音（首次生成语音文件，之后秒开）' : '未保存角色临时试听（保存后即入语音文件缓存）'}>试听</Button>
                    </div>
                    <TextArea className="cd-area" size="small" rows={2} value={form.ttsLine ?? ''}
                      placeholder="这个角色的签名台词/开场白；留空试听自动取首条对话样本"
                      onChange={e => patch({ ttsLine: e.target.value })} />
                  </div>
                  <div className="cd-field">
                    <div className="cd-label-row"><label className="cd-label">克隆音色</label></div>
                    <Select size="small" value={form.ttsVoiceId ?? ''} style={{ width: '100%' }}
                      onChange={v => patch({ ttsVoiceId: String(v) })}
                      options={[
                        { value: '', label: '自动（按下方音色描述）' },
                        ...breezeVoices.map(v => ({ value: v.id, label: `${v.id}（${(v.seconds ?? 0).toFixed(1)}s）` })),
                      ]}
                      notFoundContent="无克隆音色（需 Breeze 服务运行）" />
                  </div>
                  <div className="cd-field">
                    <div className="cd-label-row"><label className="cd-label">音色描述</label></div>
                    <TextArea className="cd-area" size="small" rows={2} value={form.ttsDesc ?? ''}
                      placeholder={`按人格写的音色描述；留空按性别缺省（${form.gender === 'male' ? '沉稳清晰的青年男性声线' : '温柔清晰的青年女性声线'}）`}
                      onChange={e => patch({ ttsDesc: e.target.value })} />
                  </div>
                </div>
              ))}
              {form.assistantId && (
                <div className="cd-note">
                  聊天通道：assistantId={form.assistantId}（微信通道配置以助手记录为准）
                  <span style={{ color: 'var(--md-sys-color-warning)', fontSize: 11 }}>微信通道为个人使用实验功能（beta），凭证失效时不自动恢复，请以桌面聊天为主</span>
                </div>
              )}
            </main>
          </div>
        </div>

        {/* 底部操作条 */}
        <div className="cd-foot">
          <div className="cd-foot-meta">
            {projects.length > 0 && (
              <span>被 {projects.length} 个项目引用：{projects.join('、')}</span>
            )}
          </div>
          <div className="cd-foot-actions">
            <Button icon={<CloseOutlined />} onClick={onClose}>取消</Button>
            <Button type="primary" icon={<SaveOutlined />} loading={saving} onClick={handleSave} className="cd-save">
              保存
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  )
}

export default CharacterLibEditor
