import React, { useState, useRef, useEffect, useMemo } from 'react'
import { Button, Input, Popconfirm, Typography, Tooltip } from 'antd'
import {
  PlusOutlined,
  DeleteOutlined,
  MessageOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  SearchOutlined,
} from '@ant-design/icons'
import { C } from '../utils/theme'
import { filterChatTopics } from '../utils/chatTopics'
import { groupChatTopics } from '../utils/chatTopicGroups'
import { relativeTime } from '../gaea/lib/time'

export interface Topic {
  id: string
  title: string
  createdAt: number
  /** topic mode: 'plain' or personaID */
  mode?: string
  /** display label for the mode badge (empty string for plain) */
  modeLabel?: string
  /** first message preview */
  preview?: string
  /** 最近活跃时间（ms），用于列表排序展示 */
  updatedAt?: number
}

interface ChatTopicSidebarProps {
  topics: Topic[]
  activeId: string
  onSelect: (id: string) => void
  onCreate: () => void
  onDelete: (id: string) => void
  onRename: (id: string, title: string) => void
  /** 折叠态：窄栏只保留切换/新建按钮，随左侧面板一起折叠 */
  collapsed?: boolean
  onToggle?: () => void
}

const ChatTopicSidebar: React.FC<ChatTopicSidebarProps> = ({
  topics, activeId, onSelect, onCreate, onDelete, onRename,
  collapsed = false, onToggle,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editText, setEditText] = useState('')
  const [query, setQuery] = useState('')
  const editRef = useRef<React.ComponentRef<typeof Input>>(null)

  useEffect(() => {
    if (editingId && editRef.current) {
      editRef.current.focus()
    }
  }, [editingId])

  const startEdit = (topic: Topic) => {
    setEditingId(topic.id)
    setEditText(topic.title)
  }

  const commitEdit = () => {
    if (editingId && editText.trim()) {
      onRename(editingId, editText.trim())
    }
    setEditingId(null)
    setEditText('')
  }

  // v4.350：过滤 memo 化；行 hover 高亮（删除钮显隐）改纯 CSS——此前
  // hoveredId state 使鼠标每扫过一行就全列表重渲染。
  const visibleTopics = useMemo(() => filterChatTopics(topics, query), [topics, query])
  // G1 时间分组（chat-demo sessionGroups 对齐）：今天/昨天/7天/30天/按月。
  // 分钟级重算代价低（纯函数），跨天过期由下次任意渲染自然修正（与 DeepSeek
  // 半夜定时器不同：分组标签只受 updatedAt 影响，过期只差标签新鲜度，可接受）。
  const groups = useMemo(() => groupChatTopics(visibleTopics, Date.now()), [visibleTopics])

  return (
    <div className={`chat-topic-sidebar v3-panel${collapsed ? ' is-collapsed' : ''}`}>
      {collapsed ? (
        /* 折叠窄栏：切换按钮 + 新建会话 */
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, paddingTop: 10 }}>
          {onToggle && (
            <Tooltip title="展开会话列表" placement="right">
              <Button
                type="text"
                size="small"
                icon={<MenuUnfoldOutlined />}
                onClick={onToggle}
                aria-label="展开会话列表"
                style={{ color: C('color-text-secondary'), borderRadius: 8 }}
              />
            </Tooltip>
          )}
          <Tooltip title="新建会话" placement="right">
            <Button
              type="text"
              size="small"
              icon={<PlusOutlined />}
              onClick={onCreate}
              aria-label="新建会话"
              style={{ color: C('color-primary'), borderRadius: 8 }}
            />
          </Tooltip>
        </div>
      ) : (
        <>
          {/* header: title + new topic button + collapse */}
          <div className="chat-topic-head">
            <Typography.Text strong style={{ color: C('color-text'), fontSize: 13.5 }}>
              <MessageOutlined style={{ marginRight: 8, color: C('color-primary') }} />
              会话
            </Typography.Text>
            <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              {onToggle && (
                <Tooltip title="折叠会话列表" placement="bottom">
                  <Button
                    type="text"
                    size="small"
                    icon={<MenuFoldOutlined />}
                    onClick={onToggle}
                    aria-label="折叠会话列表"
                    style={{ color: C('color-text-secondary'), borderRadius: 8 }}
                  />
                </Tooltip>
              )}
              <Tooltip title="新建会话" placement="bottom">
                <Button
                  type="text"
                  size="small"
                  icon={<PlusOutlined />}
                  onClick={onCreate}
                aria-label="新建会话"
                  style={{ color: C('color-primary'), borderRadius: 8 }}
                />
              </Tooltip>
            </div>
          </div>

          {/* session search */}
          <div style={{ padding: '0 12px 8px' }}>
            <Input
              size="small"
              allowClear
              prefix={<SearchOutlined style={{ color: C('color-text-secondary'), fontSize: 12 }} />}
              placeholder="搜索会话"
              aria-label="搜索会话"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              style={{
                background: C('color-bg-container'),
                borderColor: C('color-border'),
                color: C('color-text'),
                borderRadius: 8,
              }}
            />
          </div>

          {/* topic list */}
          <div style={{ flex: 1, overflow: 'auto', padding: '2px 8px 88px' }}>
            {visibleTopics.length === 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '48px 16px', textAlign: 'center' }}>
                <div style={{
                  width: 48, height: 48, borderRadius: 14,
                  background: `${C('color-primary')}10`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  marginBottom: 14,
                }}>
                  <MessageOutlined style={{ fontSize: 24, color: C('color-primary') }} />
                </div>
                <Typography.Text style={{ color: C('color-text-secondary'), fontSize: 13, marginBottom: 4 }}>
                  {query ? '无匹配会话' : '暂无会话'}
                </Typography.Text>
                <Typography.Text style={{ color: C('color-text-secondary'), fontSize: 12, opacity: 0.7 }}>
                  {query ? '换个关键词试试' : '点击 + 创建新对话'}
                </Typography.Text>
                {!query && (
                  <button type="button" className="chat-topic-empty-create" onClick={onCreate}>
                    <PlusOutlined aria-hidden /> 新建对话
                  </button>
                )}
              </div>
            ) : (
              <div>
                {groups.map((group) => (
                  <div key={group.key}>
                    <div className="chat-topic-group-head" aria-hidden="true"
                      style={{
                        padding: '8px 8px 4px', fontSize: 10.5, fontWeight: 600,
                        letterSpacing: 0.5, color: C('color-text-secondary'), opacity: 0.75,
                        userSelect: 'none',
                      }}>
                      {group.label}
                    </div>
                    {group.topics.map((topic) => {
              const active = topic.id === activeId
              return (
                <div
                  key={topic.id}
                  className={`chat-topic-item${active ? ' active' : ''}`}
                  /* 背景走 chat-board.css：active=primary-container，hover=surface-container-high；
                     删除钮显隐同样纯 CSS（.chat-topic-del），无 JS hover state */
                >
                  {/* title + preview (double-click to edit) */}
                  {editingId === topic.id ? (
                    <div className="chat-topic-select is-editing">
                      <Input
                        ref={editRef}
                        size="small"
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        onBlur={commitEdit}
                        onPressEnter={commitEdit}
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') {
                            e.preventDefault()
                            setEditingId(null)
                            setEditText('')
                          }
                        }}
                        onClick={(e) => e.stopPropagation()}
                        style={{ background: C('color-bg-container'), borderColor: C('color-primary'), color: C('color-text'), borderRadius: 6 }}
                      />
                    </div>
                  ) : (
                    <button
                      type="button"
                      className="chat-topic-select"
                      aria-label={`打开会话：${topic.title}`}
                      aria-current={active ? 'true' : undefined}
                      title={`${topic.title}（双击或按 F2 重命名）`}
                      onClick={() => onSelect(topic.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'F2') {
                          e.preventDefault()
                          startEdit(topic)
                        }
                      }}
                    >
                        <span className="chat-topic-title-row">
                          <Typography.Text
                            ellipsis
                            onDoubleClick={() => startEdit(topic)}
                            style={{
                              color: active ? 'var(--md-sys-color-on-primary-container)' : C('color-text'),
                              fontSize: 12.5,
                              fontWeight: active ? 600 : 500,
                              flex: 1,
                              lineHeight: '18px',
                              minWidth: 0,
                            }}
                          >
                            {topic.title}
                          </Typography.Text>
                          {topic.modeLabel && (
                            <span className="chat-topic-badge" title={`${topic.modeLabel} 模式`}>
                              {topic.modeLabel}
                            </span>
                          )}
                          <span
                            className="chat-topic-time"
                            title={new Date(topic.updatedAt || topic.createdAt).toLocaleString()}
                          >
                            {relativeTime(topic.updatedAt || topic.createdAt)}
                          </span>
                        </span>
                        {topic.preview && (
                          <span className="chat-topic-preview" title={topic.preview}>
                            {topic.preview}
                          </span>
                        )}
                    </button>
                  )}

                  {/* delete button — visible on hover / active（纯 CSS，见 chat-board.css） */}
                  <div
                    className="chat-topic-del"
                    style={{
                      width: 26, height: 26,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      flexShrink: 0, marginLeft: 4,
                    }}
                  >
                    <Popconfirm
                      title="确定删除此会话？"
                      onConfirm={(e) => { e?.stopPropagation(); onDelete(topic.id) }}
                      onCancel={(e) => e?.stopPropagation()}
                      okText="删除"
                      cancelText="取消"
                      placement="right"
                    >
                      <Button
                        type="text"
                        size="small"
                        icon={<DeleteOutlined style={{ fontSize: 13 }} />}
                        onClick={(e) => e.stopPropagation()}
                        aria-label={`删除会话：${topic.title}`}
                        style={{
                          color: active ? 'var(--md-sys-color-on-primary-container)' : C('color-text-secondary'),
                          width: 26, height: 26, padding: 0,
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          borderRadius: 6,
                        }}
                      />
                    </Popconfirm>
                  </div>
                </div>
              )
                })}
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}

// memo：topics 引用已由 ChatPage 的 topicList useMemo 稳定，回调均 useCallback——
// 流式打字期间（每 chunk 一次页面渲染）侧栏整体跳过重渲染。
export default React.memo(ChatTopicSidebar)
