// perf-guards.test.ts — 运行开销与布局结构守卫（v4.349 前端优化刀）
//
// Why：本刀修掉的三类问题都是「结构性」的——一旦有人把 memo 拆掉、
// 把心跳轮询加回来、或把 nowrap/行数上限删掉，功能测试不会红，只有用户
// 感受到卡顿/参差。此处按仓内既有 source-guard 风格（App.tokens.test.ts /
// contrast-hex.test.ts）把这些不变量钉死。
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

const read = (...p: string[]) => readFileSync(resolve(__dirname, ...p), 'utf8')

describe('主线程心跳：不再自带走 500ms 空转轮询（v4.349）', () => {
  const src = read('main.tsx')

  it('心跳戳由 rAF 探测循环维护（probe 每帧写 mainThreadBeatAt）', () => {
    expect(src).toContain('let mainThreadBeatAt = Date.now()')
    expect(src).toMatch(/probe[\s\S]{0,200}mainThreadBeatAt = Date\.now\(\)/)
  })

  it('诊断层读共享心跳戳，且不再自带 500ms 只写时间戳的 interval', () => {
    expect(src).not.toMatch(/setInterval\(\(\)\s*=>\s*\{\s*lastBeat = Date\.now\(\)\s*\},\s*500\)/)
    expect(src).toMatch(/Date\.now\(\) - mainThreadBeatAt/)
  })

  it('rAF 降级路径有兜底续跳（否则诊断层把已降级的正常态误报成卡死）', () => {
    const degradeBlock = src.slice(src.indexOf('const degrade ='), src.indexOf('// 持续探测'))
    expect(degradeBlock).toContain('mainThreadBeatAt = Date.now()')
  })
})

describe('主题令牌与 antd 主题对象 memo 化（v4.349）', () => {
  const src = read('App.tsx')

  it('getThemeTokens 包在 useMemo 里（否则每次渲染都换新令牌对象 → 主题 effect 重跑）', () => {
    expect(src).toMatch(/const tokens = useMemo\(\(\) => getThemeTokens\(/)
    expect(src).not.toMatch(/^\s*const tokens = getThemeTokens\(/m)
  })

  it('ConfigProvider theme 走 memo 对象，不再是内联字面量', () => {
    expect(src).toMatch(/const antdTheme = useMemo\(/)
    expect(src).toContain('<ConfigProvider theme={antdTheme}>')
  })
})

describe('启动页与最近文件单源守卫', () => {
  it('首页启动器已删除，MainLayout 默认直接进入办公', () => {
    const layout = read('layouts/MainLayout.tsx')
    expect(layout).not.toContain('ModuleLauncher')
    expect(layout).not.toContain('getActiveHomeBoard')
    expect(layout).toContain('useState<Page>(DEFAULT_BOARD_ID)')
    expect(read('boards/manifests.ts')).not.toContain("id: 'home', label: '首页'")
    expect(read('boards/manifests.ts')).toContain("DEFAULT_BOARD_ID = 'gaea'")
  })

  it('RecentFilesBar 同样订阅单源', () => {
    const src = read('gaea/components/RecentFilesBar.tsx')
    expect(src).toContain('useSyncExternalStore(subscribeRecentFiles, loadRecentFiles')
  })
})

describe('布局守卫（v4.349）', () => {
  it('.gsched 摘要 chip 不再被压缩换行（shrink-0 + whitespace-nowrap）', () => {
    const src = read('gaea/components/ScheduleFileCard.tsx')
    const chip = src.slice(src.indexOf('function StatChip'), src.indexOf('export function ScheduleFileCard'))
    expect(chip).toContain('shrink-0')
    expect(chip).toContain('whitespace-nowrap')
  })

  it('基线槽位行可换行、固定段不压缩（工期/时间戳）', () => {
    const src = read('schedule/BaselinesPanel.tsx')
    expect(src).toContain("flexWrap: 'wrap'")
    expect(src).toMatch(/总工期 \{b\.duration\} 天/)
    // 工期 + 时间戳两处固定段都带 nowrap/不可压缩
    expect(src.match(/whiteSpace: 'nowrap', flexShrink: 0/g)?.length).toBe(2)
  })

  // 海报墙描述行数上限守卫随 garden 版式退役（v4.475 首页合一，.p-poster-desc 已删）
})

describe('可访问性守卫（v4.349）', () => {
  it('全屏看图关闭钮有可访问名', () => {
    const src = read('components/Lightbox.tsx')
    expect(src).toMatch(/<Button type="text" icon=\{<CloseOutlined \/>\}[^>]*aria-label="关闭/)
  })

  it('阻断式批准弹窗是 aria-modal="true"', () => {
    const src = read('gaea/components/ApprovalModal.tsx')
    expect(src).toContain('role="dialog" aria-modal="true"')
    expect(src).not.toContain('aria-modal="false"')
  })

})

describe('后台空转与流式节流守卫（v4.365）', () => {
  it('聊天流式 delta 走 rAF 合并 flush，不再每 chunk 一次 setStreamText', () => {
    const src = read('hooks/useChatStream.ts')
    expect(src).toContain('cancelPendingDelta')
    expect(src).toContain('requestAnimationFrame(flushDelta)')
    expect(src).not.toMatch(/setStreamText\(prev => prev \+ \(p\.content/)
    // 角色模式打字机为 rAF 时间驱动，不再 setTimeout(14) 循环
    expect(src).not.toContain('setTimeout(r, 14)')
  })

  it('四个常驻 canvas 循环都有隐藏挂起守卫（keepAlive 页后台不烧绘制）', () => {
    for (const f of ['components/ParticleFlow.tsx', 'components/SoundWaveOverlay.tsx', 'components/CompanionAvatar.tsx']) {
      const src = read(f)
      expect(src).toMatch(/document\.hidden \|\| canvas\.offsetParent === null/)
    }
    // VoiceChatOrb 随 V1 语音链退役（2026-11-05），守卫名单同步减一
    expect(read('components/RelationGraph.tsx')).toMatch(/document\.hidden \|\| !canvas \|\| canvas\.offsetParent === null/)
  })


  it('AOA 几何管线已 memo 化（缩放/选中变化不再全量重算）', () => {
    const src = read('schedule/AoaView.tsx')
    expect(src).toContain('const aoaGeo = useMemo(')
    expect(src.indexOf('const aoaGeo = useMemo(')).toBeLessThan(src.indexOf('暂无任务或计划存在循环依赖'))
  })
})
