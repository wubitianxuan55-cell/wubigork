import React from 'react'
import { Button, Tag } from 'antd'
import {
  ThunderboltOutlined, CloseCircleOutlined, LoadingOutlined,
  ClockCircleOutlined, DatabaseOutlined,
} from '@ant-design/icons'
import { C } from '../../utils/theme'
import { estimateImageTime } from './ui'
import { backendSupportsMode } from './meta'
import { GenerationProgress } from './GenerationProgress'
import type { ImageMode } from './types'

interface Props {
  mode: ImageMode
  backend: string
  model: string
  count: number
  frames: number
  fps: number
  generating: boolean
  elapsed: number
  lastTime: number
  pendingCount: number
  queueTotal: number
  comfyProgress?: { status: string; elapsed: number; percent?: number; node?: string }
  needsComfy: boolean
  /** 页面级内容门禁：缺画面描述时禁用主按钮并把原因放回生成栏。 */
  hasPrompt?: boolean
  /** 图生图必须已有参考图；其它模式默认满足。 */
  hasReference?: boolean
  onGenerate: () => void
  onCancel: () => void
}

export const GenerationBar: React.FC<Props> = ({
  mode, backend, model, count, frames, fps,
  generating, elapsed, lastTime, pendingCount, queueTotal,
  comfyProgress, needsComfy, hasPrompt = true, hasReference = true,
  onGenerate, onCancel,
}) => {
  const est = estimateImageTime(backend, model, count, mode, frames, fps)

  // 模式 × 引擎能力门禁（单源）：needsComfy 来自页面级「缺引擎」提示，
  // backendSupportsMode 兜住引擎固有模式约束（GLM 仅文生图），
  // 两者任一不满足即禁用生成，避免残留态点击后被后端拒收。
  const modeBlocked = !backendSupportsMode(backend, mode) || needsComfy
  const contentBlocked = !hasPrompt || (mode === 'img2img' && !hasReference)
  const blockReason = modeBlocked
    ? backend === 'glm'
      ? 'GLM 仅支持文生图，请切换到文生图模式或更换引擎'
      : mode === 't2v'
        ? '文生视频需切换至 ComfyUI'
        : '图生图需切换至 ComfyUI / Herdsman'
    : !hasPrompt
      ? mode === 't2v' ? '先写下视频画面描述' : '先写下画面描述'
      : mode === 'img2img' && !hasReference
        ? '先上传一张参考图'
        : ''
  const generateDisabled = modeBlocked || contentBlocked

  let hint: string
  if (!generating && contentBlocked) {
    hint = blockReason
  } else if (generating) {
    hint = `已用时 ${elapsed}s`
  } else if (backend === 'comfyui' && comfyProgress?.status === 'running') {
    hint = `ComfyUI 执行中 · ${comfyProgress.elapsed}s`
  } else if (backend === 'comfyui' && comfyProgress?.status) {
    hint = 'ComfyUI 排队中'
  } else if (lastTime > 0) {
    hint = `上次 ${lastTime}s · 预计约 ${est}s`
  } else {
    hint = `预计约 ${est}s`
  }

  const label = generating
    ? pendingCount > 0 ? `生成中 · 队列 ${pendingCount}` : '生成中'
    : mode === 't2v' ? '生成视频' : `生成 ${count} 张`

  // ComfyUI 实时进度（percent >= 0 时显示确定进度条；其余后端/未知显示不定态光带）
  const hasRealProgress = generating && backend === 'comfyui' && (comfyProgress?.percent ?? -1) >= 0
  const percent = hasRealProgress ? Math.min(100, Math.max(0, comfyProgress!.percent!)) : -1
  return (
    <div className={generating ? 'ig-bottom-bar is-busy' : 'ig-bottom-bar'}>
      {generating && (
        <GenerationProgress
          percent={hasRealProgress ? percent : -1}
          node={comfyProgress?.node}
        />
      )}
      <div
        className="ig-bottom-row"
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, minWidth: 0, width: '100%' }}
      >
        <div
          className="ig-bottom-hint"
          style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0, flexWrap: 'wrap' }}
        >
          <span className="ig-bottom-hint-main" style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            {generating
              ? <LoadingOutlined style={{ color: 'var(--color-primary)' }} />
              : <ClockCircleOutlined style={{ color: C('color-text-secondary') }} />}
            <span>{hint}</span>
          </span>
          {queueTotal > 0 && (
            <Tag icon={<DatabaseOutlined />} color="processing" style={{ marginInlineEnd: 0, borderRadius: 999, fontSize: 11 }}>
              队列 {queueTotal}
            </Tag>
          )}
          {blockReason && !contentBlocked && (
            <span style={{ fontSize: 11, color: 'var(--md-sys-color-warning)' }}>
              {blockReason}
            </span>
          )}
        </div>
        <div className="ig-bottom-actions" style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
          {(generating || pendingCount > 0) && (
            <Button
              size="middle"
              icon={<CloseCircleOutlined />}
              onClick={onCancel}
              style={{ borderRadius: 999, fontSize: 12 }}
            >
              取消
            </Button>
          )}
          <button
            type="button"
            disabled={generateDisabled}
            onClick={onGenerate}
            className="ig-gen-button"
            aria-busy={generating}
            title={blockReason || undefined}
          >
            {generating ? <LoadingOutlined /> : <ThunderboltOutlined />}
            {label}
          </button>
        </div>
      </div>
    </div>
  )
}

