/**
 * boards/manifests.ts — 板块 manifest 数据源（3.0 架构 §5.2 / 附 B）
 *
 * 数据源 seam（§5.3 前端侧）：提供者 = CoreB.GetBoardManifests()（经 gaea/lib/bridge
 * 代理，见 gaea/lib/bridge.ts LegacySurfaceNames 注记）；消费者 = 菜单/白名单/快捷键/
 * 布局派生视图（MainLayout 经 subscribeBoards 订阅）。加载失败/未就绪时 fail-closed
 * 回退内置静态 canonicalBoards，壳层永远可用。
 * 板块差集归一（normalizeManifests）：后端清单为准并过滤已退役的壳层 id——
 *   · knowledge：后端 D7 独立板块（前端静态清单无）→ 并入记忆中枢；
 *   · home：首页已删除，后端旧清单或旧深链均 fail-closed 过滤；
 *   · weixin：v4.4 起两端一致（WeixinPage 已落地，后端 Page 优先照常生效）。
 * 12 硬编码点收敛映射（附 B）：menuItems=filter(inMenu).sort(menuOrder)；
 * allPageKeys=manifest 派生导航白名单；pageLabels=manifest.label；Ctrl+1~4=manifest.shortcut；
 * Content 布局=manifest.layout；面包屑锚点=manifest.breadcrumb.anchorTo；
 * 启动页=DEFAULT_BOARD_ID（办公）；settings 入口=manifest.inMenu=false。
 */
import {
  MessageOutlined, ReadOutlined, PictureOutlined,
  ToolOutlined, DatabaseOutlined, ApiOutlined, TeamOutlined,
  SettingOutlined, WechatOutlined, BookOutlined, AccountBookOutlined,
  ScheduleOutlined,
  FireOutlined, MonitorOutlined, CodeOutlined,
  CrownOutlined,
} from '@ant-design/icons'
import type { ComponentType } from 'react'
import type { BoardManifest, BoardNavChild } from './types'
import { app } from '../gaea/lib/bridge'
import { isIndependentBoard, type BoardSpace } from './space'

// ─── 图标注册表：manifest.icon 名（antd 图标名）→ 组件查表解析 ───────────────
const ICON_REGISTRY: Record<string, ComponentType> = {
  MessageOutlined, ReadOutlined, PictureOutlined,
  ToolOutlined, DatabaseOutlined, ApiOutlined, TeamOutlined,
  SettingOutlined, WechatOutlined, BookOutlined, AccountBookOutlined,
  ScheduleOutlined, FireOutlined, MonitorOutlined, CodeOutlined,
  CrownOutlined,
}

/** 查表解析 antd 图标；未知图标名返回 null（不抛错，渲染时退化） */
export function resolveBoardIcon(name: string): ComponentType | null {
  return ICON_REGISTRY[name] ?? null
}

// ─── 板块内子导航（与各页面实际 tab/分类一致）─────────────────────────────
const SETTINGS_NAV: BoardNavChild[] = [
  { id: 'general', label: '通用' }, { id: 'chat', label: '聊天' },
  { id: 'imagegen', label: '绘梦' },
  { id: 'office', label: '办公' }, { id: 'model', label: '模型' },
  { id: 'security', label: '安全' }, { id: 'data', label: '数据' },
  { id: 'about', label: '关于' },
]
const MEMORYHUB_NAV: BoardNavChild[] = [
  { id: 'knowledge', label: '知识库' },
  { id: 'profile', label: '用户画像' }, { id: 'office', label: '办公记忆' },
  { id: 'materials', label: '项目资料' }, { id: 'whisper', label: '聊天记忆' },
  { id: 'graph', label: '记忆图谱' }, { id: 'digitallife', label: '数字生命' },
]
const COST_NAV: BoardNavChild[] = [
  { id: 'overview', label: '概览' },
  { id: 'entries', label: '成本条目' },
  { id: 'sources', label: '价格源' },
  { id: 'repository', label: '价格仓库' },
]

/**
 * 内置 canonical 板块清单（14 条业务板块，含 inMenu=false 的 settings）。
 * menuOrder 与现状 menuItems 顺序一致；settings inMenu=false（右上角按钮入口）。
 * weixin：v4.4 触点落地（WeixinPage 扫码绑定 + 离线代办），进 rail。
 * sin 板块已退役并整体删除（2026-10-27 撤导航收编第六页签；2026-11-15 拍板全删：
 * sinboard/pages-sin/SinB 门面/sin 功能绑定/sin 引擎全家同步拆除）。
 */
export const canonicalBoards: BoardManifest[] = [
  {
    id: 'chat', label: '聊天', icon: 'MessageOutlined', page: 'ChatPage',
    lazy: true, keepAlive: true, layout: 'full', shortcut: 'ctrl+1',
    menuOrder: 1, inMenu: true, featureModel: 'chat', space: 'play', // §10.3 对话降为对话流（乐园=会客厅）
  },
  {
    // 文学板块（2026-11-15）：办公板块的完整前端拷贝（frontend/src/wenxue/），独立
    // 引擎装配（feature=wenxue 绑定）。2026-11-15 小说板块退役后接替其一级导航位
    // （menuOrder 2 + ReadOutlined + ctrl+2，用户拍板「一级图标给文学板块」）；
    // 与 Go builtins.go 同步翻，防 normalizeManifests 后端字段优先导致真机/浏览器分裂。
    id: 'wenxue', label: '文学', icon: 'ReadOutlined', page: 'WenxuePage',
    lazy: true, keepAlive: true, layout: 'full', shortcut: 'ctrl+2',
    menuOrder: 2, inMenu: true, breadcrumb: { anchorTo: 'wenxue' },
    featureModel: 'wenxue', space: 'work',
  },
  {
    id: 'imagegen', label: '绘梦', icon: 'PictureOutlined', page: 'ImageGenPage',
    lazy: true, keepAlive: true, layout: 'padded', shortcut: 'ctrl+3',
    menuOrder: 3, inMenu: true, space: 'play',
  },
  {
    id: 'gaea', label: '办公', icon: 'ToolOutlined', page: 'GaeaPage',
    lazy: true, keepAlive: true, layout: 'full', shortcut: 'ctrl+4',
    menuOrder: 4, inMenu: true, featureModel: 'gaea', space: 'work',
  },
  {
    id: 'cost', label: '造价数据库', icon: 'AccountBookOutlined', page: 'CostLibraryPage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 5, inMenu: true, nav: { children: COST_NAV }, featureModel: 'cost', space: 'work',
  },
  {
    // 2026-11-08 用户恢复：编程回流为独立一级板块。页面只承载官方 Web 安装、
    // 隔离边界与插件适配入口，不恢复旧 DSH 进程管理绑定。
    id: 'code', label: '编程', icon: 'CodeOutlined', page: 'ProgrammingPage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 6, inMenu: true, space: 'independent',
  },
  {
    id: 'pantheon', label: '众神殿', icon: 'CrownOutlined', page: 'PantheonPage',
    lazy: true, keepAlive: true, layout: 'full',
    menuOrder: 6, inMenu: true, space: 'shared',
  },
  {
    id: 'memoryhub', label: '记忆中枢', icon: 'DatabaseOutlined', page: 'MemoryHubPage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 7, inMenu: true, nav: { children: MEMORYHUB_NAV }, space: 'work',
  },
  {
    id: 'modelcenter', label: '模型中心', icon: 'ApiOutlined', page: 'ModelCenterPage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 8, inMenu: true, space: 'shared',
  },
  {
    id: 'characterlib', label: '角色库', icon: 'TeamOutlined', page: 'CharacterLibraryPage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 9, inMenu: true, featureModel: 'characterlib', space: 'play',
  },
  {
    id: 'settings', label: '设置', icon: 'SettingOutlined', page: 'SettingsPage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 10, inMenu: false, nav: { children: SETTINGS_NAV }, space: 'shared',
  },
  {
    id: 'weixin', label: '微信助手', icon: 'WechatOutlined', page: 'WeixinPage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 11, inMenu: true, space: 'work', // v4.4：触点落地，进 rail + 首页左翼
  },
  {
    id: 'schedule', label: '进度计划', icon: 'ScheduleOutlined', page: 'SchedulePage',
    lazy: true, keepAlive: true, layout: 'padded',
    // 2026-11-14 用户拍板：进度板块从办公板块分离为一级板块（撤 v4.168.0 瘦身刀1 的
    // inMenu:false 合并语义）。办公侧承接入口保留：文件面 .gsched 摘要卡、命令面板项、
    // 右栏一级 Tab（ScheduleTool）。与 Go builtins.go 同步翻，防 normalizeManifests
    // 后端字段优先导致真机/浏览器分裂。
    menuOrder: 12, inMenu: true, space: 'work',
    featureModel: 'schedule',
  },
  {
    // 运行监测（2026-10-19，参照 Strata Monitor 仪表盘）：系统资源 + 引擎状态 +
    // Strata 系引擎 /metrics 遥测 + gaea 侧最近调用记账的聚合仪表盘。
    id: 'runtime', label: '运行监测', icon: 'MonitorOutlined', page: 'RuntimePage',
    lazy: true, keepAlive: true, layout: 'padded',
    menuOrder: 14, inMenu: true, space: 'shared',
  },
]

// ─── 类型级断言锁死（附 B #1：Page 类型由 manifest.id 派生）────────────────
/** 锁死：所有 canonical 板块 id 联合（navigateWhitelist: BoardId[] 消费，
 *  新增/改名板块漏改即编译失败——原先另有两条 AssertNever<never> 别名，
 *  实为恒真空操作且触发 noUnusedLocals，已删） */
export type BoardId = (typeof canonicalBoards)[number]['id']

/** 应用启动落点：办公是默认工作台。 */
export const DEFAULT_BOARD_ID = 'gaea' satisfies BoardId

// ─── 派生视图通用实现（列表参数化：静态 canonicalBoards 与活动清单共用）──────
/** 顶栏菜单：filter(inMenu) + sort(menuOrder)（附 B #4） */
export function deriveMenuBoards(list: BoardManifest[]): BoardManifest[] {
  return [...list]
    .filter((b) => b.inMenu)
    .sort((a, b) => (a.menuOrder ?? Number.MAX_SAFE_INTEGER) - (b.menuOrder ?? Number.MAX_SAFE_INTEGER))
}

/** 导航白名单：所有已注册板块 id（附 B #2，navigate 事件校验）。
 *  注册即可导航；inMenu 只控菜单、不再派生可导航性。v4.164 前科：藏板块（inMenu=false）经
 *  NAVIGATE 白名单 fail-closed 静默丢导航；刀1 schedule inMenu=false 依赖本语义。 */
export function deriveNavigateWhitelist(list: BoardManifest[]): string[] {
  return list.map((b) => b.id)
}

/** 快捷键映射：'ctrl+1' → board（附 B #6，显式声明不依赖数组顺序） */
export function deriveShortcutMap(list: BoardManifest[]): Record<string, string> {
  return Object.fromEntries(list.filter((b) => b.shortcut).map((b) => [b.shortcut as string, b.id]))
}

/** 面包屑项目锚点板块（附 B #8：声明 breadcrumb.anchorTo 的板块，wenxue 是项目锚点——
 *  2026-11-15 小说板块退役后文学板块接替锚点位） */
export function deriveProjectAnchorId(list: BoardManifest[]): string {
  return list.find((b) => b.breadcrumb?.anchorTo)?.id ?? 'wenxue'
}

/** 按 id 查板块（附 B #7 pageLabels 来源） */
export function deriveBoard(list: BoardManifest[], id: string): BoardManifest | undefined {
  return list.find((b) => b.id === id)
}

/** 板块显示名（面包屑/启动器直接用 manifest.label，附 B #7） */
export function deriveBoardLabel(list: BoardManifest[], id: string): string {
  return deriveBoard(list, id)?.label ?? id
}

// ─── 静态派生视图（fallback 基线，附 B 像素回归测试锁定）─────────────────
// 主 rail 不含 independent；编程实例只走壳层 foot 独立入口。
export const menuBoards: BoardManifest[] = deriveMenuBoards(
  canonicalBoards.filter((b) => !isIndependentBoard(b)),
)
export const navigateWhitelist: BoardId[] = deriveNavigateWhitelist(canonicalBoards)
export const shortcutMap: Record<string, BoardId> = deriveShortcutMap(canonicalBoards)
export const projectAnchorId: string = deriveProjectAnchorId(canonicalBoards)
export function getBoard(id: string): BoardManifest | undefined {
  return deriveBoard(canonicalBoards, id)
}
export function boardLabel(id: string): string {
  return deriveBoardLabel(canonicalBoards, id)
}

// ─── 后端 GetBoardManifests 接线（§5.3 seam 前端侧）──────────────────────
// 提供者 = CoreB.GetBoardManifests()（经 gaea/lib/bridge 代理）；消费者 = 下方
// getActive* 派生视图（MainLayout 订阅）。加载前活动清单 = 静态 canonicalBoards。

/** 后端 manifest 原始形态（wailsjs board.Manifest 字段子集，结构兼容） */
export interface RemoteBoardManifest {
  id: string
  label?: string
  icon?: string
  page?: string
  lazy?: boolean
  keepAlive?: boolean
  layout?: string
  shortcut?: string
  menuOrder?: number
  inMenu?: boolean
  // 后端为 Go string（空间枚举由后端校验）；前端在此收敛为字面量联合，
  // 未知值回退静态清单，避免把不可信远程值直接灌进导航派生视图。
  space?: string
  breadcrumb?: { anchorTo?: string }
  nav?: { children?: BoardNavChild[] }
  featureModel?: string
}

function isBoardSpace(s: unknown): s is BoardSpace {
  return s === "work" || s === "play" || s === "shared" || s === "independent";
}

/**
 * 板块差集归一（merge 语义 = 后端清单 + 前端静态 field 兜底）：
 *  - 重叠 id：后端字段优先，缺失字段回填前端静态（icon/page/layout 兜底）；
 *  - knowledge：后端 D7 独立板块**过滤不并入一级导航**——知识库已并入记忆中枢
 *    （MemoryHubPage「知识库」分类），一级导航不再单列避免重复入口（3.0 定制）；
 *  - home：首页已删除；旧后端清单若仍返回 home，导航侧过滤；
 *  - weixin：v4.4 触点落地，前后端同为 WeixinPage/inMenu=true（后端字段优先不变）；
 *  - 空输入返回 []（回退决策在 loadBoardManifests 层）。
 */
export function normalizeManifests(remote: RemoteBoardManifest[]): BoardManifest[] {
  const staticById = new Map(canonicalBoards.map((b) => [b.id, b]))
  const out: BoardManifest[] = []
  for (const r of remote ?? []) {
    if (!r || typeof r.id !== 'string' || r.id === '') continue
    // knowledge 并入记忆中枢；home 已退役。两者都不进入导航派生。
    if (r.id === 'knowledge' || r.id === 'home') continue
    const base = staticById.get(r.id)
    out.push({
      id: r.id,
      label: r.label ?? base?.label ?? r.id,
      icon: r.icon ?? base?.icon ?? '',
      page: r.page ?? base?.page ?? '',
      lazy: r.lazy ?? base?.lazy ?? false,
      keepAlive: r.keepAlive ?? base?.keepAlive ?? true,
      layout: r.layout === 'full' || r.layout === 'padded' ? r.layout : (base?.layout ?? 'padded'),
      shortcut: r.shortcut ?? base?.shortcut,
      menuOrder: r.menuOrder ?? base?.menuOrder,
      inMenu: r.inMenu ?? base?.inMenu ?? false,
      space: isBoardSpace(r.space) ? r.space : base?.space,
      breadcrumb: r.breadcrumb ? { anchorTo: r.breadcrumb.anchorTo } : base?.breadcrumb,
      nav: r.nav ? { children: r.nav.children ?? [] } : base?.nav,
      featureModel: r.featureModel ?? base?.featureModel,
    })
  }
  // 稳定排序：menuOrder 升序（undefined 视为无穷大）
  out.sort((a, b) => (a.menuOrder ?? Number.MAX_SAFE_INTEGER) - (b.menuOrder ?? Number.MAX_SAFE_INTEGER))
  return out
}

// ── 活动清单状态（加载成功后被合并清单替换；失败保持静态 fallback）──────
let activeBoards: BoardManifest[] = canonicalBoards
const boardListeners = new Set<() => void>()

/** 订阅活动板块清单变化（MainLayout 重渲染用）；返回退订函数 */
export function subscribeBoards(cb: () => void): () => void {
  boardListeners.add(cb)
  return () => { boardListeners.delete(cb) }
}

function notifyBoardsChanged(): void {
  for (const cb of boardListeners) cb()
}

/** 当前生效板块清单（后端合并；未加载 = 静态 canonicalBoards） */
export function getActiveBoards(): BoardManifest[] {
  return activeBoards
}

// ── 活动派生视图（消费者：MainLayout 菜单/白名单/快捷键/布局/面包屑）────
// 一级导航合一（2026-10-26）：主 rail 收纳非独立板块；independent 走 foot 单列。
export function getActiveMenuBoards(): BoardManifest[] {
  return deriveMenuBoards(activeBoards.filter((b) => !isIndependentBoard(b)))
}
/** S2.1：独立窗口板块——两空间导航/首页均不出现，壳层单独入口。 */
export function getActiveIndependentBoards(): BoardManifest[] {
  return deriveMenuBoards(activeBoards.filter(isIndependentBoard))
}
export function getActiveNavigateWhitelist(): string[] { return deriveNavigateWhitelist(activeBoards) }
export function getActiveShortcutMap(): Record<string, string> { return deriveShortcutMap(activeBoards) }
export function getActiveProjectAnchorId(): string { return deriveProjectAnchorId(activeBoards) }
export function getActiveBoard(id: string): BoardManifest | undefined { return deriveBoard(activeBoards, id) }
export function activeBoardLabel(id: string): string { return deriveBoardLabel(activeBoards, id) }

/** 测试隔离：恢复静态 fallback 基线（vitest beforeEach，与 clearPageRegistry 同范式） */
export function resetActiveBoardsForTest(): void {
  activeBoards = canonicalBoards
  notifyBoardsChanged()
}

/**
 * 后端 GetBoardManifests 绑定的接入点（§5.3 seam 提供者调用）：
 *  1. 优先 CoreB.GetBoardManifests()（经 gaea/lib/bridge 代理）；
 *  2. 成功 → normalizeManifests 合并（过滤 knowledge/home）并替换活动清单；
 *  3. 失败/空/未就绪（浏览器 dev mock 无 window.go）→ fail-closed 回退静态
 *     canonicalBoards，壳层保持可用。
 * 返回生效清单；消费方经 subscribeBoards 感知变化。
 */
export async function loadBoardManifests(): Promise<BoardManifest[]> {
  let merged: BoardManifest[] = []
  try {
    const remote = await app.GetBoardManifests()
    if (Array.isArray(remote)) {
      merged = normalizeManifests(remote as unknown as RemoteBoardManifest[])
    }
  } catch {
    merged = []
  }
  activeBoards = merged.length ? merged : canonicalBoards
  notifyBoardsChanged()
  return activeBoards
}
