# gaea 板块蓝图 · weixin 微信助手「通讯枢纽」

> 覆盖 MASTER。v4.47.0 落地（WeixinPage.tsx + weixin-page.css），取代 misc.md 中
> 「服务型板块，无页面」的过时定位（v4.4 起 WeixinPage 已在 rail）。

## 视觉性格：通讯枢纽（Link Hub）
服务型工作台 = 实时运营台语义：通道状态一眼可读、绑定流渐进引导、提醒即代办
收件箱。对齐 Constellation OS 三分区语言（strip + 左轨道 + 主区），信息层用
`v3-panel`/`v3-card` 实底卡，容器层 Luminous Glass 2.0。

## 布局（wx-* 类，见 frontend/src/pages/weixin-page.css）
- **顶部细条 `.wx-strip`**（40px 玻璃）：WechatOutlined + 「微信助手」+ 一句话
  定位 + 通道遥测 meta（等宽数字 `3 通道 · 1 运行中 · 提醒 开`，role=status）
  + 刷新按钮。原整卡介绍收敛为一句副标语，完整说明移到指南视图。
- **左轨道 `.wx-rail`（196px）**：通道组 = 每助手一条 rail item（antd Avatar
  26px + 名字 + 状态字 + 状态点）；「+ 新增微信助手」dashed 项挂组尾；
  「支持」组 = 离线提醒（pending 数徽标）/ 使用指南。激活态 =
  primary-container 底 + 左缘 `--gaea-glow` 光条（对齐 hub-rail）。
- **主区 `.wx-main` 三视图**（rail 点击驱动）：
  1. 通道详情 `ChannelDetail`：身份头（Avatar 44 + 核心/人格 Tag + 绑定/删除
     操作）→ 会话过期内联 Alert → 三张键值卡（通道状态/微信绑定/启停 Switch）。
  2. 离线提醒：标题 + 全局「到点回推微信」Switch → 新建行（Input+DatePicker+
     创建）→ `wx-rem-item` 行（状态 Tag/文本/来源/重试/等宽时间/删除）。
  3. 使用指南：三张 `wx-guide-card`（设提醒示例句 `wx-cmd` 等宽 chip /
     收提醒 / 聊天）+ 脚注。

## 状态语义（三重传达：色 + 文字 + 详情 Tag）
`channelStatusOf`：running=success 发光脉冲（reduced-motion 关闭）/
expired=warning / stopped=次级 62% / unbound=虚线空心点。rail 状态字 +
`title` + 详情区完整 antd Tag 同口径。

## 关键流
- 扫码绑定 Modal：`wx-qr-steps` 三步指示（扫码→确认→完成，等宽字）+ 240px
  `wx-qr-frame` 二维码容器；相位文案/配对码/错误分支照旧。
- 新增助手 Modal（名字 + 人格 ID）→ 扫码 confirmed 落库 → 主区直接落在新通道。
- 会话过期：选中通道详情内联 Alert（全局任一过期的语义保留在状态字）。

## 纪律
- 零硬编码色值：只消费 --md-sys-* / --gaea-* / --color-* / --v3-* 与旧栈
  令牌，派生一律 color-mix。
- 功能零删减（v4.4 面逐项对齐）：多助手 CRUD/逐助手扫码/启停/核心禁删禁停/
  提醒 CRUD + 全局开关/使用说明/过期警示。
- 测试锁：WeixinPage.test.tsx 8 场景（轨道渲染/启停载荷/核心限制/删除/
  新增扫码流/提醒视图/指南视图/过期警示）。
- dev mock：`gaea/lib/mock/weixin.ts` 提供微信域离线数据（伪二维码 SVG、
  扫码相位推进 2→4 次轮询）。

## v4.48 增补：更名「青鸟」+ 人格选择器
- 板块 label 更名「青鸟」（board id weixin 不动）；通道文案保留「微信」。
- 新增助手弹窗 = `wx-pk-*` 双栏选择器：左搜索+分组列表（轻语预设/角色库
  可聊天角色，18+ 过滤），右详情预览（立绘/来源 Tag/性别/标签/描述）；
  listbox/option a11y；默认选中 gaea 预设，加载失败降级照常确认。
- portraitUrl 随 Save 落库 → 轨道/详情头像真立绘回显。
- 测试锁：WeixinPage.test 9 场景；spaceBindings facets 数量锁 266。

## v4.49 增补：编辑助手 + 生命周期
- 通道详情操作区 = 扫码绑定 · 编辑（core 不渲染）· 删除。
- 编辑弹窗复用 PersonaPickerPanel（新增/编辑共用 personaOpts；编辑预填当前
  personalityId，custom id 不在选项时保留原值 + 占位提示，绝不静默重置）。
- 角色库 custom 角色卡「创建青鸟助手」→ 未绑定助手 + 文案引导扫码绑定；
  EnsureAssistants 镜像守卫：custom 角色永不被镜像覆写。

## 2026-10-31 重设计：通讯航路
- **当前名称 = 微信助手**。用户反馈「青鸟」过于晦涩，导航、页面标题、新增/
  删除/深链文案全部回到直白命名；board id `weixin` 与旧意图别名「青鸟」
  仅为兼容保留，不再作为可见名称。
- 主区从「身份头 + 三张键值卡」升级为**可判读的通讯链路由**：
  微信端 → 助手内核 → 桌面能力；running 时点亮传输包，unbound / expired /
  stopped 同步降阶，仍保留颜色 + 文字 + 状态 Tag 三重传达。
- 通道轨道直接标注解析后的人格与来源（如「盖亚 · 轻语预设」）；详情新增
  **人物档案**：头像、来源、性别、人物定位、年龄、标签、人格设定、人物背景
  与沟通口吻。预设人格补「内置人格、不绑定具体背景」的诚实说明，角色库人物
  使用真实 personality / background / voiceGuide 字段。
- 人物剧照位：`portraitUrl` 优先，缺失时用 `galleryImages[0]`；角色库其他
  剧照以缩略胶卷展示。角色库内置人格没有真人剧照时不伪造身份照，显示同主题的
  「预设形象」矢量化人物剪影；角色库一旦设置剧照，轨道头像、档案主图与
  选择器自动同步更新。
- 数据源统一为 `CharacterList`：内置人格（kind=builtin/assistant）与自建
  角色（kind=custom）均直接消费同一行记录的名称、性格、背景、定位、标签、
  portraitUrl 与 galleryImages；不再从 `WhisperGetPersonalities` 窄投影
  二次拼装人物档案。页面重新可见时刷新一次，不纳入 5s 轮询。
- 详情采用非对称双栏：左侧链路由与能力范围，右侧通道控制台（启停、绑定、
  生效方式）；底部两张入口卡直达提醒工作流与使用指南。
- 提醒页增加基于真实 reminders 数据派生的「等待触达 / 已送微信 / 需要处理」
  统计和最近一条待办；列表改为任务流（状态信号 · 内容 · 来源 · 时间）。
- 指南采用 1 大 2 小的非对称手册版式；窄窗 980 / 860 / 720 / 520 四级降阶，
  通道轨道在窄窗横排滚动，链路由在手机上转纵排。
- 视觉纪律不变：信息层实底、容器层轻玻璃、单一主色、语义状态色、
  reduced-motion 降至静帧；新增样式继续零硬编码色值。
