# gaea 3.0 板块蓝图 · characterlib 角色库 / settings 设置 / knowledge 知识库 / weixin 微信

> 覆盖 MASTER。实施参考 docs/2026-08-15-gaea3-ui-design-system.md。

## characterlib 角色库
- **视觉性格：选角工作台**——人物剧照主导的档案墙 + 常驻档案 inspector。
- 现状：CharacterLibraryPage + CharacterCard/CharacterLibEditor（立绘横幅/随机补齐/生成剧照/可聊天开关）；
  角色库联动聊天/小说（单向引用）。
- 2026-10-31 重设计：顶部人物宣言 + 横向检索带取代左侧整列筛选；主区改为
  三列表格化人物墙（`minmax(190px,1fr)`），右侧 336px 常驻 inspector。
  首屏/翻页/筛选后自动选中第一位有效角色，不再默认空白检查器。
- 档案卡：3:4 剧照、档案眉（编号/类型/项目/可聊天）、名称与元数据叠加、
  两行弧线、标签和底部工具栏；当前检查项使用主色边线与左缘标记，操作按钮
  键盘可达并按来源剧照更新时立即换图。
- Inspector：整幅剧照主视觉、项目/人格/聊天三重状态、两列动作网格、
  人物设定和人格记忆分区；窄窗降为画廊下方可折叠检查器。
- 数据工具收进筛选带下拉菜单，保留一键补齐/项目导入/项目同步；删除仍走确认。

## settings 设置
- **视觉性格：克制工具**——分组导航 + 表单，信息密度低、可扫读。
- 现状：SettingsPage + components/settings/*（通用/聊天/小说/绘梦/办公/模型/安全/数据/关于 9 分组，
  左侧导航 + 全局搜索）。
- 目标：左侧分组导航（激活 = primary-container + 左缘条）；表单走令牌 + 显式标签 + 错误就近；
  数据备份/恢复（危险操作 destructive 确认）；关于 = 品牌卡 + 版本信息。
- 落地：分组导航激活态统一；表单 focus 环；危险操作确认色。

## knowledge 知识库（3.0 D7 板块）
- **视觉性格：文档库**——面板 + 导入/检索/预览。
- 现状：KnowledgePage（KnowledgePanel variant="page"）+ 导入 Modal + 预览；已注册 PageRegistry + manifest。
- 目标：面板玻璃化 + 分类树（激活 primary-container）+ 条目卡（名称/摘要/来源）；导入走确认流程；
  预览抽屉玻璃化。落地：面板/条目令牌化 + 焦点环。

## weixin 微信助手
- v4.4 起有页面（WeixinPage，manifest page="WeixinPage"、inMenu=true）；
  v4.47 星枢化重构为「通讯枢纽」工作台——蓝图与落地细节见同目录 weixin.md
  （覆盖本文件）。
